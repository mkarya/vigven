from PySide import QtGui, QtCore

from pyrf.units import M
import colors
from widgets import QPushLabelPlayback
from fonts import GROUP_BOX_FONT
from pyrf.sweep_device import MAXIMUM_SPP as MAXIMUM_SWEEP_SPP
from gui_config import WindowOptions
from device_controls import DeviceControls
from frequency_controls import FrequencyControls
from bw_controls import BWControls
from amplitude_controls import AmplitudeControls
from trace_controls import TraceControls
from measurements_widget import MeasurementControls
from capture_widget import SweepControls
from marker_controls import MarkerControls
from mode_controls import ModeControls
from preset_controls import PresetControls
from display_controls import DisplayControls
from trigger_controls import TriggerControls
from util import change_widget_background

CONTROL_BUTTONS = ['AMPLITUDE',
'BW',
'DISPLAY',
'FREQ \n SPAN',
'MARKER',
'MEAS \n SETUP',
'MODE \n MEAS',
'PEAK \n SEARCH',
'SWEEP',
'TRACE',
'TRIGGER',
'SYSTEM',
'PRESET']

WIDGET_NAMES = ['amplitude_control',
                'bw_control',
                'display_control',
                'frequency_control',
                'marker_control',
                'measurement_control',
                'mode_control',
                'marker_control',
                'capture_control',
                'trace_control',
                'trigger_control',
                'device_control',
                'preset_control']

BUTTON_NAMES_TO_WIDGET = {}
for n, w in enumerate(WIDGET_NAMES):
    BUTTON_NAMES_TO_WIDGET[w] = CONTROL_BUTTONS[n]
    
WIDGET_TO_BUTTON_NAMES = {}
for n, b in enumerate(CONTROL_BUTTONS):
    BUTTON_NAMES_TO_WIDGET[b] = WIDGET_NAMES[n]

class GUIControls(QtGui.QGroupBox):
    """
    Widget containing all of the RTSA controls
    """
    def __init__(self, controller):
        super(GUIControls, self).__init__()
        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        controller.marker_change.connect(self.marker_changed)
        controller.window_change.connect(self.window_changed)
        controller.app_change.connect(self.app_changed)
        self.window_state = WindowOptions().state
        self.create_controls()
        self.build_layout()
        self.connect_controls()

    def create_controls(self):
    
        # initialize all of the buttons
        self.buttons = []
        for b in CONTROL_BUTTONS:
            button = QPushLabelPlayback(b)
            self._prep_button(button)
            self.buttons.append(button)

        # initialize all of the control
        self.controls = {}
        self.setMaximumWidth(350)
        self.controls['frequency_control'] = FrequencyControls(self.controller)
        self.controls['bw_control'] = BWControls(self.controller)
        self.controls['amplitude_control'] = AmplitudeControls(self.controller)
        self.controls['measurement_control'] = MeasurementControls(self.controller)
        self.controls['marker_control'] = MarkerControls(self.controller)
        self.controls['trace_control'] = TraceControls(self.controller)
        self.controls['capture_control'] = SweepControls(self.controller)
        self.controls['device_control'] = DeviceControls(self.controller)
        self.controls['preset_control'] = PresetControls(self.controller)
        self.controls['trigger_control'] = TriggerControls(self.controller)
        self.controls['display_control'] = DisplayControls(self.controller)
        self.controls['mode_control'] = ModeControls(self.controller)

    def build_layout(self):

        main_layout = QtGui.QHBoxLayout()
        main_layout.setSpacing(40)
        control_layout = QtGui.QVBoxLayout()
        control_layout.setSpacing(0)
        main_layout.setSpacing(5)
        button_layout = QtGui.QVBoxLayout()
        button_groupbox = QtGui.QGroupBox()
        button_groupbox.setStyleSheet("QGroupBox{Background-color: %s; border: 1px solid %s}" % (self.controller.widget_color, 
                self.controller.border_color)) 
        grid = QtGui.QVBoxLayout()
        for w in self.controls:
            control_layout.addWidget(self.controls[w], 0)

        n = 0
        background_widget = QtGui.QLabel('')
        background_widget.setMinimumHeight(20)
        background_widget.setMinimumWidth(200)
        params = (self.controller.widget_color, 
                self.controller.widget_border_length, 
                self.controller.border_color, 
                self.controller.widget_border_length, 
                self.controller.border_color, 
                self.controller.widget_border_length, 
                self.controller.border_color)

        background_widget.setStyleSheet("QLabel{Background-color: %s; border-bottom: %dpx solid %s; border-left: %dpx solid %s;  border-right: %dpx solid %s}" % params) 

        control_layout.addWidget(background_widget)

        for b in self.buttons:

            grid.addWidget(b)
        button_groupbox.setLayout(grid)
        button_layout.addWidget(button_groupbox)
        main_layout.addLayout(control_layout)
        main_layout.addLayout(button_layout)
        self.setLayout(main_layout)

    def connect_controls(self):
        def change_shown_window(button):
            button_text = button.text()
            if button_text == 'PEAK \n SEARCH':
                self.controller.apply_tab_options(selected_marker_tab = 'Pk Search')
                keep_goin = True
                for m in self._marker_state:
                    if keep_goin:
                        if m >= 0:
                            if self._marker_state[m]['enabled'] and m == self._marker_state[-1]['selected_marker']:
                                self.controller.apply_marker_options(m, ['peak'], [None])
                                keep_goin = False
                if keep_goin:
                   for m in self._marker_state:
                        if m >= 0:
                            if not self._marker_state[m]['enabled']:
                                self.controller.apply_marker_options(m, ['type', 'enabled'], ['Normal', True])
                                self.controller.apply_marker_options(m, ['peak'], [None])
                                self.controller.apply_marker_options(-1, ['selected_marker'], [m])
                                break
            elif button_text == 'MARKER':
                self.controller.apply_tab_options(selected_marker_tab = 'Mkr')
            for s in self.window_state:
                if s == BUTTON_NAMES_TO_WIDGET[button_text]:
                    self.window_state[s] = True
                else:
                    self.window_state[s] = False
                self.controller.apply_window_options(**self.window_state)

        self.buttons[0].clicked.connect(lambda: change_shown_window(self.buttons[0]))
        self.buttons[1].clicked.connect(lambda: change_shown_window(self.buttons[1]))
        self.buttons[2].clicked.connect(lambda: change_shown_window(self.buttons[2]))
        self.buttons[3].clicked.connect(lambda: change_shown_window(self.buttons[3]))
        self.buttons[4].clicked.connect(lambda: change_shown_window(self.buttons[4]))
        self.buttons[5].clicked.connect(lambda: change_shown_window(self.buttons[5]))
        self.buttons[6].clicked.connect(lambda: change_shown_window(self.buttons[6]))
        self.buttons[7].clicked.connect(lambda: change_shown_window(self.buttons[7]))
        self.buttons[8].clicked.connect(lambda: change_shown_window(self.buttons[8]))
        self.buttons[9].clicked.connect(lambda: change_shown_window(self.buttons[9]))
        self.buttons[10].clicked.connect(lambda: change_shown_window(self.buttons[10]))
        self.buttons[11].clicked.connect(lambda: change_shown_window(self.buttons[11]))
        self.buttons[12].clicked.connect(lambda: change_shown_window(self.buttons[12]))

    def _prep_button(self, button):
        button.setMinimumHeight(50)
        font = QtGui.QFont()
        if button.text() == 'PRESET':
            button.setLabelStyleSheet("QLabel{background: %s; border-radius: 10px;color: %s; font-size: 14px}" % (self.controller.preset_color, self.controller.button_text_color))
        else:
            button.setLabelStyleSheet("QLabel{background: %s; border-radius: 10px; border-color: %s; border-top: 1px solid;border-left: 1px solid; border-right: 1px solid; color: %s; font-size: 14px}" % (self.controller.label_color, 
                                                                                                self.controller.label_color, 
                                                                                                self.controller.button_text_color))

    def marker_changed(self, marker, state, changed):
        self._marker_state = state

    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def window_changed(self, state, changed):
        self.window_state = state
        for s in state:
                self.controls[s].setVisible(state[s])

    def moveEvent(self, event):
        self.controller.apply_app_options(num_entry_x = self.mapToGlobal(self.pos()).x())

    def state_changed(self, state, changed):
        self.gui_state = state
    
    def plot_changed(self, state, changed):
        self.plot_state = state
        
    def app_changed(self, state, changed):
        if 'window_moved' in changed:
            self.controller.apply_app_options(num_entry_x = self.mapToGlobal(self.pos()).x())