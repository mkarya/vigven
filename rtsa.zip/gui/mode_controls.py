from PySide import QtGui, QtCore

from pyrf.units import M
import colors
from fonts import GROUP_BOX_FONT
from util import clear_layout
from widgets import QCheckBoxPlayback, QDoubleSpinBoxPlayback, QComboBoxPlayback, ValueEditWidget
from util import (create_item_label,
                create_title_label, 
                change_widget_background, 
                initialize_groupbox_stylesheet, 
                initialize_group_box, clear_layout, set_button_color, hide_layout)

MEASUREMENT_MODES = ['Swept SA', 'Channel Power']
TEXT_TO_MODE = {'Swept SA': 'Analyzer',
                'Channel Power': 'Channel Power'}
                
MODE_TO_TEXT = {'Analyzer': 'Swept SA',
                'Channel Power': 'Channel Power'}

CAPTURE_MODES = ['Spectrum Analyzer', 'RTSA']
class ModeControls(QtGui.QGroupBox):

    def __init__(self, controller):
        super(ModeControls, self).__init__()

        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        controller.app_change.connect(self.app_changed)
        self._create_controls()
        self.setLayout(QtGui.QGridLayout())
        self._build_layout()
        self._connect_controls()

    def _create_controls(self):
        # control the capture mode
        self._capture_widget, grid = initialize_group_box(self.controller)
        grid.setContentsMargins(25,0,10,0)
        capture_label = create_item_label(' Mode')
        self._capture_mode = QComboBoxPlayback()
        self._capture_mode.quiet_update(CAPTURE_MODES, CAPTURE_MODES[0])
        self._capture_mode.setToolTip("Select the measurement mode of the device")
        grid.addWidget(capture_label)
        grid.addWidget(self._capture_mode)
        self._capture_widget.setLayout(grid)

        # control the measurement mode
        self._measurement_widget, grid = initialize_group_box(self.controller)
        grid.setContentsMargins(25,0,10,0)
        measurement_label = create_item_label('Measurement')
        self._measurement_mode = QComboBoxPlayback()
        self._measurement_mode.quiet_update(MEASUREMENT_MODES, MEASUREMENT_MODES[0])
        self._measurement_mode.setToolTip("Select the measurement mode of the device")
        grid.addWidget(measurement_label)
        grid.addWidget(self._measurement_mode)
        self._measurement_widget.setLayout(grid)

    def _build_layout(self):
        grid = self.layout()
        grid.setContentsMargins(0,0, 0,0)
        initialize_groupbox_stylesheet(self, self.controller)
        clear_layout(grid)
        title_label = create_title_label('MODE MEAS', self.controller)
        row = 0
        grid.addWidget(title_label, row, 0, 1,8)
        row += 1
        grid.addWidget(self._capture_widget, row, 0, 1,8)
        
        row += 1
        grid.addWidget(self._measurement_widget, row, 0, 1,8)
        self.resize_widget()

    def _connect_controls(self):
        
        def enable_channel_power():
            if self._measurement_mode.currentText() == 'Channel Power':
                self.controller.apply_app_options(measurement_mode = 'Channel Power')
                self.controller.apply_plot_options(channel_power = True)
            else:
                self.controller.apply_app_options(measurement_mode = 'Analyzer')
                self.controller.apply_plot_options(channel_power = False)

        def change_capture_mode():
            if self._capture_mode.currentText() == 'Spectrum Analyzer':
                self.controller.apply_app_options(capture_mode = 'Spectrum Analyzer')
            else:
                self.controller.apply_app_options(capture_mode = 'RTSA')
                self.controller.apply_plot_options(channel_power = False)
        self._capture_mode.currentIndexChanged.connect(change_capture_mode)
        self._measurement_mode.currentIndexChanged.connect(enable_channel_power)

    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def app_changed(self, state, changed):
        self.app_state = state

        if 'measurement_mode' in changed:

            self._measurement_mode.quiet_update(select_item = MODE_TO_TEXT[state['measurement_mode']])
        
        if 'capture_mode' in changed:
            self._capture_mode.quiet_update(select_item = state['capture_mode'])
            if state['capture_mode'] == 'Spectrum Analyzer':
                self._measurement_widget.setEnabled(True)
            elif state['capture_mode'] == 'RTSA':
                self._measurement_widget.setEnabled(False)

    def state_changed(self, state, changed):
        self.gui_state = state
        if 'device_settings.iq_output_path' in changed:
            if state.device_settings['iq_output_path'] == 'CONNECTOR':
                self._measurement_mode.setEnabled(False)
            elif state.device_settings['iq_output_path'] == 'DIGITIZER':
                self._measurement_mode.setEnabled(True)

    def plot_changed(self, state, changed):
        self.plot_state = state

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)

    def showEvent(self, event):
        self.activateWindow()