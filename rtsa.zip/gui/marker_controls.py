from collections import namedtuple
from PySide import QtGui, QtCore
import numpy as np

from pyrf.units import M
import colors, fonts
from widgets import (QComboBoxPlayback, 
                QDoubleSpinBoxPlayback, 
                QCheckBoxWidget, 
                 QButtonTabs,
                 ValueEditWidget,
                 QPushLabelPlayback,
                 QTabWidgetPlayback)

from fonts import GROUP_BOX_FONT, HIGHLIGHTED_MARKER_LABEL
from labels import MARKERS, TRACES
from util import (create_item_label,
                create_title_label, 
                change_widget_background, 
                initialize_groupbox_stylesheet, 
                initialize_group_box, 
                clear_layout, 
                set_button_color, 
                hide_layout, 
                update_button,
                format_frequency_text)
from gui_config import MarkerState, TraceState, TabState
BUTTON_WIDTH = 65

UNITS = ['GHz', 'MHz', 'kHz', 'Hz']
UNIT_MAGNITUDE = {'GHz': 1e9,
                  'MHz': 1e6,
                  'kHz': 1e3,
                  'Hz': 1}
UNIT_DECIMAL = {'GHz': 11,
                  'MHz': 8,
                  'kHz': 5,
                  'Hz': 2}

class MarkerControls(QtGui.QGroupBox):

    def __init__(self, controller):
        super(MarkerControls, self).__init__()

        # connect controller controls
        self.controller = controller
        controller.marker_change.connect(self.marker_changed)
        controller.trace_change.connect(self.trace_changed)
        controller.plot_change.connect(self.plot_changed)
        controller.tab_change.connect(self.tab_changed)
        controller.app_change.connect(self.app_changed)
        # initialize preset states
        self._marker_state = MarkerState().state
        self._trace_state = TraceState().state
        self.setLayout(QtGui.QGridLayout())
        self._create_controls()
        self._connect_controls()
        self.resize_widget()

    def _create_controls(self):
        grid = self.layout()
        grid.setContentsMargins(0,0, 0,0)
        initialize_groupbox_stylesheet(self, self.controller)
        self._marker_widgets = []
        title_label = create_title_label('MARKER', self.controller)
        # declare marker number tabs
        self.button_tabs = QButtonTabs(self.controller, 2,len(MARKERS) / 2)

        # create controls tab
        self._control_tab = QTabWidgetPlayback()
        self._control_tab.setUsesScrollButtons(False)
        self._control_tab.addTab(QtGui.QWidget(), 'Mkr')
        self._control_tab.addTab(QtGui.QWidget(), 'Pk Search')
        self._control_tab.addTab(QtGui.QWidget(), 'Pk Config')
        self._control_tab.setUsesScrollButtons(False)

        # color button for annotation 
        self._color_button = QtGui.QPushButton()
        self._update_button_color(colors.PLOT_LABEL)

        # mouse annotation (developer mode only)
        self._mouse_label = QCheckBoxWidget("Display Annotations")
        self._mouse_label.setToolTip("Display label indicating current mouse position")

        # mouse table control
        self.table_widget, grid = initialize_group_box(self.controller)
        grid.setContentsMargins(10,10,10,10)
        self._marker_table = QCheckBoxWidget("Marker Table On")
        self._marker_table.setToolTip("Display The marker table")
        grid.addWidget(self._marker_table)
        self.table_widget.setLayout(grid)   

        # create button to clear markers
        self.clear_widget, grid = initialize_group_box(self.controller)
        self._clear_markers = QPushLabelPlayback('All Markers Off')
        update_button(self._clear_markers, self.controller)
        grid.addWidget(self._clear_markers)
        self.clear_widget.setLayout(grid)

        grid = self.layout()
        grid.setContentsMargins(0,0, 0,0)

        row = 0
        grid.addWidget(title_label, 0, 0, 1, 8)
        row += 1
        grid.addWidget(self._control_tab, row, 0, 1, 8)
        row += 1
        grid.addWidget(self.button_tabs, row, 0, 1, 8)
        row += 1
        # add a new marker widget for each marker
        for m in MARKERS:
            widget = MarkerWidget(self.controller, m)
            if not m == 0:
                widget.hide()
            self._marker_widgets.append(widget)
            grid.addWidget(self._marker_widgets[m], row, 0, 1, 8)
        row += 1
        grid.addWidget(self.table_widget, row, 0, 1, 8)
        row += 1
        grid.addWidget(self.clear_widget, row, 0, 1, 8)
        row += 1
        # only turn on marker annotations if in developer mode
        if self.controller.developer_mode:
            grid.addWidget(self._color_button, row, 0, 1, 1)
            grid.addWidget(self._mouse_label, row, 1, 1, 1)
            row += 1
        self.resize_widget()

    def _connect_controls(self):
        # connect control changes to controler
        def enable_mouse_label():
            self.controller.apply_plot_options(mouse_label = self._mouse_label.isChecked())

        def enable_marker_table():
            self.controller.apply_marker_options(-1, ['show_table'], [self._marker_table.isChecked()])
            
        def custom_color_clicked():
            color = QtGui.QColorDialog.getColor()
            if not (color.red(), color.green(), color.blue()) == colors.BLACK_NUM:
                color = (color.red(), color.green(), color.blue(), colors.PLOT_LABEL[3])
                self._update_button_color(color)
                self.controller.apply_plot_options(mouse_label_color=color)
        def control_tab_changed():
            text = self._control_tab.tabText(self._control_tab.currentIndex())
            self.controller.apply_tab_options(selected_marker_tab=text)

        def clear_markers_clicked():
            self.controller.preset_markers()
            self.controller.apply_marker_options(-1, ['show_table'], [False])

        self._control_tab.currentChanged.connect(control_tab_changed)
        self._mouse_label.clicked.connect(enable_mouse_label)
        self._marker_table.clicked.connect(enable_marker_table)
        self._color_button.clicked.connect(custom_color_clicked)
        self._clear_markers.clicked.connect(clear_markers_clicked)

    def _update_button_color(self, mouse_color):
            button_icon = QtGui.QIcon()
            color = QtGui.QColor()
            color.setRgb(mouse_color[0], mouse_color[1], mouse_color[2])
            pixmap = QtGui.QPixmap(50, 50)
            pixmap.fill(color)
            button_icon.addPixmap(pixmap)
            self._color_button.setIcon(button_icon)
    
    def plot_changed(self, state, changed):
        if 'mouse_label' in changed:
            self._mouse_label.setChecked(state['mouse_label'])
    
    def app_changed(self, state, changed):
        self.app_state = state
        if 'measurement_mode' in changed:
            # disable marker table if in channel power mode
            if state['measurement_mode'] == 'Channel Power':
                self._marker_table.quiet_update(False)
                self.table_widget.hide()
                self._marker_table.hide()
            else:
                self.table_widget.show()
                self._marker_table.show()
        
    def marker_changed(self, marker, state, changed):
        self._marker_state = state
        # if a config has changed
        if marker == -1:

            # change tab position if changed
            if 'selected_marker' in changed:
                for m in self._marker_widgets:
                    if m.name == state[marker]['selected_marker']:
                        m.show()
                    else:
                        m.hide()
            if 'show_table' in changed:
                self._marker_table.quiet_update(state[marker]['show_table'])

    def trace_changed(self, trace, state, changed):
        self._trace_state = state

    def tab_changed(self, state, changed):
        self._tab_state = state
        if 'selected_marker_tab' in changed:
            if 'Mkr' in state['selected_marker_tab']:
                self._control_tab.quiet_tab(0)
                self.table_widget.show()
                self.clear_widget.show()
                self.button_tabs.show()
            else:
                self.table_widget.hide()
                self.clear_widget.hide()
                
            if 'Search' in state['selected_marker_tab']:
                self._control_tab.quiet_tab(1)
                self.button_tabs.show()
            if'Config' in state['selected_marker_tab']:
                self._control_tab.quiet_tab(2)
                self.button_tabs.hide()

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)

    def showEvent(self, event):
        self.activateWindow()

class MarkerWidget(QtGui.QWidget):
    def __init__(self, controller, name):
        super(MarkerWidget, self).__init__()
        self.name = name

        # connect controller signals
        self.controller = controller
        controller.marker_change.connect(self.marker_changed)
        controller.trace_change.connect(self.trace_changed)
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.tab_change.connect(self.tab_changed)
        # initialize states
        self._marker_state = MarkerState().state
        self._trace_state = TraceState().state
        self._tab_state = TabState().state
        self.create_controls()
        self.setLayout(QtGui.QGridLayout())
        palette = QtGui.QPalette()
        color = QtGui.QColor()
        color.setRgb(self.controller.widget_color_num[0], 
                     self.controller.widget_color_num[1], 
                     self.controller.widget_color_num[2])
        palette.setColor(QtGui.QPalette.Background, color)
        self.setAutoFillBackground(True)
        self.setPalette(palette)
        
        self._build_layout()

    def create_controls(self):

        # create marker frequency input
        self.freq_widget, grid = initialize_group_box(self.controller)
        self.freq = ValueEditWidget(self.controller, 
                                        'Marker Frequency', 
                                        val_unit = 'Hz', 
                                        current_unit = 'MHz',
                                        step =  M,
                                        allow_step_change = False)
        freq_label = create_item_label('Marker Frequency')
        def freq_change():
            factor = UNIT_MAGNITUDE[self._marker_state[self.name]['unit']]
            unit = self.freq.getUnit()
            if 'Delta' in self._marker_state[self.name]['type']:
                delta_marker = int(self._marker_state[self.name]['type'][-1]) - 1
                new_freq = self._marker_state[delta_marker]['freq'] + (self.freq.value)
            else:
                new_freq = self.freq.value
                fstart = self._gui_state.center - (self._gui_state.span / 2)
                fstop = self._gui_state.center + (self._gui_state.span / 2)
                if new_freq < fstart:
                    new_freq = fstart
                elif new_freq > fstop:
                    new_freq = fstop
            self.controller.apply_marker_options(self.name, ['freq', 'unit'], [new_freq, unit])
            self.controller.apply_marker_options(self.name, ['reset_peaks'], [None])
        self.freq.value_changed.connect(freq_change)
        grid.addWidget(freq_label)
        grid.addWidget(self.freq)
        self.freq_widget.setLayout(grid)

        # marker type (marker or delta)
        self.mode_widget, grid = initialize_group_box(self.controller)
        self.marker_type = QComboBoxPlayback()
        mode_label = create_item_label('Marker Mode')
        self.marker_type.quiet_update(['Off, Normal, Fixed'], 'Off')
        def change_type():
            self.controller.apply_marker_options(self.name, ['type'], [self.marker_type.currentText()])
            # if marker is turned off
            if self.marker_type.currentText() == 'Off':
                self.controller.apply_marker_options(self.name, ['enabled'], [False])
                # turn off deltas as well
                for m in self._marker_state:
                    if m >= 0:
                        if str(self.name) in self._marker_state[m]['type']:
                            self.controller.apply_marker_options(m, ['enabled'], [False])
            else:
                if not self._marker_state[self.name]['enabled']:
                    self.controller.apply_marker_options(self.name, ['enabled'], [True])
                
        self.marker_type.currentIndexChanged.connect(change_type)
        grid.addWidget(mode_label)
        grid.addWidget(self.marker_type)
        self.mode_widget.setLayout(grid)

        # create marker trace combo
        self.trace_widget, grid = initialize_group_box(self.controller)
        trace_label = create_item_label('Marker Trace')
        self.trace = QComboBoxPlayback()
        self.trace.quiet_update_pixel(colors.TRACE_COLORS, TRACES)
        def new_trace():
            self.controller.apply_marker_options(self.name, ['trace'], [int(self.trace.currentText()) - 1])
        self.trace.currentIndexChanged.connect(new_trace)
        grid.addWidget(trace_label)
        grid.addWidget(self.trace)
        self.trace_widget.setLayout(grid)

        # create power input for fixed markers
        self.power_widget, grid = initialize_group_box(self.controller)
        power_label = create_item_label('Marker Power')
        self.power = ValueEditWidget(self.controller, 
                                        'Marker Power Level', 
                                        val_unit = 'dBm', 
                                        current_unit = 'dBm',
                                        step = 1.0)
        self.power.quiet_update(-2000, 2000)
        def power_change():
            self.controller.apply_marker_options(self.name, ['power'], [self.power.value])
        self.power.value_changed.connect(power_change)
        grid.addWidget(power_label)
        grid.addWidget(self.power)
        self.power_widget.setLayout(grid)

        # marker peak
        self.peak = QPushLabelPlayback('Peak Search')
        update_button(self.peak, self.controller)
        def find_peak():
            self.controller.apply_marker_options(self.name, ['peak'], [True])
        self.peak.clicked.connect(find_peak)

        # next peak marker
        self.next_peak = QPushLabelPlayback('Next Peak')
        update_button(self.next_peak, self.controller)
        def find_next_peak():
            self.controller.apply_marker_options(self.name, ['next_peak'], [True])
        self.next_peak.clicked.connect(find_next_peak)

        # marker peak left
        self.peak_left = QPushLabelPlayback('Next Peak Left')
        update_button(self.peak_left, self.controller)
        def find_left_peak():
            self.controller.apply_marker_options(self.name, ['peak_left'], [True])
        self.peak_left.clicked.connect(find_left_peak)

        # marker peak right
        self.peak_right = QPushLabelPlayback('Next Peak Right')
        update_button(self.peak_right, self.controller)

        def find_right_peak():
            self.controller.apply_marker_options(self.name, ['peak_right'], [True])
        self.peak_right.clicked.connect(find_right_peak)

        # marker point left
        self.point_left = QPushLabelPlayback('Next Point Left')
        update_button(self.point_left, self.controller)

        def find_point_left():
            self.controller.apply_marker_options(self.name, ['point_left'], [True])
        self.point_left.clicked.connect(find_point_left)

        # marker point right
        self.point_right = QPushLabelPlayback('Next Point Right')
        update_button(self.point_right, self.controller)

        def find_point_right():
            self.controller.apply_marker_options(self.name, ['point_right'], [True])
        self.point_right.clicked.connect(find_point_right)

        # center to marker
        self.center = QPushLabelPlayback('Marker -> Center')
        update_button(self.center, self.controller)

        def center_marker():
            self.controller.apply_settings(center = self._marker_state[self.name]['freq'])
        self.center.clicked.connect(center_marker)
        
        # reflevel to marker
        self.reflevel = QPushLabelPlayback('Marker -> Ref Lvl')
        update_button(self.reflevel, self.controller)

        def reflevel_marker():
            self.controller.apply_plot_options(ref_level = self._marker_state[self.name]['power'])
        self.reflevel.clicked.connect(reflevel_marker)
        
        # marker to start
        self.marker_start = QPushLabelPlayback('Marker -> Start')
        update_button(self.marker_start, self.controller)
        def marker_to_start():
            fstart = self._marker_state[self.name]['freq']
            fstop = self._gui_state.center + (self._gui_state.span / 2)
            fstop = float(max(fstop, fstart + self.dut_prop.TUNING_RESOLUTION))
            if fstart < fstop:
                self.controller.apply_settings(
                    center = (fstop + fstart) / 2.0,
                    span = (fstop - fstart),
                    )
        self.marker_start.clicked.connect(marker_to_start)
        # marker to stop
        self.marker_stop = QPushLabelPlayback('Marker -> Stop')
        update_button(self.marker_stop, self.controller)

        def marker_to_stop():
            fstop = self._marker_state[self.name]['freq']
            fstart = self._gui_state.center - (self._gui_state.span / 2)
            if fstart < fstop:
                self.controller.apply_settings(
                    center = (fstop + fstart) / 2.0,
                    span = (fstop - fstart),
                    )
        self.marker_stop.clicked.connect(marker_to_stop)

        # add delta
        self.add_delta = QPushLabelPlayback('Marker Delta')
        update_button(self.add_delta, self.controller)

        def add_delta_mrk():
            # dont add delta if current marker is off
            if  not self._marker_state[self.name]['enabled']:
                return

            ref_marker = self._marker_state[self.name]['ref_marker']
            if self._marker_state[ref_marker]['enabled'] and ('Delta' in self._marker_state[ref_marker]['type']):
                for m in self._marker_state:
                    if m > 0:
                        if not self._marker_state[m]['enabled'] and not ('Delta' in self._marker_state[m]['type']):
                            ref_marker = m
                            break
            if not self._marker_state[ref_marker]['enabled']:
                self.controller.apply_marker_options(ref_marker, ['enabled'], [True])
            marker_type = 'Fixed'
            marker_freq = self._marker_state[self.name]['freq']
            marker_power = self._marker_state[self.name]['power']
            self.controller.apply_marker_options(ref_marker, ['type', 'freq', 'power'], [marker_type, marker_freq, marker_power])
            self.controller.apply_marker_options(self.name, ['type'], ['Delta %d' % (ref_marker + 1)])

        self.add_delta.clicked.connect(add_delta_mrk)

        # contineous peak
        self.cont_widget, grid = initialize_group_box(self.controller)
        self.cont_peak = QCheckBoxWidget('Continuous Peak')
        def cont_peak():
            self.controller.apply_marker_options(self.name, ['cont_peak'], [self.cont_peak.isChecked()])
        self.cont_peak.clicked.connect(cont_peak)
        grid.addWidget(self.cont_peak)
        self.cont_widget.setLayout(grid)

        # peak threshold
        self.threshold_widget, grid = initialize_group_box(self.controller)

        self.thrshold_value = ValueEditWidget(self.controller, 
                                        'Peak Threshold', 
                                        val_unit = 'dBm', 
                                        current_unit = 'dBm',
                                        step = 1.0)
        self.thrshold_value.quiet_update(-200, 30, self._marker_state[-1]['thrshold_val'])
        self.thrshold_value.setEnabled(False)
        def thrshold_value():
            self.controller.apply_marker_options(-1, ['thrshold_val'], [self.thrshold_value.value])
        self.thrshold_value.value_changed.connect(thrshold_value)

        self.peak_thrshold = QCheckBoxWidget('Pk Threshold On')
        def peak_thrshold():
            self.controller.apply_marker_options(-1, ['peak_thrshold'], [self.peak_thrshold.isChecked()])
        self.peak_thrshold.clicked.connect(peak_thrshold)
        
        self.peak_thrshold_line = QCheckBoxWidget('Pk Threshold Line On')
        def peak_thrshold():
            self.controller.apply_plot_options(thrshold_line = self.peak_thrshold_line.isChecked())
        self.peak_thrshold_line.clicked.connect(peak_thrshold)
        grid.addWidget(self.peak_thrshold)
        grid.addWidget(self.thrshold_value)
        grid.addWidget(self.peak_thrshold_line)
        self.threshold_widget.setLayout(grid)

        # peak excursion
        self.excursion_widget, grid = initialize_group_box(self.controller)
        self.exc_value = ValueEditWidget(self.controller, 
                                        'Peak Excursion', 
                                        val_unit = 'dB', 
                                        current_unit = 'dB',
                                        step = 1.0)
        self.exc_value.quiet_update(0, 100, self._marker_state[-1]['exc_val'])
        self.exc_value.setEnabled(False)
        self.peak_exc = QCheckBoxWidget('Pk Excursion On')
        def peak_exc():
            self.controller.apply_marker_options(-1, ['peak_exc'], [self.peak_exc.isChecked()])
        self.peak_exc.clicked.connect(peak_exc)
        def exc_value():
            self.controller.apply_marker_options(-1, ['exc_val'], [self.exc_value.value])
        self.exc_value.value_changed.connect(exc_value)
        grid.addWidget(self.peak_exc)
        grid.addWidget(self.exc_value)
        self.excursion_widget.setLayout(grid)

        # disable peak latch
        def disable_latch_click():
            self.controller.apply_marker_options(self.name, ['mouse_latch'], [self._peak_latch.isChecked()])
            self._build_layout()
        self._peak_latch = QCheckBoxWidget("Latch Marker to Peak")
        self._peak_latch.clicked.connect(disable_latch_click)

    def _build_layout(self):
        grid = self.layout()
        grid.setSpacing(0)
        hide_layout(grid)

        def show(widget, y, x, h, w):
            grid.addWidget(widget, y, x, h, w)
            widget.show()

        if 'Mkr' in self._tab_state['selected_marker_tab']:
            row = 0
            show(self.freq_widget, row, 0, 1, 1)
            row += 1
            show(self.power_widget, row, 0, 1, 1)
            row += 1
            show(self.mode_widget, row, 0, 1, 1)
            row += 2
            show(self.trace_widget, row, 0, 1, 1)
            row += 1
            show(self.add_delta, row, 0, 1, 2)
            row += 1

        elif 'Search' in self._tab_state['selected_marker_tab']:
            row = 0
            show(self.freq_widget, row, 0, 2, 2)
            row += 3
            show(self.power_widget, row, 0, 2, 2)
            row += 3
            show(self.peak, row, 0, 1, 2)
            row += 1

            show(self.next_peak, row, 0, 1, 2)
            row += 1

            show(self.peak_left, row, 0, 1, 2)
            row += 1

            show(self.peak_right,  row, 0, 1, 2)
            row += 1

            show(self.point_left, row, 0, 1, 2)
            row += 1

            show(self.point_right,  row, 0, 1, 2)
            row += 1

            show(self.add_delta, row, 0, 1, 2)
            row += 1

            show(self.center,  row, 0, 1, 2)
            row += 1
            
            show(self.reflevel,  row, 0, 1, 2)
            row += 1
            # show(self.marker_start, row, 0, 1, 2)
            # row += 1
            # show(self.marker_stop,  row, 0, 1, 2)
            # row += 1
            show(self.cont_widget,  row, 0, 1, 2)

        elif 'Config' in self._tab_state['selected_marker_tab']:
            row = 0
            show(self.threshold_widget,  row, 0, 1, 1)
            row += 1
            show(self.excursion_widget,  row, 0, 1, 1)


        self.resize_widget()
    def _update_layout(self):
        state = self._marker_state[self.name]
        
        if state['enabled']:
            self.mode_widget.setEnabled(True)
            self.trace_widget.setEnabled(True)
            self.freq_widget.setEnabled(True)
            self.power_widget.setEnabled(True)
        else:
            self.mode_widget.setEnabled(True)
            self.trace_widget.setEnabled(False)
            self.freq_widget.setEnabled(False)
            self.power_widget.setEnabled(False)
            return
    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def state_changed(self, state, changed):
        self._gui_state = state
        
        if 'span' in changed or 'center' in changed:
            self._update_freq_range()

    def tab_changed(self, state, changed):
        self._tab_state = state
        if 'selected_marker_tab' in changed:
            self._build_layout()

    def _update_freq_range(self):
    # update the range of the frequency spinbox
        if 'Delta' in self._marker_state[self.name]['type']:
            fstart = (-1 * self._gui_state.span)
            fstop = self._gui_state.span 
        else:
            
            fstart = self._gui_state.center - (self._gui_state.span / 2)
            fstop = self._gui_state.center + (self._gui_state.span / 2)

        self.freq.quiet_update( fstart, fstop)

    def _update_freq_value(self):
    # update the value of the frequency spinbox
        if 'Delta' in self._marker_state[self.name]['type']:
            delta_marker = int(self._marker_state[self.name]['type'][-1]) - 1
            freq_val = (self._marker_state[self.name]['freq'] - self._marker_state[delta_marker]['freq'])
        else:
            freq_val = self._marker_state[self.name]['freq']
        self.freq.quiet_update(value = freq_val)

    def marker_changed(self, marker, state, changed):
        self._marker_state = state
        marker_states = ['Off', 'Normal', 'Fixed']
        for m in state:
            if m >= 0 and m != self.name:
                if state[m]['enabled'] and state[m]['type'] in ['Normal', 'Fixed']:
                    marker_states.append(u'Delta %d' % (m + 1))

        if 'enabled' in changed or 'type' in changed:
            
            self.marker_type.quiet_update(marker_states, state[self.name]['type'])
            self._update_freq_range()
            self._update_freq_value()

        if marker == self.name:
            if state[marker]['type'] == 'Fixed':
                self.power.setEnabled(True)
            else:
                self.power.setEnabled(False)
            factor = UNIT_MAGNITUDE[state[marker]['unit']]

            if 'enabled' in changed:
                self._update_layout()
            if 'freq' in changed:
                if state[marker]['freq'] is not None:
                    self._update_freq_value()
            if 'power' in changed:
                self.power.quiet_update(value = state[marker]['power'])
            if 'unit' in changed:
                fstart = self._gui_state.center - (self._gui_state.span / 2)
                fstop = self._gui_state.center + (self._gui_state.span / 2)
                self._update_freq_range()
                self._update_freq_value()
            if 'cont_peak' in changed:
                self.cont_peak.quiet_update(state[marker]['cont_peak'])
        elif marker == -1:

            if 'all_delta' in changed:
                self.marker_type.setEnabled( not state[-1]['all_delta'])
            
            if 'peak_thrshold' in changed:
                self.thrshold_value.setEnabled(state[-1]['peak_thrshold'])
                self.peak_thrshold_line.setEnabled(state[-1]['peak_thrshold'])
            if 'peak_exc' in changed:
                self.peak_exc.quiet_update(state[-1]['peak_exc'])
                self.exc_value.setEnabled(state[-1]['peak_exc'])
            
            if 'thrshold_val' in changed:
                self.peak_thrshold.quiet_update(state[-1]['peak_thrshold'])
                self.thrshold_value.quiet_update(value = state[-1]['thrshold_val'])
            
            if 'exc_val' in changed:
                self.exc_value.quiet_update(value = state[-1]['exc_val'])

    def trace_changed(self, trace, state, changed):
        self._trace_state = state
        
        for m in self._marker_state:
            if m >= 0:
                if self._marker_state[m]['trace'] == trace:
                    if 'mode' in changed:
                        # disable marker if trace is disabled
                        if state[trace]['mode'] == 'Off' and not self._marker_state[m]['type'] == 'Fixed':
                            self.controller.apply_marker_options(m, ['enabled'], [False])
        self._update_trace_combo()

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Minimum)

    def _update_trace_combo(self):
        available_colors = []
        trace_name = []
        for n, t in zip(TRACES, sorted(self._trace_state)):
            if t == -1:
                continue
            if not self._trace_state[t]['mode'] == 'Off':
                available_colors.append(self._trace_state[t]['color'])
                trace_name.append(n)
            index = self._marker_state[self.name]['trace']
            self.trace.quiet_update_pixel(available_colors, trace_name, index)
        self._build_layout()

class MarkerLabel(QtGui.QLabel):

    def __init__(self, controller):
        super(MarkerLabel, self).__init__()
        self._create_controls()
        self.controller = controller
        controller.marker_change.connect(self.marker_changed)
        controller.trace_change.connect(self.trace_changed)
        controller.state_change.connect(self.state_changed)
        self._marker_state = MarkerState().state
        self._trace_state = TraceState().state

    def _create_controls(self):
        self.setAlignment(QtCore.Qt.AlignRight)
        font = QtGui.QFont()
        font.setBold(True)
        font.setPixelSize(fonts.MARKER_LABEL_SIZE)
        self.setFont(font)

    def marker_changed(self, marker, state, changed):
        self._marker_state = state
        selected_marker = self._marker_state[-1]['selected_marker']

        if marker == selected_marker or 'selected_marker' in changed:
            
            if state[selected_marker]['enabled']:
                unit = state[selected_marker]['unit']
                factor = UNIT_MAGNITUDE[unit]
                decimals = "%" + "0.%df" % UNIT_DECIMAL[state[selected_marker]['unit']]
 
                if 'freq' in changed or 'power' in changed or 'selected_marker' in changed:
                    # grab marker color
                    color = self._trace_state[state[selected_marker]['trace']]['color']

                    # grab marker type
                    marker_type = state[selected_marker]['type']

                    # grab power and frequency
                    if 'list' in str(type(state[selected_marker]['freq'])):
                        marker_freq = decimals % (state[selected_marker]['freq'][0] / factor)
                    else:
                        marker_freq = decimals % (state[selected_marker]['freq'] / factor)
                    marker_power = state[selected_marker]['power']

                    # if delta, display delta values
                    if 'Delta' in marker_type:
                        pow_unit = 'dB'
                        if 'list' in str(type(state[selected_marker]['freq'])):
                            marker_freq = state[selected_marker]['freq'][0]
                        else:
                            marker_freq = state[selected_marker]['freq']
                        freq = (marker_freq - state[int(marker_type[-1]) - 1]['freq']) / factor
                        if marker_power is None or state[int(marker_type[-1]) - 1]['power'] is None:
                            power = None
                        else:
                            power =  '%0.2f' % (marker_power - state[int(marker_type[-1]) - 1]['power'])
      
                    else:
                        pow_unit = 'dBm'
                        freq = marker_freq
                        if marker_power is None:
                            power = None
                        else:
                            power = '%0.2f' % marker_power


                    freq_text = 'Mkr%s ' % str(selected_marker + 1)
                    freq_text = freq_text + format_frequency_text('%s %s' % (freq, unit))
                    if power is None:
                        power_text = '---'
                    else:
                        power_text = '%s %s' % (power, pow_unit)
                    full_text = ('%s \n    %s' % (freq_text, power_text))
                    self.setText(full_text)
                    self._update_label_colors(color)
            else:
                self.setText('')

    def _update_label_colors(self, color):
        self.setStyleSheet("QLabel {color : rgb(%d, %d, %d);}" % (color[0],
                                                                          color[1],
                                                                          color[2]))
    def state_changed(self, state, changed):
        if 'device_settings.iq_output_path' in changed:
            if state.device_settings['iq_output_path'] == 'CONNECTOR':
                self.setVisible(False)
            elif state.device_settings['iq_output_path'] == 'DIGITIZER':
                self.setVisible(True)

    def trace_changed(self, trace, state, changed):
        self._trace_state = state
