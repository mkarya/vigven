from PySide import QtGui, QtCore
from util import hide_layout
from fonts import GROUP_BOX_FONT
from gui_config import AppState
from widgets import QPushLabelPlayback, QCheckBoxWidget, QComboBoxPlayback, QDoubleSpinBoxPlayback, QTabWidgetPlayback, ValueEditWidget
from pyrf.units import M
import colors
from util import (update_button, 
                create_item_label,
                create_title_label, 
                change_widget_background, 
                initialize_groupbox_stylesheet, 
                initialize_group_box)

# FIXME: move to device properties?
MODE_TO_TEXT = {
    'Sweep SH': 'Sweep Normal',
    'Sweep SHN': 'Sweep Accuracy',
    'SH': '40 MHz span',
    'SHN': '10 MHz span',
    'Sweep ZIF': 'Sweep (100 MHz steps)',
    'ZIF': '100 MHz span',
    'HDR': '100 kHz span',
    'DD': 'Baseband',
    'IQIN': 'IQIN',
}
TRIGGER_MODES = ['Free Run', 'Level']
TEXT_TO_MODE = dict((m,t) for (t,m) in MODE_TO_TEXT.iteritems())

TRIGGER_TYPE_TEXT = {'NONE': 'Free Run',
                    'LEVEL': 'Level'}
class SweepControls(QtGui.QGroupBox):
    """
    A widget with a layout containing widgets that
    can be used to control the amplitude configurations of the GUI
    :param controller: A controller that emits/receives Qt signals from multiple widgets
    :param name: The name of the groupBox
    """

    def __init__(self, controller):
        super(SweepControls, self).__init__()

        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)

        grid = QtGui.QGridLayout()
        self.setLayout(QtGui.QGridLayout())
        self._build_layout()

    def _build_layout(self, dut_prop=None):

        grid = self.layout()
        
        grid.setContentsMargins(0,0, 0,0)
        initialize_groupbox_stylesheet(self, self.controller)

        title_label = create_title_label('SWEEP', self.controller)
        grid.addWidget(title_label, 0, 0, 1, 10)
        # create controls tab
        grid.addWidget(CaptureWidget(self.controller), 1, 0, 1, 10)
        self.setLayout(grid)
        self.resize_widget()

    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def state_changed(self, state, changed):
        self.gui_state = state

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)

class CaptureWidget(QtGui.QWidget):
    """
    A widget with the capture controls
    """
    def __init__(self, controller):
        super(CaptureWidget, self).__init__()
        self.app_state = AppState().state
        self.controller = controller
        controller.plot_change.connect(self.plot_changed)
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.app_change.connect(self.app_changed)

        grid = QtGui.QGridLayout()
        self.setLayout(QtGui.QGridLayout())

        self._build_layout()

    def _build_layout(self, dut_prop=None):

        grid = self.layout()

        # update background color
        palette = QtGui.QPalette()
        color = QtGui.QColor()
        color.setRgb(self.controller.widget_color_num[0], 
                     self.controller.widget_color_num[1], 
                     self.controller.widget_color_num[2])
        palette.setColor(QtGui.QPalette.Background, color)
        self.setAutoFillBackground(True)
        self.setPalette(palette)
        grid.addWidget(self._mode_controls(), 0, 0, 1, 2)
        grid.addWidget(self._capture_controls(), 1, 0, 1, 2)
        grid.addWidget(QtGui.QLabel(' '), 2, 0, 4, 2)

        self.setLayout(grid)
        self.resize_widget()

    def _mode_controls(self):
        widget, grid  = initialize_group_box(self.controller)
        self._mode_label = create_item_label('Sweep Type')
        self._mode = QComboBoxPlayback()
        self._mode.setToolTip("Change the device input mode")

        def new_input_mode():
            self._mode.showPopup()
            if not self._mode.currentText() in TEXT_TO_MODE:
                self._update_modes(current_mode = self.gui_state.mode)
                return
            input_mode = TEXT_TO_MODE[self._mode.currentText()]
            self.controller.apply_settings(mode=input_mode)
            #FIXME rfe_mode should not be in device settings dictionary
            if self.gui_state.device_settings['iq_output_path'] == 'CONNECTOR':
                self.controller.apply_device_settings(rfe_mode = input_mode)

        self._mode.currentIndexChanged.connect(new_input_mode)
        grid.addWidget(self._mode_label)
        grid.addWidget( self._mode)
        widget.setLayout(grid)
        return widget

    def _capture_controls(self):
        widget, grid  = initialize_group_box(self.controller)
        self._conts_box = QCheckBoxWidget("Continuous")
        self._conts_box.setChecked(True)
        self._single_button = QPushLabelPlayback('Single')
        update_button(self._single_button, self.controller)

        def single_capture():
            self.controller.apply_plot_options(cont_cap_mode = False)
            self.controller.start_capture(single = True)

        def cont_capture():
            self.controller.apply_plot_options(cont_cap_mode = self._conts_box.isChecked())
            if self._conts_box.isChecked():
                self.controller.start_capture(single = True)


        self._single_button.clicked.connect(single_capture)
        self._conts_box.clicked.connect(cont_capture)
        grid.addWidget(self._conts_box)
        grid.addWidget(self._single_button)
        widget.setLayout(grid)
        return widget

    def device_changed(self, dut):
        self.dut_prop = dut.properties
        self._update_modes()

    def state_changed(self, state, changed):
        self.gui_state = state
        if 'playback' in changed:
            # restore controls after playback is stopped
            self._update_modes(current_mode=state.mode)

        if state.playback:
            # for playback simply update on every state change
            self._mode.playback_value(MODE_TO_TEXT[state.mode])
        
        if 'device_settings.iq_output_path' in changed:
            if state.device_settings['iq_output_path'] == 'CONNECTOR':
                self._update_modes(include_sweep=False)

            elif state.device_settings['iq_output_path'] == 'DIGITIZER':
                self._update_modes()

        if 'mode' in changed:
            self._update_modes(current_mode = state.mode)

    def plot_changed(self, state, changed):
        if 'cont_cap_mode' in changed:
            if not state['cont_cap_mode']:
                if self._conts_box.isChecked():
                    self._conts_box.click()

    def app_changed(self, state, changed):
        self.app_state = state
        if 'capture_mode' in changed:
            if state['capture_mode'] == 'Spectrum Analyzer':

                self._update_modes(include_rtsa = False)
            else:
                self._update_modes(include_sweep=False)

    def _update_modes(self, include_sweep=True, include_rtsa = True, current_mode=None):
        modes = []
        if current_mode:
            current_mode = MODE_TO_TEXT[current_mode]
        if self.app_state['capture_mode'] == 'Spectrum Analyzer':
            modes.extend(self.dut_prop.SPECA_MODES)
            modes.append('HDR')
            modes.append('DD')
            if not self.controller.developer_mode:
                if 'Sweep ZIF' in modes:
                    modes.remove('Sweep ZIF')
            self._mode.quiet_update((MODE_TO_TEXT[m] for m in modes), 
                                    current_mode, 
                                    seperator = 2, 
                                    seperator_text = 'Advanced Modes')

        elif self.app_state['capture_mode'] == 'RTSA':
            modes.extend(self.dut_prop.RFE_MODES)
            modes.remove('HDR')
            modes.remove('DD')
            self._mode.quiet_update((MODE_TO_TEXT[m] for m in modes), current_mode, 
                                    seperator = 2, 
                                    seperator_text = 'Advanced Modes')
        self._mode.setEnabled(True)

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Minimum)
