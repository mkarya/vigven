from PySide import QtGui, QtCore
from util import hide_layout
from fonts import GROUP_BOX_FONT
from widgets import QClickLabel
from marker_controls import MarkerLabel
from pyrf.units import M
import colors

class statusBar(QtGui.QWidget):
    """
    A widget that contains all of the status labels
    can be used to control the amplitude configurations of the GUI
    :param controller: A controller that emits/receives Qt signals from multiple widgets
    """

    def __init__(self, controller):
        super(statusBar, self).__init__()

        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        grid = QtGui.QGridLayout()
        self.setLayout(QtGui.QGridLayout())
        self._build_layout()

    def _build_layout(self, dut_prop=None):
        self._scale_label = QClickLabel(self.controller, 'Scale / Div', 'Scale/Div', QtCore.Qt.AlignLeft)
        self._reflevel_label = QClickLabel(self.controller, 'Ref Level', 'Reference Level', QtCore.Qt.AlignLeft)
        self.marker_label = MarkerLabel(self.controller)
        grid = self.layout()
        grid.setContentsMargins(0,0, 0,0)
        grid.addWidget(self._scale_label, 0, 0, 1, 1)
        grid.addWidget(self._reflevel_label, 1, 0, 1, 1)
        grid.addWidget(self.marker_label, 0, 4, 2, 1)
        self.setLayout(grid)
        self.resize_widget()

    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def plot_changed(self, state, changed):
        self.plot_state = state
        if 'db_div' in changed:
            self._scale_label.setText('Scale / Div %d dB' % state['db_div'])
        if 'ref_level' in changed:
            self._reflevel_label.setText('Ref Level %d dBm' % state['ref_level'])

    def state_changed(self, state, changed):
        self.gui_state = state

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)
