
import colors
import labels
import util

PERSISTENCE_GRADIENT = [(0.00, ( 0, 0, 0, 255)),
                                  (0.15, (  0,   0, 255, 255)),
                                  (0.33, (  0, 255, 255, 255)),
                                  (0.66, (255, 255,   0, 255)),
                                  (1.00, (255,   0,   0, 255))]

WATERFALL_GRADIENT = [(0, ( 0, 0, 0, 255)),
                                  (0.3, (  0,   0, 255, 255)),
                                  (0.55, (  0, 255, 255, 255)),
                                  (0.66, (255, 255,   0, 255)),
                                  (0.75, (255,   0,   0, 255))]


class PlotState(object):
    def __init__(self):
        self.state = {'cont_cap_mode': True,
                      'mouse_tune': True,
                      'mouse_label': False,
                      'mouse_label_color': colors.PLOT_LABEL,
                      'mouse_pos': (0.0, 0.0),
                      'horizontal_cursor': False,
                      'horizontal_cursor_value': -100.0,
                      'channel_power': False,
                      'channel_power_region': (2400000000, 2500000000),
                      'ref_level': 0.0,
                      'db_div': 10.0,
                      'persist_ticks': PERSISTENCE_GRADIENT,
                      'waterfall_ticks': WATERFALL_GRADIENT,
                      'vbw': 1.0e6,
                      'vbw_auto': True,
                      'vbw_ratio': 1.0,
                      'rbw_auto': True,
                      'thrshold_line': False
                    }

class WindowOptions(object):
    def __init__(self):
        self.state = {'frequency_control': True,
                        'bw_control': False,
                        'measurement_control': False,
                        'marker_control': False,
                        'capture_control': False,
                        'amplitude_control': False,
                        'device_control': False,
                        'trace_control': False,
                        'preset_control': False,
                        'display_control': False,
                        'trigger_control': False,
                        'mode_control': False
                        }

class TabState(object):
    def __init__(self):
        self.state= {'selected_sweep_tab': 'Sweep',
                    'selected_marker_tab': 'Mkr'}

class MarkerState(object):
    def __init__(self):
        self.state = {}
        for m in labels.MARKERS:
            delta_ref = m + 1
            if m == 11:
                delta_ref = 0
            self.state[m] =  { 'enabled': False,
                                  'freq': 2450000000.0,
                                  'power': -60.0,
                                  'trace': labels.TRACES[0],
                                  'type': 'Off',
                                  'hovering': False,
                                  'tab': True,
                                  'center': None,
                                  'peak': False,
                                  'peak_left': False,
                                  'peak_right': False,
                                  'mouse_latch': False,
                                  'next_peak': False,
                                  'reset_peaks': None,
                                  'marker_start': None,
                                  'marker_stop': None,
                                  'point_right': None,
                                  'point_left': None,
                                  'cont_peak': False,
                                  'ref_marker': delta_ref,
                                  'unit': 'MHz'}

        # -1 holds the overall marker states
        self.state[-1] = {'show_table': False,
                           'selected_marker': 0,
                           'all_delta': False,
                           'peak_thrshold': False,
                           'thrshold_val': -90.0,
                           'peak_exc': False,
                           'exc_val': 6.0,}
class AppState(object):
    def __init__(self):
        self.state = {'measurement_mode':'Analyzer',
                    'capture_mode':'Spectrum Analyzer',
                    'app_click': None,
                    'click_location': None,
                    'wheel_up': None,
                    'wheel_down': None,
                    'active_num_control': None,
                    'fstep': 10e6,
                    'selected_trace_tab': 0,
                    'auto_atten': True,
                    'window_moved': None,
                    'num_entry_x': 0}

class TraceState(object):
    def __init__(self):
        self.state = {}
        self.state[-1] = {'average': 100.0}
        for t ,c  in zip(labels.TRACES, colors.TRACE_COLORS): 
            if t == labels.TRACES[0]:
                mode = 'Clear/Write'
            else:
                mode = 'Off'
            self.state[t] = {'color': c,
                            'pause': False,
                            'channel_power': 0.0,
                            'mode': mode,
                            'clear': 'None'}
                            
class warningState(object):
    def __init__(self):
        self.state = {'saturation': False}