from PySide import QtGui, QtCore
from util import hide_layout
from fonts import GROUP_BOX_FONT
from gui_config import AppState
from widgets import QPushLabelPlayback, QCheckBoxPlayback, QComboBoxPlayback, QDoubleSpinBoxPlayback, QTabWidgetPlayback, ValueEditWidget
from pyrf.units import M
import colors
from util import (update_button, 
                create_item_label,
                create_title_label, 
                change_widget_background, 
                initialize_groupbox_stylesheet, 
                initialize_group_box)


TRIGGER_MODES = ['Free Run', 'Level']

TRIGGER_TYPE_TEXT = {'NONE': 'Free Run',
                    'LEVEL': 'Level'}
class TriggerControls(QtGui.QGroupBox):
    """
    A widget with a layout containing widgets that
    can be used to control the amplitude configurations of the GUI
    :param name: A controller that emits/receives Qt signals from multiple widgets
    :param name: The name of the groupBox
    """

    def __init__(self, controller):
        super(TriggerControls, self).__init__()

        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        grid = QtGui.QGridLayout()
        self.setLayout(QtGui.QGridLayout())
        self._build_layout()

    def _build_layout(self, dut_prop=None):

        grid = self.layout()
        
        grid.setContentsMargins(0,0, 0,0)
        initialize_groupbox_stylesheet(self, self.controller)

        title_label = create_title_label('Trigger', self.controller)
        grid.addWidget(title_label, 0, 0, 1, 10)
        # create controls tab
        grid.addWidget(TriggerWidget(self.controller), 1, 0, 1, 10)
        self.setLayout(grid)
        self.resize_widget()

    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def state_changed(self, state, changed):
        self.gui_state = state

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)



class TriggerWidget(QtGui.QWidget):
    """
    A widget containing the trigger controls
    """

    def __init__(self, controller):
        super(TriggerWidget, self).__init__()

        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)

        grid = QtGui.QGridLayout()
        self.setLayout(QtGui.QGridLayout())

        self._build_layout()
        self._connect_capture_controls()


    def _build_layout(self, dut_prop=None):

        grid = self.layout()
        # update background color
        palette = QtGui.QPalette()
        color = QtGui.QColor()
        color.setRgb(self.controller.widget_color_num[0], 
                     self.controller.widget_color_num[1], 
                     self.controller.widget_color_num[2])
        palette.setColor(QtGui.QPalette.Background, color)
        self.setAutoFillBackground(True)
        self.setPalette(palette)

        grid.addWidget(self._trigger_mode_controls(), 0, 0, 1, 4)

        grid.addWidget(self._fstart_trigger_controls(), 1, 0, 1, 4)

        grid.addWidget(self._fstop_trigger_controls(), 2, 0, 1, 4)

        grid.addWidget(self._amp_trigger_controls(), 3, 0, 1, 4)
        self._trig_state(False)

        self.setLayout(grid)
        self.resize_widget()

    def _trigger_mode_controls(self):
        widget, grid  = initialize_group_box(self.controller)
        label = create_item_label('Trigger Source')

        self._trigger_mode = QComboBoxPlayback()
        self._trigger_mode.quiet_update(TRIGGER_MODES, TRIGGER_MODES[0])

        grid.addWidget(label)
        grid.addWidget(self._trigger_mode)
        widget.setLayout(grid)
        return widget

    def _fstart_trigger_controls(self):
        widget, grid  = initialize_group_box(self.controller)
        label = create_item_label("Trigger Start Frequency")
        self._trig_fstart = ValueEditWidget(self.controller, 
                                        'Trigger Start Frequency', 
                                        val_unit = 'Hz', 
                                        current_unit = 'MHz',
                                        step =  M,
                                        allow_step_change = False)
        
        grid.addWidget(label)
        grid.addWidget(self._trig_fstart)
        widget.setLayout(grid)
        return widget

    def _fstop_trigger_controls(self):
        widget, grid  = initialize_group_box(self.controller)
        label = create_item_label("Trigger Stop Frequency")
        self._trig_fstop = ValueEditWidget(self.controller, 
                                        'Trigger Stop Frequency', 
                                        val_unit = 'Hz', 
                                        current_unit = 'MHz',
                                        step = M,
                                        allow_step_change = False)
        grid.addWidget(label)
        grid.addWidget(self._trig_fstop)
        widget.setLayout(grid)
        return widget

    def _amp_trigger_controls(self):
        widget, grid  = initialize_group_box(self.controller)
        label = create_item_label("Trigger Level")
        self._trig_amp = ValueEditWidget(self.controller, 
                                        'Trigger Level', 
                                        val_unit = 'dBm', 
                                        current_unit = 'dBm',
                                        step = 1.0)
        grid.addWidget(label)
        grid.addWidget(self._trig_amp)
        widget.setLayout(grid)
        return widget
    def _connect_capture_controls(self):

        def change_trigger():
            trigger_settings = self.gui_state.device_settings['trigger']
            if self._trigger_mode.currentText() == 'Level':
                self._trig_state(True)

                start = self.gui_state.center - (self.gui_state.span / 4)
                stop = self.gui_state.center + (self.gui_state.span / 4)
                level = trigger_settings['amplitude']
                self.controller.apply_device_settings(trigger = {'type': 'LEVEL',
                                                                'fstart': start,
                                                                'fstop': stop,
                                                                'amplitude': trigger_settings['amplitude']})
            else:
                self.controller.apply_device_settings(trigger = {'type': 'NONE',
                                                                'fstart': trigger_settings['fstart'],
                                                                'fstop': trigger_settings['fstop'],
                                                                'amplitude': trigger_settings['amplitude']})
                self._trig_state(False)

        def new_trigger():
            self.controller.apply_device_settings(trigger = {'type': 'LEVEL',
                                                    'fstart': self._trig_fstart.value,
                                                    'fstop': self._trig_fstop.value,
                                                    'amplitude': self._trig_amp.value})


        self._trigger_mode.currentIndexChanged.connect(change_trigger)
        self._trig_fstart.value_changed.connect(new_trigger)
        self._trig_fstop.value_changed.connect(new_trigger)
        self._trig_amp.value_changed.connect(new_trigger)

    def device_changed(self, dut):
        self.dut_prop = dut.properties


    def state_changed(self, state, changed):
        self.gui_state = state
        if 'playback' in changed:
            # restore controls after playback is stopped
            self._trigger_mode.setEnabled(state.mode in self.dut_prop.LEVEL_TRIGGER_RFE_MODES)

        if 'device_settings.trigger' in changed:
            max_tunable = self.dut_prop.MAX_TUNABLE[self.gui_state.rfe_mode()]
            min_tunable = self.dut_prop.MIN_TUNABLE[self.gui_state.rfe_mode()]
            trigger = state.device_settings['trigger']
            self._trig_fstart.quiet_update(min_tunable, max_tunable,trigger['fstart'])
            self._trig_fstop.quiet_update(min_tunable, max_tunable, trigger['fstop'])
            self._trigger_mode.quiet_update(select_item = TRIGGER_TYPE_TEXT[trigger['type']])
            self._trigger_mode.clearFocus()
            self._trig_amp.quiet_update(-200, 200, value=trigger['amplitude'])
            if trigger['type'] == 'NONE':
                self._trig_state(False)
            else:
                self._trig_state(True)

        if 'device_settings.iq_output_path' in changed:
            if state.device_settings['iq_output_path'] == 'CONNECTOR':
                self._trigger_mode.setEnabled(False)
                self._trig_fstart.setEnabled(False)
                self._trig_fstop.setEnabled(False)
                self._trig_amp.setEnabled(False)

            elif state.device_settings['iq_output_path'] == 'DIGITIZER':
                self._trig_fstart.setEnabled(True)
                self._trig_fstop.setEnabled(True)
                self._trig_amp.setEnabled(True)
                self._trigger_mode.setEnabled(True)

        if 'mode' in changed:
            if state.mode not in self.dut_prop.LEVEL_TRIGGER_RFE_MODES:
                # forcibly disable triggers
                # if self._trigger_mode.currentText() == 'Level':
                self._trig_state(False)
                self._trigger_mode.setEnabled(False)

            else:
                self._trigger_mode.setEnabled(True)

    def _trig_state(self, state):
        self._trig_fstart.setEnabled(state)
        self._trig_amp.setEnabled(state)
        self._trig_fstop.setEnabled(state)
        self._trig = state

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)
