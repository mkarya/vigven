from PySide import QtGui, QtCore

from pyrf.units import M
import colors
from fonts import GROUP_BOX_FONT
from util import clear_layout
from widgets import QCheckBoxPlayback, QDoubleSpinBoxPlayback, QComboBoxPlayback, ValueEditWidget
from util import (create_item_label,
                 create_title_label, 
                 change_widget_background, 
                 initialize_groupbox_stylesheet, 
                 initialize_group_box)

MEASUREMENT_MODES = ['Analyzer', 'Channel Power']
MAX_AVERAGE_FACTOR = 10001
DEFAULT_AVERAGE_FACTOR = 100
DEFAULT_TRACE = 0 # 0 indicates LIVE
class MeasurementControls(QtGui.QGroupBox):

    def __init__(self, controller):
        super(MeasurementControls, self).__init__()

        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        controller.app_change.connect(self.app_changed)
        controller.trace_change.connect(self.trace_changed)
        self._create_controls()
        self.setLayout(QtGui.QGridLayout())
        self._build_layout()
        self._connect_controls()

    def _create_controls(self):

        # channel bw controls
        self._bw_widget, grid = initialize_group_box(self.controller)
        grid.setContentsMargins(25,0,0,0)
        bw_label = create_item_label('Integration BW')
        self._ch_bw = ValueEditWidget(self.controller, 
                                        'Integration BW', 
                                        val_unit = 'Hz', 
                                        current_unit = 'MHz',
                                        step = M,
                                        allow_step_change = False)

        self._ch_bw.quiet_update(0, 27000 * M, 0)
        grid.addWidget(bw_label)
        grid.addWidget(self._ch_bw)
        self._bw_widget.setLayout(grid)
        

        # initialize average controls
        self.average_widget, grid = initialize_group_box(self.controller)
        grid.setContentsMargins(25,0,0,0)
        average_label = create_item_label("Avg / Hold Number")
        self.average_edit = ValueEditWidget(self.controller, 
                                        'Number of Averages', 
                                        val_unit = None, 
                                        current_unit = None,
                                        step = 1.0,
                                        allow_step_change = False)

        self.average_edit.quiet_update(1, MAX_AVERAGE_FACTOR, DEFAULT_AVERAGE_FACTOR)
        grid.addWidget(average_label)
        grid.addWidget(self.average_edit)
        self.average_widget.setLayout(grid)

    def _build_layout(self):
        grid = self.layout()
        grid.setContentsMargins(0,0, 0,0)
        initialize_groupbox_stylesheet(self, self.controller)
        clear_layout(grid)
        title_label = create_title_label('MEAS SETUP', self.controller)
        row = 0
        grid.addWidget(title_label, row, 0, 1,8)
        row += 1
        grid.addWidget(self.average_widget, row, 0, 1,8)
        row += 2
        grid.addWidget(self._bw_widget, row, 0, 1, 8)

        self.resize_widget()

    def _connect_controls(self):

        def ch_bw_change():

            center = self.gui_state.center
            span = self._ch_bw.value / 2
            new_region = (center - span, center + span)
            self.controller.apply_plot_options(channel_power_region = new_region)


        def average_changed():
            average_num = self.average_edit.value
            self.controller.apply_trace_options(-1, ['average'], [self.average_edit.value])

        self.average_edit.value_changed.connect(average_changed)
        self._ch_bw.value_changed.connect(ch_bw_change)

    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def app_changed(self, state, changed):
        self.app_state = state

        if state['measurement_mode'] == 'Analyzer':
            self._bw_widget.hide()
        else:
            self._bw_widget.show()

    def state_changed(self, state, changed):
        self.gui_state = state

    def plot_changed(self, state, changed):
        self.plot_state = state

        if 'channel_power_region' in changed:
            region = state['channel_power_region']
  
            self._ch_bw.quiet_update(value = (max(region) - min(region)))

    def trace_changed(self, trace, state, changed):
        if trace == -1:
            if 'average' in changed:
                self.average_edit.quiet_update(value = state[-1]['average'])

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)

    def showEvent(self, event):
        self.activateWindow()