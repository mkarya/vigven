from PySide import QtGui, QtCore
from pyrf.units import M
from fonts import GROUP_BOX_FONT
from util import (create_title_label, 
                change_widget_background, 
                initialize_groupbox_stylesheet, 
                initialize_group_box, clear_layout, set_button_color, hide_layout, update_button)
import colors
from widgets import QPushLabelPlayback



class PresetControls(QtGui.QGroupBox):
    """
    A widget based from the Qt QGroupBox widget used to control the preset options
    of the RTSA
    """

    def __init__(self, controller):
        super(PresetControls, self).__init__()

        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)

        self._create_controls()
        self.setLayout(QtGui.QGridLayout())
        self._build_layout()
        self._connect_device_controls()

    def _create_controls(self):
        self.preset_button = QPushLabelPlayback('Preset All')
        update_button(self.preset_button, self.controller)

    def _build_layout(self):
        
        initialize_groupbox_stylesheet(self, self.controller)
        grid = self.layout()
        grid.setContentsMargins(0,0, 0,0)
        clear_layout(grid)

        title_label = create_title_label('PRESET', self.controller)
        row = 0
        grid.addWidget(title_label, row, 0, 1, 8)
        row += 1

        grid.addWidget(self.preset_button, row, 0, 1, 8)
        row += 1
        self.resize_widget()

    def _connect_device_controls(self):
        def preset_all():
            self.controller.preset_all()

        self.preset_button.clicked.connect(preset_all)

    def device_changed(self, dut):
        self.dut_prop = dut.properties


    def state_changed(self, state, changed):
        self.gui_state = state
        if state.playback:
            self.preset_button.setEnabled(False)
        else:
            self.preset_button.setEnabled(True)

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)

    def showEvent(self, event):
        self.activateWindow()