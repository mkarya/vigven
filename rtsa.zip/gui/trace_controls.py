from collections import namedtuple

from PySide import QtGui, QtCore
import labels
import colors
from util import hide_layout
from fonts import GROUP_BOX_FONT
from widgets import (QCheckBoxWidget, 
                    QDoubleSpinBoxPlayback, 
                    TraceTab, 
                    QComboBoxPlayback, 
                    ValueEditWidget, 
                    QPushLabelPlayback)
from gui_config import MarkerState, TraceState
import numpy as np
from util import (create_item_label,
                create_title_label, 
                change_widget_background, 
                initialize_groupbox_stylesheet, 
                initialize_group_box, clear_layout, set_button_color, hide_layout, update_button)
REMOVE_BUTTON_WIDTH = 10

TRACE_TYPES = ['Clear/Write', 'Trace Average', 'Max Hold', 'Min Hold']
TRACE_MODES = ['Active', 'View', 'Blank']
class TraceControls(QtGui.QGroupBox):
    """
    A widget with a layout containing widgets that
    can be used to control the FFT plot's traces
    :param name: The name of the groupBox
    """
    def __init__(self, controller):
        super(TraceControls, self).__init__()

        self.controller = controller
        self._tab_widgets = []
        controller.plot_change.connect(self.plot_changed)
        controller.trace_change.connect(self.trace_changed)
        controller.app_change.connect(self.app_changed)
        self._trace_state = TraceState().state
        self.setLayout(QtGui.QGridLayout())
        self._create_controls()

    def _create_controls(self):
        grid = self.layout()
        grid.setContentsMargins(0,0, 0,0)
        initialize_groupbox_stylesheet(self, self.controller)
        self.button_tabs = TraceTab(self.controller, 1,len(colors.TRACE_COLORS))

        title_label = create_title_label('TRACE', self.controller)
        row = 0

        # add title
        grid.addWidget(title_label, row, 0, 1, 1)
        row += 1

        # add buttons
        grid.addWidget(self.button_tabs, row, 0, 1, 1)
        row += 1

        for num in range(len(colors.TRACE_COLORS)):
            self._tab_widgets.append(TraceWidget(self.controller, num))
            grid.addWidget(self._tab_widgets[num], row, 0, 1, 1)

        self.resize_widget()

    def plot_changed(self, state, changed):
        self._plot_state = state
    
    def marker_changed(self, marker, state, changed):
        self._marker_state = state
        
    def app_changed(self, state, changed):
        self._app_state = state
        if 'selected_trace_tab' in changed:
            for w in self._tab_widgets:
                if w.name == state['selected_trace_tab']:
                    w.show()
                else:
                    w.hide()
    def trace_changed(self, trace, state, changed):
        self._trace_state = state

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)

class TraceWidget(QtGui.QWidget):
    def __init__(self, controller, name):
        super(TraceWidget, self).__init__()
        self.name = name
        # connect controller signals
        self.controller = controller
        controller.trace_change.connect(self.trace_changed)
        controller.state_change.connect(self.state_changed)
        # initialize states
        self._marker_state = MarkerState().state
        self._trace_state = TraceState().state
        self.create_controls()
        self.setLayout(QtGui.QGridLayout())
        palette = QtGui.QPalette()
        color = QtGui.QColor()
        color.setRgb(self.controller.widget_color_num[0], 
                     self.controller.widget_color_num[1], 
                     self.controller.widget_color_num[2])
        palette.setColor(QtGui.QPalette.Background, color)
        self.setAutoFillBackground(True)
        self.setPalette(palette)
        self._build_layout()

    def create_controls(self):
        """
        """
        # initialize the trace type selection widget
        self.type_widget, grid = initialize_group_box(self.controller)
        draw_label = create_item_label('Trace Type')
        self.draw = QComboBoxPlayback()
        self.draw.setToolTip("Select data source")
        for i, val in enumerate(TRACE_TYPES):
            self.draw.addItem(val)
        self.draw.setCurrentIndex(self.name)

        def draw_changed(index):
            self.controller.apply_trace_options(self.name, ['mode'], [self.draw.currentText()])
        self.draw.currentIndexChanged.connect(draw_changed)
        grid.addWidget(draw_label)
        grid.addWidget(self.draw)
        self.type_widget.setLayout(grid)

        # initialize the trace type selection widget
        self.mode_widget, grid = initialize_group_box(self.controller)
        mode_label = create_item_label('View / Blank')
        self.mode = QComboBoxPlayback()
        for i, val in enumerate(TRACE_MODES):
            self.mode.addItem(val)
        self.mode.setCurrentIndex(self.name)

        def mode_changed(index):
            if self.mode.currentText() == 'Blank':
                self.controller.apply_trace_options(self.name, ['mode', 'pause'], ['Off', False])

            elif self.mode.currentText() == 'Active':
                self.controller.apply_trace_options(self.name, ['mode'], [self.draw.currentText()])
                self.controller.apply_trace_options(self.name, ['pause'], [False])
            else:
                self.controller.apply_trace_options(self.name, ['pause'], [True])
        self.mode.currentIndexChanged.connect(mode_changed)
        grid.addWidget(mode_label)
        grid.addWidget(self.mode)
        self.mode_widget.setLayout(grid)

        # initlaize color button controls
        self.color_widget, grid = initialize_group_box(self.controller, orientation = 'h')
        color_label = create_item_label('Trace Color')
        self.color_button = QtGui.QPushButton()
        self.color_button.setStyleSheet("")
        r, g, b = colors.TRACE_COLORS[self.name]
        self._update_button_color(r, g, b)

        def custom_color_clicked():
            color = QtGui.QColorDialog.getColor()
            # Don't update if color chosen is black
            if not (color.red(), color.green(), color.blue()) == colors.BLACK_NUM:
                self._update_button_color(color.red(), color.green(), color.blue())
                color = (color.red(), color.green(), color.blue())
                trace_colors = {}
                self.controller.apply_trace_options(self.name, ['color'], [color])

        self.color_button.clicked.connect(custom_color_clicked)
        grid.addWidget(color_label)
        grid.addWidget(self.color_button)
        self.color_widget.setLayout(grid)

        # initialize clear trace widget        
        self.clear = QPushLabelPlayback("Clear Trace")
        update_button(self.clear, self.controller)
        def clear_clicked():
            self.controller.apply_trace_options(self.name, ['clear'], [None])
        self.clear.clicked.connect(clear_clicked)

        # initialize clear all trace widget        
        self.clear_all = QPushLabelPlayback("Clear All Traces")
        update_button(self.clear_all, self.controller)
        def clear_all_clicked():
            for t in self._trace_state:
                self.controller.apply_trace_options(t, ['clear'], [None])
        self.clear_all.clicked.connect(clear_all_clicked)

    def _update_button_color(self, r, g, b):
            button_icon = QtGui.QIcon()
            color = QtGui.QColor()
            color.setRgb(r, g, b)
            pixmap = QtGui.QPixmap(50, 50)
            pixmap.fill(color)
            button_icon.addPixmap(pixmap)
            self.color_button.setIcon(button_icon)

    def _build_layout(self):
        """
        rebuild grid layout based on marker and trace states
        """
        grid = self.layout()
        hide_layout(grid)

        def show(widget, y, x, h, w):
            grid.addWidget(widget, y, x, h, w)
            widget.show()

        row = 0
        show(self.type_widget, row, 0, 1, 3)
        row += 1
        show(self.clear, row, 0, 1, 3)
        row += 2
        show(self.clear_all, row, 0, 1, 3)
        row += 2
        show(self.color_widget, row, 0, 1, 3)
        row += 2
        show(self.mode_widget, row, 0, 1, 3)
        self.resize_widget()

    def _update_layout(self):
        """
        disable or enable the appropriate controls
        # """
        state = self._trace_state[self.name]
        # if trace is turned off, disable all the controls
        if state['mode'] == 'Off':
            self.type_widget.setEnabled(False)
            self.clear.setEnabled(False)
            self.clear_all.setEnabled(False)
            self.color_widget.setEnabled(False)

            return
        else:
            self.type_widget.setEnabled(True)
            self.clear.setEnabled(True)
            self.clear_all.setEnabled(True)
            self.color_widget.setEnabled(True)

        if state['mode'] in ['Live/Write', 'Trace Average']:
            self.clear.setText("Clear Trace")
        else:
            self.clear.setText("Clear Trace")

        # if trace is paused disable all controls unless it is unpaused
        if state['pause']:
            self.type_widget.setEnabled(False)
            self.clear.setEnabled(False)
            self.color_widget.setEnabled(False)
        else:
            self.type_widget.setEnabled(True)
            self.clear.setEnabled(True)
            self.color_widget.setEnabled(True)

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Maximum)

    def state_changed(self, state, changed):
        if 'device_settings.iq_output_path' in changed:
            if state.device_settings['iq_output_path'] == 'CONNECTOR':
                self.setEnabled(False)
            else:
                self.setEnabled(True)

    def trace_changed(self, trace, state, changed):
        self._trace_state = state
        if trace == self.name:
            if 'color' in changed:
                color = state[trace]['color']
                self._update_button_color(color[0], 
                                        color[1],
                                        color[2])
            if 'mode' in changed or 'pause' in changed:
                mode = state[trace]['mode']
                if mode == 'Off':
                    self.mode.quiet_update(TRACE_MODES, 'Blank')
                else:
                    if state[trace]['pause']:
                        self.mode.quiet_update(TRACE_MODES, 'View')
                    else:
                        self.mode.quiet_update(TRACE_MODES, 'Active')
                    self.draw.quiet_update(TRACE_TYPES, mode)
                self._update_layout()
            if 'average' in changed:
                self.average_edit.quiet_update(value = state[trace]['average'])
            self._update_layout()

    def plot_changed(self, state, changed):
        self.plot_state = state

    def showEvent(self, event):
        self.activateWindow()
