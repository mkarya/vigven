from PySide import QtGui, QtCore
from pyrf.units import M
from fonts import GROUP_BOX_FONT
from util import (create_item_label,
                create_title_label, 
                change_widget_background, 
                initialize_groupbox_stylesheet, 
                initialize_group_box, clear_layout)
import colors
from widgets import (QComboBoxPlayback, QCheckBoxPlayback, ValueEditWidget,
    QDoubleSpinBoxPlayback)

DIGITIZER_PATH_STRING = {'DIGITIZER': 'Digitizer',
                  'CONNECTOR': 'Connector'}
PLL_REF_STRING = {'EXT': 'External',
                  'INT': 'Internal'}
class DeviceControls(QtGui.QGroupBox):
    """
    A widget based from the Qt QGroupBox widget with a layout containing widgets that
    can be used to control the WSA4000/WSA5000
    :param name: The name of the groupBox
    """

    def __init__(self, controller):
        super(DeviceControls, self).__init__()

        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)

        self._create_controls()
        self.setLayout(QtGui.QGridLayout())
        self._build_layout()
        self._connect_device_controls()

    def _create_controls(self):
    
        # decimation controls
        self.dec_widget, grid = initialize_group_box(self.controller)
        grid.setContentsMargins(25,0,10,0)
        self._dec_label = create_item_label('Decimation Rate')
        self._dec_box = QComboBoxPlayback()
        self._dec_box.setToolTip("Choose Decimation Rate")
        # FIXME: use values from device properties
        dec_values = ['1', '4', '8', '16', '32', '64', '128', '256', '512', '1024']
        for d in dec_values:
            self._dec_box.addItem(d)
        self._dec_values = dec_values
        grid.addWidget(self._dec_label)
        grid.addWidget(self._dec_box)
        self.dec_widget.setLayout(grid)
        
        # frequency shift controls
        self.fshift_widget, grid = initialize_group_box(self.controller)
        grid.setContentsMargins(25,0,10,0)
        self._fshift_label = create_item_label("Frequency Shift")
        self._fshift_edit = ValueEditWidget(self.controller, 
                                        'Frequency Shift', 
                                        val_unit = 'Hz', 
                                        current_unit = 'MHz',
                                        step = M,
                                        allow_step_change = False)
        grid.addWidget(self._fshift_label)
        grid.addWidget(self._fshift_edit)
        self.fshift_widget.setLayout(grid)

        # iq out controls
        self.iq_widget, grid = initialize_group_box(self.controller)
        grid.setContentsMargins(25,0,10,0)
        self._iq_output_label = create_item_label("IQ Path:")
        self._iq_output_box = QComboBoxPlayback()
        self._iq_output_box.setToolTip("Choose IQ Path")
        self._iq_output_box.quiet_update(["Digitizer", "Connector"])
        grid.addWidget(self._iq_output_label)
        grid.addWidget(self._iq_output_box)
        self.iq_widget.setLayout(grid)

        # pll source controls
        self.pll_widget, grid = initialize_group_box(self.controller)
        grid.setContentsMargins(25,0,10,0)
        self._pll_label = create_item_label("PLL Clock Reference")
        self._pll_box = QComboBoxPlayback()
        self._pll_box.setToolTip("Choose PLL Reference")
        self._pll_box.quiet_update(["Internal", "External"])
        grid.addWidget(self._pll_label)
        grid.addWidget(self._pll_box)
        self.pll_widget.setLayout(grid)

    def _build_layout(self, dut_prop=None):
        features = dut_prop.SWEEP_SETTINGS if dut_prop else []
        
        initialize_groupbox_stylesheet(self, self.controller)
        grid = self.layout()
        grid.setContentsMargins(0,0, 0,0)

        title_label = create_title_label('SYSTEM', self.controller)
        row = 0
        grid.addWidget(title_label, row, 0, 1, 8)
        row += 1

        grid.addWidget(self.dec_widget, row, 0, 1, 8)
        row += 1

        grid.addWidget(self.fshift_widget, row, 0, 1, 8)
        row += 1
 
        grid.addWidget(self.iq_widget, row, 0, 1, 8)
        row += 1

        grid.addWidget(self.pll_widget, row, 0, 1, 8)
        row += 1
        self.resize_widget()

    def _connect_device_controls(self):
        def new_dec():
            self.controller.apply_settings(decimation=int(
                self._dec_box.currentText()))

        def new_freq_shift():
            self.controller.apply_settings(
                fshift=self._fshift_edit.value)

        def new_pll_reference():
            if self._pll_box.currentText() == 'Internal':
                src = 'INT'
            else:
                src = 'EXT'
            self.controller.apply_device_settings(pll_reference=src)

        def new_iq_path():
            self.controller.apply_device_settings(
                iq_output_path= str(self._iq_output_box.currentText().upper()))



        self._dec_box.currentIndexChanged.connect(new_dec)
        self._fshift_edit.value_changed.connect(new_freq_shift)
        self._iq_output_box.currentIndexChanged.connect(new_iq_path)
        self._pll_box.currentIndexChanged.connect(new_pll_reference)

    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def state_changed(self, state, changed):
        if not hasattr(self, 'gui_state'):
            self.gui_state = state

        if state.playback:
            self._dec_box.quiet_update(str(state.decimation))
            self._fshift_edit.quiet_update(value = state.fshift / M)
            self._pll_box.playback_value('External'
                if state.device_settings.get('pll_reference') == 'EXT' else
                'Internal')
            self._iq_output_box.playback_value('Digitizer')
            return

        if 'playback' in changed:
            decimation_available = self.dut_prop.MIN_DECIMATION[
                state.rfe_mode()] is not None
            self._dec_box.setEnabled(decimation_available)
            self._fshift_edit.setEnabled(decimation_available)
            self._pll_box.quiet_update(["Internal", "External"])
            self._pll_box.setEnabled(True)
            self._iq_output_box.quiet_update(["Digitizer", "Connector"])
            self._iq_output_box.setEnabled(True)

        if 'mode' in changed:
            if state.sweeping():
                self._dec_box.setEnabled(False)
                self._fshift_edit.setEnabled(False)
            else:
                decimation_available = self.dut_prop.MIN_DECIMATION[
                    state.rfe_mode()] is not None
                self._dec_box.setEnabled(decimation_available)
                self._fshift_edit.setEnabled(decimation_available)
                fshift_max = self.dut_prop.FULL_BW[state.rfe_mode()]
                self._fshift_edit.quiet_update(-fshift_max, fshift_max)

        if 'decimation' in changed:
            self._dec_box.quiet_update(self._dec_values, str(state.decimation))

        if 'fshift' in changed:
            self._fshift_edit.quiet_update(value = state.fshift)

        if 'device_settings.iq_output_path' in changed:
            self._iq_output_box.quiet_update(["Digitizer", "Connector"], DIGITIZER_PATH_STRING[state.device_settings['iq_output_path']])
            if 'CONNECTOR' == state.device_settings['iq_output_path']:

                self._dec_box.setEnabled(False)
                self._fshift_edit.setEnabled(False)
                self._fshift_label.setEnabled(False)

            elif 'DIGITIZER' == state.device_settings['iq_output_path']:
                    self._dec_box.setEnabled(True)
                    self._fshift_edit.setEnabled(True)
                    self._fshift_label.setEnabled(True)

        if 'device_settings.pll_reference' in changed:
            self._pll_box.quiet_update(["Internal", "External"], PLL_REF_STRING[state.device_settings['pll_reference']])
        self.gui_state = state

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Maximum, QtGui.QSizePolicy.Maximum)

    def showEvent(self, event):
        self.activateWindow()