from PySide import QtGui, QtCore

from pyrf.units import M
import colors
from fonts import GROUP_BOX_FONT
from util import clear_layout
from widgets import QCheckBoxWidget, QDoubleSpinBoxPlayback, QComboBoxPlayback, ValueEditWidget
from util import (create_item_label,
                create_title_label, 
                change_widget_background, 
                initialize_groupbox_stylesheet, 
                initialize_group_box)

MEASUREMENT_MODES = ['Analyzer', 'Channel Power']
WIDGET_WIDTH = 12
class DisplayControls(QtGui.QGroupBox):

    def __init__(self, controller):
        super(DisplayControls, self).__init__()

        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        controller.app_change.connect(self.app_changed)
        self._create_controls()
        self._build_layout()
        self._connect_controls()

    def _create_controls(self):

        # horizontal cursor controls
        self._cursor_widget, grid = initialize_group_box(self.controller)
        grid.setContentsMargins(25,0,0,0)
        self._horizontal_cursor = QCheckBoxWidget("Display Line")
        self._horizontal_cursor.setToolTip("Enable Horizontal Cursor on reference Plot")
        self._cursor_spinbox = ValueEditWidget(self.controller, 
                                        'Display Line', 
                                        val_unit = 'dBm', 
                                        current_unit = 'dBm',
                                        step = 1.0)
        self._cursor_spinbox.setEnabled(False)

        self._cursor_spinbox.quiet_update(-2000, 2000, value = -100)
        grid.addWidget(self._horizontal_cursor)
        grid.addWidget(self._cursor_spinbox)
        self._cursor_widget.setLayout(grid)

    def _build_layout(self):
        grid = QtGui.QGridLayout()
        grid.setContentsMargins(0,0, 0,0)
        initialize_groupbox_stylesheet(self, self.controller)
        clear_layout(grid)
        title_label = create_title_label('DISPLAY', self.controller)
        row = 0
        grid.addWidget(title_label, row, 0, 1,WIDGET_WIDTH)
        row += 1
        grid.addWidget(self._cursor_widget, row, 0, 1,WIDGET_WIDTH - 2)
        self.setLayout(grid)
        self.resize_widget()

    def _connect_controls(self):

        def enable_cursor():
            self.controller.apply_plot_options(horizontal_cursor = self._horizontal_cursor.isChecked())

        def change_cursor_value():
            self.controller.apply_plot_options(horizontal_cursor_value = self._cursor_spinbox.value)

        self._horizontal_cursor.clicked.connect(enable_cursor)
        self._cursor_spinbox.value_changed.connect(change_cursor_value)

    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def app_changed(self, state, changed):
        self.app_state = state

    def state_changed(self, state, changed):
        self.gui_state = state
        if 'device_settings.iq_output_path' in changed:
            if state.device_settings['iq_output_path'] == 'CONNECTOR':
                self._cursor_spinbox.setEnabled(False)
            elif state.device_settings['iq_output_path'] == 'DIGITIZER':
                self._horizontal_cursor.setEnabled(True)
                self._cursor_spinbox.setEnabled(True)

    def plot_changed(self, state, changed):
        self.plot_state = state
        if 'horizontal_cursor_value' in changed:
                self._cursor_spinbox.quiet_update(value = float(state['horizontal_cursor_value']))

        if 'horizontal_cursor' in changed:
            self._horizontal_cursor.quiet_update(state['horizontal_cursor'])
            self._cursor_spinbox.setEnabled(state['horizontal_cursor'])

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)

    def showEvent(self, event):
        self.activateWindow()