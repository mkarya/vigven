from PySide import QtGui, QtCore
from fonts import GROUP_BOX_FONT
from widgets import QCheckBoxWidget, QDoubleSpinBoxPlayback, ValueEditWidget, QComboBoxPlayback

import numpy as np
import colors
from util import (create_item_label,
                create_title_label, 
                change_widget_background, 
                initialize_groupbox_stylesheet, 
                initialize_group_box, 
                clear_layout, 
                set_button_color, 
                hide_layout)
PLOT_YMIN = -5000
PLOT_YMAX = 10
PLOT_TOP = 10
PLOT_BOTTOM = -160
PLOT_STEP = 1
BUTTON_WIDTH = 12
ATTENUATOR_MODES = ['0 dB', '20 dB']
ATTENUATOR_TEXT_TO_MODE = {'0 dB': False,
                    '20 dB': True}

class AmplitudeControls(QtGui.QGroupBox):
    """
    A widget with a layout containing widgets that
    can be used to control the amplitude configurations of the GUI
    :param controller: A controller that emits/receives Qt signals from multiple widgets
    """

    def __init__(self, controller):
        super(AmplitudeControls, self).__init__()

        self.controller = controller
        self._create_controls()
        grid = QtGui.QGridLayout()
        self.setLayout(QtGui.QGridLayout())
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        controller.app_change.connect(self.app_changed)
        self.plot_state = None

    def _create_controls(self):
    
        # reflevel controls
        widget, grid = initialize_group_box(self.controller)
        self._max_level = ValueEditWidget(self.controller, 
                                        'Reference Level', 
                                        val_unit = 'dBm', 
                                        current_unit = 'dBm',
                                        step = 1.0)
        self._max_level.quiet_update(PLOT_YMIN, PLOT_YMAX, PLOT_TOP)
        def update_plot_max():
            self.controller.apply_plot_options(ref_level = self._max_level.value)
        self._max_level.value_changed.connect(update_plot_max)

        grid.addWidget(create_item_label('Reference Level'))
        grid.addWidget(self._max_level)
        widget.setLayout(grid)
        self.reflevel_widget = widget

        # db/div controls
        widget, grid = initialize_group_box(self.controller)
        self._db_div = ValueEditWidget(self.controller, 
                                        'Scale/Div', 
                                        val_unit = 'dB', 
                                        current_unit = 'dB',
                                        step = 1.0)
        self._db_div.quiet_update(1, 16, 15)

        def update_db_div():
            self.controller.apply_plot_options(db_div =  self._db_div.value)
        self._db_div.value_changed.connect(update_db_div)
        self._div_label = create_item_label('Scale/Div ')
        grid.addWidget(self._div_label)
        grid.addWidget(self._db_div)
        widget.setLayout(grid)
        self.db_div_widget = widget

        # reflevel offset controls
        widget, grid = initialize_group_box(self.controller)
        self._reference_offset_spinbox = ValueEditWidget(self.controller, 
                                        'Reference Level Offset', 
                                        val_unit = 'dB', 
                                        current_unit = 'dB',
                                        step = 1.0)
        self._reference_offset_spinbox.quiet_update(-200, 200, 0)
        
        def change_reference_offset_value():
            self.controller.apply_plot_options(reference_offset_value = self._reference_offset_spinbox.value)
        self._reference_offset_spinbox.value_changed.connect(change_reference_offset_value)
        grid.addWidget(create_item_label("Reference Level Offset"))
        grid.addWidget(self._reference_offset_spinbox)
        widget.setLayout(grid)
        self.reflevel_offset_widget = widget
        

        # 20dB attenuator control
        widget, grid = initialize_group_box(self.controller)
        attenuator_box = QComboBoxPlayback()
        for mode in ATTENUATOR_MODES:
            attenuator_box.addItem(mode)
        self._atten_box = attenuator_box

        def new_attenuator():
            setting = ATTENUATOR_TEXT_TO_MODE[self._atten_box.currentText()]
            self.controller.apply_device_settings(attenuator = setting)
        self._atten_box.currentIndexChanged.connect(new_attenuator)
        
        grid.addWidget(create_item_label("Attenuation"))
        grid.addWidget(self._atten_box)
        widget.setLayout(grid)
        self.attenuator_widget = widget
        
        # variable attenuator control
        widget, grid = initialize_group_box(self.controller)
        self._var_atten = ValueEditWidget(self.controller, 
                                        'IF Aattenuator', 
                                        val_unit = 'dB', 
                                        current_unit = 'dB',
                                        step = 1.0)

        def new_var_attenuator():
            self.controller.apply_device_settings(var_attenuator = self._var_atten.value)
        self._var_atten.value_changed.connect(new_var_attenuator)
        self._var_atten.quiet_update(0, 25, 0)
        grid.addWidget(create_item_label("IF Attenuator"))
        grid.addWidget(self._var_atten)
        widget.setLayout(grid)
        self.var_attenuator_widget = widget

        # auto attenuation
        self.auto_atten = QCheckBoxWidget("Auto Atteunation")
        def change_atten_mode():
            self.controller.apply_app_options(auto_atten = self.auto_atten.isChecked())
        self.auto_atten.clicked.connect(change_atten_mode)

        # hdr gain controls
        widget, grid = initialize_group_box(self.controller)
        hdr_gain_label = create_item_label("HDR Gain")
        hdr_gain_box = ValueEditWidget(self.controller, 
                                        'HDR Gain', 
                                        val_unit = 'dB', 
                                        current_unit = 'dB',
                                        step = 1.0)
        hdr_gain_box.quiet_update(-10, 30, -10)
        self._hdr_gain_label = hdr_gain_label
        self._hdr_gain_box = hdr_gain_box

        def new_hdr_gain():
            self.controller.apply_device_settings(hdr_gain = self._hdr_gain_box.value)
        self._hdr_gain_box.value_changed.connect(new_hdr_gain)
        grid.addWidget(hdr_gain_label)
        grid.addWidget(self._hdr_gain_box)
        widget.setLayout(grid)
        self.hdr_widget = widget

    def _build_layout(self):
        if hasattr(self, 'dut_prop'):
            features = self.dut_prop.SWEEP_SETTINGS 
        else:
            features = []
        grid = self.layout()

        initialize_groupbox_stylesheet(self, self.controller)
        grid.setContentsMargins(0,0, 0,0)

        title_label = create_title_label('AMPLITUDE', self.controller)
        row = 0
        grid.addWidget(title_label, 0, 0, 1, BUTTON_WIDTH)
        row += 1

        grid.addWidget(self.reflevel_widget, row, 1, 1, BUTTON_WIDTH - 2)
        row += 1

        grid.addWidget(self.db_div_widget, row, 1, 1, BUTTON_WIDTH - 2)
        row += 1

        grid.addWidget(self.reflevel_offset_widget, row, 1, 1,BUTTON_WIDTH - 2)
        row += 1
        
        grid.addWidget(self.auto_atten, row, 1, 1,BUTTON_WIDTH - 2)
        row += 1
        grid.addWidget(self.attenuator_widget, row, 1, 1, BUTTON_WIDTH - 2)
        row += 1
        grid.addWidget(self.var_attenuator_widget, row, 1, 1, BUTTON_WIDTH - 2)
        row += 1
        if not 'attenuator' in features:
            self.attenuator_widget.hide()

        if not 'var_attenuator' in features:
            self.var_attenuator_widget.hide()

        if 'hdr_gain' in features:
            grid.addWidget(self.hdr_widget, row, 1, 1, BUTTON_WIDTH - 2)
            row += 1
            self._hdr_gain_box.quiet_update(value=self.dut_prop.SPECA_DEFAULTS['device_settings']['hdr_gain'])

        self.setLayout(grid)
        self.resize_widget()

    def device_changed(self, dut):
        self.dut_prop = dut.properties
        self._build_layout()

    def state_changed(self, state, changed):

        if 'mode' in changed:
            if state.mode == 'HDR':
                self._hdr_gain_box.show()
                self._hdr_gain_label.show()
                self.hdr_widget.show()
                self.resize_widget()
            else:
                self._hdr_gain_box.hide()
                self._hdr_gain_label.hide()
                self.hdr_widget.hide()
                self.resize_widget()

        if 'device_settings.iq_output_path' in changed:
            if state.device_settings['iq_output_path'] == 'CONNECTOR':
                self._max_level.setEnabled(False)
                self._db_div.setEnabled(False)
            elif state.device_settings['iq_output_path'] == 'DIGITIZER':
                self._max_level.setEnabled(True)
                self._db_div.setEnabled(True)

        if 'device_settings.hdr_gain' in changed:
            self._hdr_gain_box.quiet_update(value=state.device_settings['hdr_gain'])

        if 'device_settings.attenuator' in changed:
            if state.device_settings['attenuator']:
                self._atten_box.quiet_update(select_item = ATTENUATOR_MODES[1])
            else:
                self._atten_box.quiet_update(select_item = ATTENUATOR_MODES[0])

        if 'device_settings.var_attenuator' in changed:
            self._var_atten.quiet_update(value = state.device_settings['var_attenuator'])


    def plot_changed(self, state, changed):

        self.plot_state = state
        if 'ref_level' in changed:
            self._max_level.quiet_update(value = state['ref_level'])
        if 'db_div' in changed:
            self._db_div.quiet_update(value = state['db_div'])
        if 'reference_offset_value' in changed:
            self._reference_offset_spinbox.quiet_update(value = state['reference_offset_value'])
   
    def app_changed(self, state, changed):

        self._app_state = state
        if 'auto_atten' in changed:
            self.auto_atten.quiet_update(value = state['auto_atten'])
            if state['auto_atten']:
                self._atten_box.setEnabled(False)
                self._var_atten.setEnabled(False)
            else:
                self._atten_box.setEnabled(True)
                self._var_atten.setEnabled(True)
   
    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)

    def get_max_level(self):
        return self._max_level.value()

    def get_db_div(self):
        return self._db_div.value()

    def showEvent(self, event):
        self.activateWindow()