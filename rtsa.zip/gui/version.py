VERSION = (3, 0, 4, 'dev1')
__version__ = ''.join(['-.'[type(x) == int]+str(x) for x in VERSION])[1:]
