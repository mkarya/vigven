from PySide import QtGui, QtCore
import colors
from widgets import (QComboBoxPlayback, 
                    QDoubleSpinBoxPlayback, 
                    QPushLabelPlayback,  
                    QCheckBoxWidget, 
                    ValueEditWidget)

from fonts import GROUP_BOX_FONT
from pyrf.sweep_device import MAXIMUM_SPP as MAXIMUM_SWEEP_SPP
from util import (create_item_label,
                create_title_label, 
                change_widget_background, 
                initialize_groupbox_stylesheet, 
                initialize_group_box, 
                update_button)

INPUT_DECIMALS = 8
WIDGET_WIDTH = 12
BW_STEPS = [1e6, 2e6, 5e6, 1e7, 2e7, 5e7, 1e8, 2e8, 5e8, 1e9, 2e9, 5e9]
MINIMUM_SPAN = 1e6
DEFAULT_CENTER = 2450e6
DEFAULT_SPAN = 100e6
class FrequencyControls(QtGui.QGroupBox):

    def __init__(self, controller):
        super(FrequencyControls, self).__init__()

        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        controller.app_change.connect(self.app_changed)
        grid = QtGui.QGridLayout()
        grid.setContentsMargins(0,0, 0,0)
        initialize_groupbox_stylesheet(self, controller, hide=False)
        self.freq_widgets = []
        self.setAlignment(QtCore.Qt.AlignTop)

        row = 0
        
        grid.addWidget(create_title_label('FREQUENCY', self.controller), row, 0, 1, 12)
        row += 1

        grid.addWidget(self._center_freq(), row, 1, 1, WIDGET_WIDTH - 2)
        row += 1

        grid.addWidget(self._bw_controls(), row, 1, 1, WIDGET_WIDTH - 2)
        row += 1

        grid.addWidget(self._fullspan_controls(), row, 1, 1, WIDGET_WIDTH - 2)
        row += 1

        grid.addWidget(self._fstart_controls(), row, 1, 1, WIDGET_WIDTH - 2)
        row += 1

        grid.addWidget(self._fstop_controls(), row, 1, 1, WIDGET_WIDTH - 2)
        row += 1

        grid.addWidget(self._freq_incr(), row, 1, 1, WIDGET_WIDTH - 2)
        row += 1

        mouse_control = self._mouse_control()
        grid.addWidget(mouse_control, row, 1, 1, WIDGET_WIDTH - 2)

        self.setLayout(grid)
        self.resize_widget()

        self.start_stop_changed = False # keep track of what was last changed
        
    def device_changed(self, dut):
        # to later calculate valid frequency values
        self.dut_prop = dut.properties

    def state_changed(self, state, changed):
        self.gui_state = state
            
        def enable_disable_edit_boxes():
            if state.sweeping():
                self._fstart_edit.setEnabled(not state.playback)
                self._fstop_edit.setEnabled(not state.playback)
                self._bw_edit.setEnabled(not state.playback)
                self._freq_edit.setEnabled(not state.playback)

            elif state.rfe_mode() in self.dut_prop.TUNABLE_MODES:
                self._fstart_edit.setEnabled(False)
                self._fstop_edit.setEnabled(False)
                self._bw_edit.setEnabled(False)
                self._freq_edit.setEnabled(True)

            else:
                self._freq_edit.setEnabled(False)
                self._fstart_edit.setEnabled(False)
                self._fstop_edit.setEnabled(False)
                self._bw_edit.setEnabled(False)

        if 'mode' in changed:
            self._update_freq_ranges()
            enable_disable_edit_boxes()

        if any(x in changed for x in ('center', 'span', 'decimation', 'mode')):
            self._update_freq_ranges()
            self._update_freq_edit()

        if 'playback' in changed:
            self._freq_edit.setEnabled(not state.playback)
            enable_disable_edit_boxes()

        if 'device_settings.iq_output_path' in changed:
            if state.device_settings['iq_output_path'] == 'CONNECTOR':
                self._fstart_edit.setEnabled(False)
                self._fstop_edit.setEnabled(False)
                self._bw_edit.setEnabled(False)

    def app_changed(self, state, changed):
        self.app_state = state
        if 'measurement_mode' in changed:
            if state['measurement_mode'] == 'Analyzer':
                self._fstop_Widget.show()
                self._fstart_Widget.show()
            elif state['measurement_mode'] == 'Channel Power':
                self._fstop_Widget.hide()
                self._fstart_Widget.hide()
        
        if 'capture_mode' in changed:
            if state['capture_mode'] == 'Spectrum Analyzer':
                self._fstop_Widget.show()
                self._fstart_Widget.show()
            elif state['capture_mode'] == 'RTSA':
                self._fstop_Widget.hide()
                self._fstart_Widget.hide()

        if 'fstep' in changed:
            self._fstep_box.quiet_update(value = state['fstep'])

    def plot_changed(self, state, changed):
        if 'mouse_tune' in changed:
            self._mouse_cbox.setChecked(state['mouse_tune'])

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)

    def _update_freq_ranges(self):
        # update all of the available ranges of the frequency controls
        
        span = self.gui_state.span
        mode = self.gui_state.rfe_mode()
        center = self.gui_state.center
        min_tunable = float(self.dut_prop.MIN_TUNABLE[mode])
        max_tunable = float(self.dut_prop.MAX_TUNABLE[mode])
        tuning_res = float(self.dut_prop.TUNING_RESOLUTION)
        if mode in self.dut_prop.TUNABLE_MODES:
            # XXX tuning_res is used here as an approximation of
            # "smallest reasonable span"

            self._fstart_edit.quiet_update(
                min_tunable,(center + (span / 2)))
        else:
            # if cannot tune, set minimum of fstart label to 0
            self._freq_edit.quiet_update(min_tunable, max_tunable)
            self._fstart_edit.quiet_update(
                0, (max_tunable + span))

        self._fstop_edit.quiet_update(
            (center - (span / 2)), (max_tunable + span))

        self._bw_edit.quiet_update(
            tuning_res, (max_tunable + span))

        self._freq_edit.quiet_update(min_tunable, max_tunable)

    def _freq_incr(self):
        incr_widget, grid = initialize_group_box(self.controller)
        grid = QtGui.QVBoxLayout()
        grid.setContentsMargins(5,0,0,0)
        steps_label = create_item_label("CF Step")
        steps = ValueEditWidget(self.controller, 'Step Frequency', allow_step_change = False, step = 1e6)
        steps.quiet_update(value=DEFAULT_CENTER)
        steps.quiet_update(minimum = 1, maximum = 1e12)
        
        def freq_step_change(freq):
            self.controller.apply_app_options(fstep = freq)

        steps.value_changed.connect(freq_step_change)
        self._fstep_box = steps
        grid.addWidget(steps_label)
        grid.addWidget(steps)
        incr_widget.setLayout(grid)
        return incr_widget

    def _mouse_control(self):
        mouse_control = QCheckBoxWidget("Tune with Mouse")
        mouse_control.setChecked(True)
        def change_mouse_control():
            self.controller.apply_plot_options(mouse_tune = mouse_control.isChecked())
        mouse_control.clicked.connect(change_mouse_control)
        self._mouse_cbox = mouse_control
        return self._mouse_cbox

    def _center_freq(self):

        cfreq_widget, grid = initialize_group_box(self.controller)
        cfreq = create_item_label('Center Frequency')
        self._cfreq = cfreq
        freq_edit = ValueEditWidget(self.controller, 'Center Frequency')
        freq_edit.quiet_update(value=DEFAULT_CENTER)
        self._freq_edit = freq_edit

        def freq_change(freq):
            self.start_stop_changed = False
            center = freq
            min_tunable = self.dut_prop.MIN_TUNABLE[self.gui_state.rfe_mode()]
            start_freq = center - (self.gui_state.span / 2)
            if start_freq < min_tunable:
                center = min_tunable + (self.gui_state.span / 2)
            self.controller.apply_settings(center=center)
            if self.gui_state.device_settings['iq_output_path'] == 'CONNECTOR':
                self.controller.apply_device_settings(freq=center)
        freq_edit.value_changed.connect(freq_change)
        self.freq_edit = freq_edit
        grid.addWidget(cfreq)
        grid.addWidget(freq_edit)
        cfreq_widget.setLayout(grid)
        self.freq_widgets.append(self.freq_edit)
        return cfreq_widget

    def _bw_controls(self):
        bw_widget, grid = initialize_group_box(self.controller)
        bw = create_item_label('Span')
        
        self._bw = bw
        bw_edit = ValueEditWidget(self.controller, 'Span', step = BW_STEPS,allow_step_change = False)
        bw_edit.quiet_update(value=DEFAULT_CENTER)
        def freq_change(freq):
            self.start_stop_changed = False
            self.controller.apply_settings(span=freq)
        bw_edit.value_changed.connect(freq_change)
        self._bw_edit = bw_edit
        grid.addWidget(bw)
        grid.addWidget(bw_edit)
        bw_widget.setLayout(grid)
        self.freq_widgets.append(self._bw_edit)
        return bw_widget

    def _fullspan_controls(self):
        full_span_widget, grid = initialize_group_box(self.controller)

        full_span = QPushLabelPlayback('Full Span')
        update_button(full_span, self.controller)

        def show_full_span():
            mode = self.gui_state.rfe_mode()
            min_tunable = float(self.dut_prop.MIN_TUNABLE[mode])
            max_tunable = float(self.dut_prop.MAX_TUNABLE[mode])
            span_freq = max_tunable - min_tunable
            center_freq = (max_tunable + min_tunable) / 2
            self.controller.apply_settings(
                span = span_freq,
                center = center_freq)
        full_span.clicked.connect(show_full_span)
        self.full_span = full_span
        return full_span

    def _fstart_controls(self):
        fstart_widget, grid = initialize_group_box(self.controller)
        fstart = create_item_label('Start Frequency')
        self._fstart = fstart
        
        freq = ValueEditWidget(self.controller, 'Start Frequency')
        freq.quiet_update(value=DEFAULT_CENTER)
        def freq_change(val):
            fstart = val
            self._fstart_edit.quiet_update(value= val)
            fstop = self._fstop_edit.freq
            fstop = float(max(fstop, fstart + self.dut_prop.TUNING_RESOLUTION))
            self.start_stop_changed = True
            self.controller.apply_settings(
                center = (fstop + fstart) / 2.0,
                span = (fstop - fstart),
                )

        freq.value_changed.connect(freq_change)
        self._fstart_edit = freq
        grid.addWidget(fstart)
        grid.addWidget(freq)
        fstart_widget.setLayout(grid)
        self.freq_widgets.append(self._fstart_edit)
        self._fstart_Widget = fstart_widget
        return fstart_widget

    def _fstop_controls(self):
        fstop_widget, grid = initialize_group_box(self.controller)
        fstop = create_item_label('Stop Frequency')
        self._fstop = fstop
        self._fstop_edit = ValueEditWidget(self.controller, 'Stop Frequency')
        self._fstop_edit.quiet_update(value=DEFAULT_CENTER)
        def freq_change(val):
            self.start_stop_changed = True
            fstart = self._fstart_edit.freq
            fstop = val
            self._fstop_edit.quiet_update(value= val)
            fstart = float(min(fstart, fstop - self.dut_prop.TUNING_RESOLUTION))

            self.controller.apply_settings(
                center = (fstop + fstart) / 2.0,
                span = (fstop - fstart),
                )
        self._fstop_edit.value_changed.connect(freq_change)
        grid.addWidget(fstop)
        grid.addWidget(self._fstop_edit)
        fstop_widget.setLayout(grid)
        self.freq_widgets.append(self._fstop_edit)
        self._fstop_Widget = fstop_widget
        return fstop_widget

    def _update_freq_edit(self):
        """
        update the spin boxes from self.gui_state
        """

        max_tunable = self.dut_prop.MAX_TUNABLE[self.gui_state.rfe_mode()]
        min_tunable = self.dut_prop.MIN_TUNABLE[self.gui_state.rfe_mode()]
        if self.gui_state.rfe_mode()  in self.dut_prop.TUNABLE_MODES:
            center = float(self.gui_state.center)
        else:
            center = max_tunable

        span = float(self.gui_state.span)
        self._freq_edit.quiet_update(value=center)
        if self.gui_state.rfe_mode() == 'HDR':
            self._bw_edit.quiet_update(minimum = span, maximum =max_tunable, value=span)
        else:
            self._bw_edit.quiet_update(minimum = MINIMUM_SPAN, maximum =max_tunable, value=span)

        if not self.start_stop_changed:
            self._fstop_edit.quiet_update(value= center + span / 2)
            self._fstart_edit.quiet_update(value= center - span / 2)
        self._updating_values = False
        self.start_stop_changed = False

    def reset_freq_bounds(self):
            self.start_freq = None
            self.stop_freq = None

    def enable(self):
        self._bw.setEnabled(True)
        self._bw_edit.setEnabled(True)
        self._fstart.setEnabled(True)
        self._fstart_edit.setEnabled(True)
        self._fstop.setEnabled(True)
        self._fstop_edit.setEnabled(True)

    def disable(self):
        self._bw.setEnabled(False)
        self._bw_edit.setEnabled(False)
        self._fstart.setEnabled(False)
        self._fstart_edit.setEnabled(False)
        self._fstop.setEnabled(False)
        self._fstop_edit.setEnabled(False)

