import logging
import ConfigParser

from PySide import QtCore
import numpy as np  # FIXME: move sweep playback out of here
import colors
from datetime import datetime
from pyrf.sweep_device import SweepDevice
from pyrf.capture_device import CaptureDevice
from gui_config import (WindowOptions, 
                        PlotState, 
                        MarkerState, 
                        TraceState, 
                        TabState, 
                        AppState,
                        warningState)
from state import SpecAState
from pyrf.numpy_util import compute_fft
from pyrf.vrt import vrt_packet_reader
from pyrf.devices.playback import Playback
from pyrf.util import (compute_usable_bins, adjust_usable_fstart_fstop,
    trim_to_usable_fstart_fstop, decode_config_type, find_saturation)
from util import calculate_rbw_values, auto_config_rbw
logger = logging.getLogger(__name__)
PLAYBACK_STEP_MSEC = 100
BUILD_TYPE = 'BNC'

class SpecAController(QtCore.QObject):
    """
    The controller for the rtsa-gui.
    Issues commands to device, stores and broadcasts changes to GUI state.
    """
    _dut = None
    _sweep_device = None
    _capture_device = None
    _plot_options = None
    _state = None
    _recording_file = None
    _csv_file = None
    _export_csv = False
    _playback_file = None
    _playback_sweep_data = None
    _pending_user_xrange = None
    _applying_user_xrange = False
    _user_xrange_control_enabled = True
    _single_capture = False
    _ref_level = 0.0
    _loading_config = False
    device_change = QtCore.Signal(object)
    capture_receive = QtCore.Signal(SpecAState, float, float, object, object, object, object)
    state_change = QtCore.Signal(SpecAState, list)
    options_change = QtCore.Signal(dict, list)
    plot_change = QtCore.Signal(dict, list)
    window_change = QtCore.Signal(dict, list)
    marker_change = QtCore.Signal(int, dict, list)
    trace_change = QtCore.Signal(int, list, list)
    tab_change = QtCore.Signal(dict, list)
    app_change = QtCore.Signal(dict, list)
    warning_change = QtCore.Signal(dict, list)

    def __init__(self, developer_mode = False):
        super(SpecAController, self).__init__()


        self.widget_color = colors.TRF_BACKGROUND
        self.widget_color_num = colors.TRF_BACKGROUND_NUM
        self.label_color = colors.TRF_BUTTONS
        self.label_color_num = colors.TRF_BUTTONS_NUM
        self.widget_border_length = 1
        self.widget_border_color = colors.BLACK

        self.widget_button_color = colors.TRF_WIDGET_BUTTONS
        self.widget_button_color_num = colors.TRF_WIDGET_BUTTONS_NUM

        self.control_color = colors.TRF_CONTROL
        
        self.selected_widget = colors.TRF_SELECTED_WIDGET
        self.selected_widget_num = colors.TRF_SELECTED_WIDGET_NUM

        self.unselected_widget = colors.TRF_UNSELECTED_WIDGET
        self.unselected_widget_num = colors.TRF_UNSELECTED_WIDGET_NUM

        self.preset_color = colors.TRF_PRESET_WIDGET
        self.preset_color_num = colors.TRF_PRESET_WIDGET_NUM
        self.header_color = colors.TRF_HEADERS
        self.build_type = BUILD_TYPE
        if BUILD_TYPE == 'TRF':
            self.border_color = colors.TRF_BORDER
        else:
            self.border_color = colors.BNC_BORDER
        self.button_text_color = colors.WHITE

        self._dsp_options = {}
        self._options = {}
        self._window_options = WindowOptions().state
        self._plot_options = PlotState().state
        self._marker_options = MarkerState().state
        self._trace_options = TraceState().state
        self._tab_options = TabState().state
        self._app_options = AppState().state
        self._warning_state = warningState().state
        self.developer_mode = developer_mode
        self.was_sweeping = False

    def preset_all(self):
        """
        Preset all of the RTSA's current settings
        """
        self._window_options = WindowOptions().state
        self._plot_options = PlotState().state
        self._marker_options = MarkerState().state
        self._trace_options = TraceState().state
        self._tab_options = TabState().state
        self._app_options = AppState().state
       # apply trace state
        for t in self._trace_options:

            self.trace_change.emit(t, dict(self._trace_options), self._trace_options[0].keys())
        self.device_change.emit(self._dut)

        state_json = dict(
            self._dut.properties.SPECA_DEFAULTS,
            device_identifier=self._dut.device_id)

        self._apply_complete_settings(state_json, bool(self._playback_file))
        
    def preset_markers(self):
        """
        Preset the markers
        """
        self._marker_options = MarkerState().state

        # apply marker state
        changes = self._marker_options[0].keys()

        # disable peak left/right and center
        changes.remove('peak')
        changes.remove('peak_left')
        changes.remove('peak_right')
        changes.remove('next_peak')
        changes.remove('center')
        for m in self._marker_options:
            self.marker_change.emit(m, dict(self._marker_options), changes)

    def set_device(self, dut=None, playback_filename=None):
        """
        Detach any currenly attached device and stop playback then
        optionally attach to a new device or playback file.

        :param dut: a :class:`pyrf.thinkrf.WSA` or None
        :param playback_filename: recorded VRT data filename or None
        :param playback_scheduler: function to schedule each playback capture
        """
        if self._playback_file:
            self._playback_file.close()
            self._playback_file = None

        if self._dut:
            self._dut.disconnect()

        if playback_filename:
            self._playback_file = open(playback_filename, 'rb')
            self._playback_started = False
            self._playback_context = {}
            vrt_packet = self._playback_vrt(auto_rewind=False)
            state_json = vrt_packet.fields['speca']
            # support old playback files
            if state_json['device_identifier'] == 'unknown':
                state_json['device_identifier'] = 'ThinkRF,WSA5000 v3,0,0'
            dut = Playback(state_json['device_class'],
                state_json['device_identifier'])
            self._sweep_device = SweepDevice(dut)
            self._capture_device = CaptureDevice(dut)
        elif dut:
            dut.reset()
            self._sweep_device = SweepDevice(dut, self.process_sweep)
            self._capture_device = CaptureDevice(dut, self.process_capture)
            state_json = dict(
                dut.properties.SPECA_DEFAULTS,
                device_identifier=dut.device_id)

        self._dut = dut
        if not dut:
            return

        self.device_change.emit(dut)
        self._apply_complete_settings(state_json, bool(self._playback_file))

        self.start_capture()

    def start_recording(self, filename):
        """
        Start a new recording. Does nothing if we're
        currently playing a recording.
        """
        if self._playback_file:
            return
        self.stop_recording()
        self._recording_file = open(filename, 'wb')
        self._dut.set_recording_output(self._recording_file)
        self._dut.inject_recording_state(self._state.to_json_object())

    def stop_recording(self):
        """
        Stop recording or do nothing if not currently recording.
        """
        if not self._recording_file:
            return
        self._dut.set_recording_output(None)
        self._recording_file.close()
        self._recording_file = None

    def start_csv_export(self, filename):
        """
        Start exporting datainto CSV file
        """
        self._csv_file = open(filename, 'wb')
        self._csv_file.write('data,mode,fstart,fstop,size,timestamp\n')
        self._export_csv = True

    def stop_csv_export(self):
        """
        Stop exporting data into  CSV file
        """
        self._csv_file.close()
        self._export_csv = False

    def _export_csv_file(self, mode, fstart, fstop, data):
        """
        Save data to csv file
        """
        time = datetime.isoformat(datetime.utcnow()) + 'Z'
        self._csv_file.write(',%s,%0.2f,%0.2f,%d,%s\n' % (mode, fstart, fstop, len(data), time))
        for d in data:
            self._csv_file.write('%0.2f\n' % d)

    def _apply_pending_user_xrange(self):
        if self._pending_user_xrange:
            self._applying_user_xrange = True
            start, stop = self._pending_user_xrange
            self._pending_user_xrange = None
            self.apply_settings(
                center=int((start + stop) / 2.0
                    / self._dut.properties.TUNING_RESOLUTION)
                    * self._dut.properties.TUNING_RESOLUTION,
                span=stop - start)
        else:
            self._applying_user_xrange = False

    def read_block(self):
        if not (self._plot_options['cont_cap_mode'] or self._single_capture):
            return
        self._apply_pending_user_xrange()
        device_set = dict(self._state.device_settings)
        device_set['decimation'] = self._state.decimation
        device_set['fshift'] = self._state.fshift
        device_set['rfe_mode'] = self._state.rfe_mode()
        device_set['freq'] = self._state.center
        self._capture_device.configure_device(device_set)

        self._capture_device.capture_time_domain(
            self._state.mode,
            self._state.center,
            self._state.rbw,
            force_change = self.was_sweeping)
        self.was_sweeping = False
        self._single_capture = False

    def read_sweep(self):
        if not (self._plot_options['cont_cap_mode'] or self._single_capture):
            return
        self._apply_pending_user_xrange()
        device_set = dict(self._state.device_settings)
        device_set.pop('iq_output_path')
        device_set.pop('trigger')

        self._dut.pll_reference(device_set['pll_reference'])
        features = self._dut.properties.SWEEP_SETTINGS
        if 'var_attenuator' in device_set:
            device_set.pop('var_attenuator')
        device_set.pop('pll_reference')
        self._sweep_device.capture_power_spectrum(
            self._state.center - self._state.span / 2.0,
            self._state.center + self._state.span / 2.0,
            self._state.rbw,
            device_set,
            mode=self._state.rfe_mode())
        self.was_sweeping = True
        self._single_capture = False

    def start_capture(self, single = False):
        self._single_capture = single
        if self._playback_file:
            self.schedule_playback()
        elif self._state.sweeping():
            self.read_sweep()
        else:
            self.read_block()

    def schedule_playback(self):
        if self._single_capture:
            self._playback_started = False
        if not self._playback_started:
            QtCore.QTimer.singleShot(0, self._playback_step)
            self._playback_started = True

    def _playback_step(self, single = False):

        if not (self._plot_options['cont_cap_mode'] or self._single_capture):
            return
        if not self._playback_file:
            self._playback_started = False
            return

        QtCore.QTimer.singleShot(PLAYBACK_STEP_MSEC, self._playback_step)
        while True:

            pkt = self._playback_vrt()

            if pkt.is_context_packet():
                if 'speca' in pkt.fields:
                    self._playback_sweep_data = None
                    state_json = pkt.fields['speca']
                    self._apply_complete_settings(state_json, playback=True)
                else:
                    self._playback_context.update(pkt.fields)
                continue

            if self._state.sweeping():
                if not self._playback_sweep_step(pkt):
                    continue
                self._single_capture = False
                return
            break

        usable_bins = compute_usable_bins(
            self._dut.properties,
            self._state.rfe_mode(),
            len(pkt.data),
            self._state.decimation,
            self._state.fshift)

        usable_bins, fstart, fstop = adjust_usable_fstart_fstop(
            self._dut.properties,
            self._state.rfe_mode(),
            len(pkt.data),
            self._state.decimation,
            self._state.center,
            pkt.spec_inv,
            usable_bins)
        
        pow_data = compute_fft(
            self._dut,
            pkt,
            self._playback_context,
            **self._dsp_options)

        if not self._options.get('show_attenuated_edges'):
            pow_data, usable_bins, fstart, fstop = (
                trim_to_usable_fstart_fstop(
                    pow_data, usable_bins, fstart, fstop))
        if self._export_csv:
            self._export_csv_file(self._state.rfe_mode(), fstart, fstop, pow_data)
        
        self.capture_receive.emit(
            self._state,
            fstart,
            fstop,
            pkt,
            pow_data,
            usable_bins,
            None)

    def _playback_sweep_start(self):
        """
        ready a new playback sweep data array
        """
        nans = np.ones(int(self._state.span / self._state.rbw)) * np.nan
        self._playback_sweep_data = nans

    def _playback_sweep_step(self, pkt):
        """
        process one data packet from a recorded sweep and
        plot collected data after receiving complete sweep.

        returns True if data was plotted on this step.
        """
        if self._playback_sweep_data is None:
            self._playback_sweep_start()
            last_center = None
        else:
            last_center = self._playback_sweep_last_center

        sweep_start = float(self._state.center - self._state.span / 2)
        sweep_stop = float(self._state.center + self._state.span / 2)
        step_center = self._playback_context['rffreq']
        updated_plot = False
        if last_center is not None and last_center >= step_center:
            # starting a new sweep, plot the data we have
            self.capture_receive.emit(
                self._state,
                sweep_start,
                sweep_stop,
                None,
                self._playback_sweep_data,
                None,
                None)
            updated_plot = True
            self._playback_sweep_start()
        self._playback_sweep_last_center = step_center

        usable_bins = compute_usable_bins(
            self._dut.properties,
            self._state.rfe_mode(),
            len(pkt.data),
            self._state.decimation,
            self._state.fshift)

        usable_bins, fstart, fstop = adjust_usable_fstart_fstop(
            self._dut.properties,
            self._state.rfe_mode(),
            len(pkt.data),
            self._state.decimation,
            step_center,
            pkt.spec_inv,
            usable_bins)

        pow_data = compute_fft(
            self._dut,
            pkt,
            self._playback_context,
            **self._dsp_options)

        pow_data, usable_bins, fstart, fstop = (
            trim_to_usable_fstart_fstop(
                pow_data, usable_bins, fstart, fstop))

        clip_left = max(sweep_start, fstart)
        clip_right = min(sweep_stop, fstop)
        sweep_points = len(self._playback_sweep_data)
        point_left = int((clip_left - sweep_start) * sweep_points / (
            sweep_stop - sweep_start))
        point_right = int((clip_right - sweep_start) * sweep_points / (
            sweep_stop - sweep_start))
        xvalues = np.linspace(clip_left, clip_right, point_right - point_left)

        if point_left >= point_right:
            logger.info('received sweep step outside sweep: %r, %r' %
                ((fstart, fstop), (sweep_start, sweep_stop)))
        else:
            self._playback_sweep_data[point_left:point_right] = np.interp(
                xvalues, np.linspace(fstart, fstop, len(pow_data)), pow_data)

        return updated_plot


    def _playback_vrt(self, auto_rewind=True):
        """
        Return the next VRT packet in the playback file
        """
        reader = vrt_packet_reader(self._playback_file.read)
        data = None
        try:
            while True:
                data = reader.send(data)
        except StopIteration:
            pass
        except ValueError:
            return None

        if data == '' and auto_rewind:
            self._playback_file.seek(0)
            data = self._playback_vrt(auto_rewind=False)

        return None if data == '' else data


    def process_capture(self, fstart, fstop, data):
        # store usable bins before next call to capture_time_domain
        usable_bins = list(self._capture_device.usable_bins)

        # only read data if WSA digitizer is used
        if 'DIGITIZER' in self._state.device_settings['iq_output_path']:
            if self._state.sweeping():
                self.read_sweep()
                return
            self.read_block()
            if 'reflevel' in data['context_pkt']:
                self._ref_level = data['context_pkt']['reflevel']

            pow_data = compute_fft(
                self._dut,
                data['data_pkt'],
                data['context_pkt'],
                ref=self._ref_level,
                **self._dsp_options)

            if not self._options.get('show_attenuated_edges'):
                pow_data, usable_bins, fstart, fstop = (
                    trim_to_usable_fstart_fstop(
                        pow_data, usable_bins, fstart, fstop))

            if pow_data.any():
                if self._plot_options.get('reference_offset_value'):
                    pow_data += self._plot_options['reference_offset_value']
                if self._export_csv:
                    self._export_csv_file(self._state.rfe_mode(), fstart, fstop, pow_data)
                fstart = self._state.center - (self._state.span / 2)
                fstop = self._state.center + (self._state.span / 2)

                self.detect_saturation(pow_data)

                self.capture_receive.emit(
                    self._state,
                    fstart,
                    fstop,
                    data['data_pkt'],
                    pow_data,
                    usable_bins,
                    None)

    def detect_saturation(self, pow_data):
        attenuation = 0
        features = self._dut.properties.SWEEP_SETTINGS
        if'attenuator' in features:
            if self._state.device_settings['attenuator']:
                attenuation += 20
        if'var_attenuator' in self._state.device_settings:
            attenuation += self._state.device_settings['var_attenuator']
        saturation =  self._dut.properties.SATURATION_LEVEL + attenuation
        p1db = self._dut.properties.P1DB_LEVEL

        if max(pow_data) > p1db:
            self.emit_warning(saturation = True)
        elif max(pow_data) > saturation:
            self.emit_warning(saturation = True)
        else:
            self.emit_warning(saturation = False)

    def process_sweep(self, fstart, fstop, data):
        sweep_segments = list(self._sweep_device.sweep_segments)
        if not self._state.sweeping():
            self.read_block()
            return
        self.read_sweep()

        self.pow_data = data
        self.iq_data = None

        if not self._options.get('show_sweep_steps'):
            sweep_segments = None
        if self._plot_options.get('reference_offset_value'):
            self.pow_data += self._plot_options['reference_offset_value']
        if self._export_csv:
            self._export_csv_file(self._state.rfe_mode(), fstart, fstop, self.pow_data)
        self.detect_saturation(self.pow_data)
        self.capture_receive.emit(
            self._state,
            fstart,
            fstop,
            None,
            self.pow_data,
            None,
            sweep_segments)

    def _state_changed(self, state, changed):
        """
        Emit signal and handle special cases where extra work is needed in
        response to a state change.
        """
        # make sure resolution of center are the same as the device's tunning resolution
        if not hasattr(self._dut, 'properties'):
            return
        center = float(np.round(state.center, -1 * int(np.log10(self._dut.properties.TUNING_RESOLUTION))))
        state = SpecAState(state, center=center)
        rfe_mode = state.rfe_mode()
        
        
        if 'span' in changed:
            # change rbw based on span value if auto rbw is on
            rbw_values = calculate_rbw_values(state, self._dut.properties)
            if self._plot_options['rbw_auto'] and not self._loading_config:
                new_rbw = auto_config_rbw(state, self._dut.properties)
                changed.append('rbw')
                state = SpecAState(state, rbw=new_rbw)

        if not state.sweeping():
            # force span to correct value for the mode given
            if state.decimation > 1:
                span = (float(self._dut.properties.FULL_BW[rfe_mode])
                    / state.decimation * self._dut.properties.DECIMATED_USABLE)
            else:
                span = self._dut.properties.USABLE_BW[rfe_mode]

            state = SpecAState(state, span=span)
            changed = [x for x in changed if x != 'span']
            if not self._state or span != self._state.span:
                changed.append('span')
            if 'mode' in changed and not self._loading_config:
                if rfe_mode == 'HDR' or self._state.rfe_mode() == 'HDR':
                    rbw = self._dut.properties.RBW_VALUES[rfe_mode][self._dut.properties.DEFAULT_RBW_INDEX]
                    changed.append('rbw')
                    state = SpecAState(state, rbw=rbw)

        elif 'mode' in changed and 'span' not in changed:
            # if get into or leaving HDR mode
            if rfe_mode == 'HDR' or self._state.rfe_mode() == 'HDR':
                if not self._loading_config:
                    rbw = self._dut.properties.RBW_VALUES[rfe_mode][self._dut.properties.DEFAULT_RBW_INDEX]
                    state = SpecAState(state, rbw=rbw)
                    changed.append('rbw')
                span = self._dut.properties.DEFAULT_SWEEP_SPAN
                state = SpecAState(state, span=span)
                changed.append('span')
            if self._state.rfe_mode() == 'DD':
                state = SpecAState(state, center = 81.25e6)
                changed.append('center')
        self._state = state

        if self._plot_options['vbw_auto'] and not self._loading_config:
            self.apply_plot_options(vbw = state.rbw / self._plot_options['vbw_ratio'])
        # start capture loop again when user switches output path
        # back to the internal digitizer XXX: very WSA5000-specific
        if 'device_settings.iq_output_path' in changed:
            if state.device_settings.get('iq_output_path') == 'DIGITIZER':
                self.start_capture()
            elif state.device_settings.get('iq_output_path') == 'CONNECTOR':
                if state.sweeping():
                    state.mode = self._dut.properties.RFE_MODES[0]
        
        # update channel power region based on change in center or span
        if 'center' in changed:
            span = max(self._plot_options['channel_power_region']) - min(self._plot_options['channel_power_region'])
            fstart = state.center - (span / 2)
            fstop = state.center + (span / 2)
            self.apply_plot_options(channel_power_region = (fstart, fstop))
        if self._recording_file:
            self._dut.inject_recording_state(state.to_json_object())

        self.state_change.emit(state, changed)

    def apply_device_settings(self, **kwargs):
        """
        Apply device-specific settings and trigger a state change event.
        :param kwargs: keyword arguments of SpecAState.device_settings
        """
        features = self._dut.properties.SWEEP_SETTINGS
        device_settings = dict(self._state.device_settings, **kwargs)
        state = SpecAState(self._state, device_settings=device_settings)
        if 'var_attenuator' in kwargs:
            if 'var_attenuator' in features:
                self._dut.var_attenuator(device_settings['var_attenuator'])
                
        if device_settings.get('iq_output_path') == 'CONNECTOR' or 'trigger' in kwargs:
            self._capture_device.configure_device(device_settings)

        changed = ['device_settings.%s' % s for s in kwargs]

        self._state_changed(state, changed)

    def apply_settings(self, **kwargs):
        """
        Apply state settings and trigger a state change event.

        :param kwargs: keyword arguments of SpecAState attributes
        """
        if self._state is None:
            logger.warn('apply_settings with _state == None: %r' % kwargs)
            return

        state = SpecAState(self._state, **kwargs)
        self._state_changed(state, kwargs.keys())

    def _apply_complete_settings(self, state_json, playback):
        """
        Apply state setting changes from a complete JSON object. Used for
        initial settings and applying settings from a recording.
        """
        if self._state:
            old = self._state.to_json_object()
            old['playback'] = self._state.playback
        else:
            old = {}

        changed = [
            key for key, value in state_json.iteritems()
            if old.get(key) != value
            ]
        if old.get('playback') != playback:
            changed.append('playback')

        if 'device_settings' in changed:
            changed.remove('device_settings')
            oset = old.get('device_settings', {})
            dset = state_json['device_settings']
            changed.extend([
                'device_settings.%s' % key for key, value in dset.iteritems()
                if oset.get(key) != value])

        state = SpecAState.from_json_object(state_json, playback)
        
        self._state_changed(state, changed)

       # apply trace state
        for t in self._trace_options:
            if t >= 0 :
                self.trace_change.emit(t, dict(self._trace_options), self._trace_options[0].keys())
            else:
                self.trace_change.emit(t, dict(self._trace_options), self._trace_options[-1].keys())
        # apply marker state
        changes = self._marker_options[0].keys() + self._marker_options[-1].keys()
        # disable peak left/right and center
        changes.remove('peak')
        changes.remove('peak_left')
        changes.remove('peak_right')
        changes.remove('center')
        changes.remove('next_peak')
        changes.remove('point_right')
        changes.remove('point_left')
        for m in self._marker_options:
            self.marker_change.emit(m, dict(self._marker_options), changes)

        # apply plot state
        self.plot_change.emit(dict(self._plot_options),
            self._plot_options.keys())

        # apply window state
        self.window_change.emit(dict(self._window_options),
            self._window_options.keys())

        # apply app state
        self.app_change.emit(dict(self._app_options),
            self._app_options.keys())

    def apply_options(self, **kwargs):
        """
        Apply menu options and signal the change
        :param kwargs: keyword arguments of the dsp options
        """
        self._options.update(kwargs)
        self.options_change.emit(dict(self._options),
            kwargs.keys())

        for key, value in kwargs.iteritems():
            if key.startswith('dsp.'):
                self._dsp_options[key[4:]] = value

    def emit_warning(self, **kwargs):
        """
        Emit a warning signal to the UI
        """
        self._warning_state.update(kwargs)
        self.warning_change.emit(dict(self._warning_state),
            kwargs.keys())

    def apply_plot_options(self, **kwargs):
        """
        Apply plot option changes and signal the change
        :param kwargs: keyword arguments of the plot options
        """
        if self._dut is not None:
            features = self._dut.properties.SWEEP_SETTINGS
            saturation_level =  self._dut.properties.SATURATION_LEVEL     
            if 'ref_level' in kwargs:
                if self._app_options['auto_atten']:
                    if kwargs['ref_level'] > saturation_level:
                        if 'attenuator' in features:
                                self.apply_device_settings(attenuator = True)
                        if 'var_attenuator' in features:
                            atten_val = abs(saturation_level - kwargs['ref_level'])
                            self.apply_device_settings(var_attenuator = atten_val)
        if 'vbw_auto' in kwargs:
            auto_vbw = kwargs['vbw_auto']
        else:
            auto_vbw = self._plot_options['vbw_auto']

        if 'vbw' in kwargs and 'vbw_ratio' not in kwargs:
            if auto_vbw:
                kwargs['vbw_ratio'] = self._state.rbw / kwargs['vbw'] 

        if 'vbw_ratio' in kwargs and not self._loading_config:
            if self._plot_options['vbw_auto']:
                kwargs['vbw'] = self._state.rbw / kwargs['vbw_ratio']

        if 'vbw_auto' in kwargs and not self._loading_config:
            if kwargs['vbw_auto']:
                kwargs['vbw'] = self._state.rbw / self._plot_options['vbw_ratio']

        self._plot_options.update(kwargs)
        self.plot_change.emit(dict(self._plot_options),
                              kwargs.keys())
        if 'rbw_auto' in kwargs and not self._loading_config:
            if kwargs['rbw_auto']:
                new_rbw = auto_config_rbw(self._state, self._dut.properties)
                self.apply_settings(rbw = new_rbw)
    def apply_tab_options(self, **kwargs):
        """
        Apply tab option changes and signal the change
        :param kwargs: keyword arguments of the tab options
        """
        # if peak is clicked turn on marker 1 and peak
        if 'selected_marker_tab' in kwargs:
            if 'Mkr' in kwargs['selected_marker_tab']:
                enable = True
                for m in self._marker_options:
                    if m != -1:
                        if self._marker_options[m]['enabled']:
                            enable = False
                if enable:
                    self.apply_marker_options(0, ['type', 'enabled'], ['Normal', True])
                    self.apply_marker_options(-1, ['selected_marker'], [0])

        self._tab_options.update(kwargs)
        self.tab_change.emit(dict(self._tab_options),
                            kwargs.keys())

    def apply_app_options(self, **kwargs):
        """
        Apply the current state of the application
        :param kwargs: keyword arguments of the tab options
        """
        if 'active_num_control' in kwargs and self._loading_config:
            kwargs['active_num_control'] = None
        if 'capture_mode' in kwargs:
            kwargs['measurement_mode'] = 'Analyzer'
            if kwargs['capture_mode'] == 'RTSA':
                rfe_mode = self._dut.properties.RFE_MODES[0]
                self.apply_settings(mode= rfe_mode)
            else:
                sweep_mode = self._dut.properties.SPECA_MODES[0]
                self.apply_settings(mode=sweep_mode)
        self._app_options.update(kwargs)
        if 'measurement_mode' in kwargs:
            if kwargs['measurement_mode'] == 'Channel Power':
                self.apply_marker_options(-1, ['show_table'], [False])
        
        if 'selected_trace_tab' in kwargs:
            trace = kwargs['selected_trace_tab']
            if self._trace_options[trace]['mode'] == 'Off':
                self.apply_trace_options(trace, ['mode', 'pause'], ['Clear/Write', False])

        self.app_change.emit(dict(self._app_options),
                            kwargs.keys())

    def apply_marker_options(self, marker, changed, value):
        """
        Apply marker changes and signal the change
        :param marker: marker affected by change
        :param changed: a list of the changes which occurred
        :param value: a list of values corresponding to the changes
        """

        if 'selected_marker' in changed and marker == -1:
                if not self._marker_options[value[0]]['enabled']:
                    self.apply_marker_options(value[0], ['type', 'enabled'], ['Normal', True])
        if 'peak' in changed or 'point' in changed:
            for p in ['peak', 'peak_left', 'peak_right', 'next_peak']:
                if p in changed:
                    continue
                changed.append(p)
                value.append(False)
        # if a marker is enabled, default to current center frequency
        if 'enabled' in changed:
            if value[changed.index('enabled')]:
                if 'Search' in self._tab_options['selected_marker_tab']:
                        changed.append('peak')
                        value.append(True)
                else:
                        changed.append('freq')
                        value.append(self._state.center)

        for i, c in enumerate(changed):
            self._marker_options[marker].update({c : value[i]})
        self.marker_change.emit(marker, dict(self._marker_options), changed)

    def apply_trace_options(self, trace, changed, value):
        """
        Apply trace changes and signal the change

        :param trace: trace affected by change
        :param changed: the change which occurred
        :param value: a list of values corresponding to the changes
        """

        for i, c in enumerate(changed):
            self._trace_options[trace].update({c : value[i]})
        self.trace_change.emit(trace, dict(self._trace_options), changed)

    def get_options(self):
        return dict(self._options)

    def apply_window_options(self, **kwargs):
        """
        Apply window options and signal the change

        :param kwargs: keyword arguments of the window options
        """

        self._window_options.update(kwargs)
        self.window_change.emit(dict(self._window_options),
            kwargs.keys())

    def enable_user_xrange_control(self, enable):
        self._user_xrange_control_enabled = enable
        if not enable:
            self._pending_user_xrange = None

    def user_xrange_changed(self, start, stop):
        if self._user_xrange_control_enabled:
            self._pending_user_xrange = start, stop

    def applying_user_xrange(self):
        return self._applying_user_xrange

    def save_settings(self, dir):
        cfgfile = open(dir,'w')
        config = ConfigParser.SafeConfigParser()
        state = self._state.to_json_object()

        config.add_section('device_options')
        for s in state:
            if 'dict' in str(type(state[s])):
                for k in state[s]:
                    if 'dict' in str(type(state[s][k])):
                        for j in state[s][k]:
                            option = j
                            value = state[s][k][j]
                            config.set('device_options', option, str(value))
                    else:
                        option = k
                        value = state[s][k]
                        config.set('device_options', option, str(value))
                continue

            else:
                option = s
                value = state[s]
            config.set('device_options', option, str(value))

        config.add_section('plot_options')
        for p in self._plot_options:
            if 'dict' in str(type(self._plot_options[p])):
                for l in self. _plot_options[p]:
                    option = l
                    value = str(self._plot_options[p][l])
                    config.set('plot_options', option, value)
                continue
            config.set('plot_options', p, str(self._plot_options[p]))

        config.add_section('app_options')
        for p in self._app_options:
            config.set('app_options', p, str(self._app_options[p]))

        config.add_section('options')
        for p in self._options:
            config.set('options', p, str(self._options[p]))
        config.add_section('tab_options')
        for p in self._tab_options:
            config.set('tab_options', p, str(self._tab_options[p]))

        config.add_section('window_options')
        for p in self._window_options:
            config.set('window_options', p, str(self._window_options[p]))

        config.add_section('marker_options')
        for p in self._marker_options:
            for s in self._marker_options[p]:
                config.set('marker_options', '%s-%s' % (str(p), s), str(self._marker_options[p][s]))
        
        config.add_section('trace_options')
        for p in self._trace_options:
            for s in self._trace_options[p]:
                config.set('trace_options', '%s-%s' % (str(p), s), str(self._trace_options[p][s]))
        config.write(cfgfile)
        cfgfile.close()

    def load_settings(self, dir):
        self._loading_config = True
        config = ConfigParser.SafeConfigParser()
        found_vbw = False
        found_vbw_ratio = False
        config.read(dir)
        plot_options = {}
        tab_options = {}
        device_options = {'device_settings': {'trigger': {}}}
        options = {}
        window_options = {}
        app_options = {}

        state = self._state.to_json_object()
        # read plot options
        for p in config.options('plot_options'):
            if p in self._plot_options:
                if p == 'vbw':
                    found_vbw = True
                elif p == 'vbw_ratio':
                    found_vbw_ratio = True
                plot_options[p] = decode_config_type(config.get('plot_options', p), self._plot_options[p])
        
        # read app options
        for p in config.options('app_options'):
            if p in self._app_options:
                app_options[p] = decode_config_type(config.get('app_options', p), self._app_options[p])
        # read tab options
        for p in config.options('tab_options'):
            if p in self._plot_options:
                tab_options[p] = decode_config_type(config.get('tab_options', p), self._tab_options[p])
        # read device options
        for s in config.options('device_options'):
            if s in state:
                device_options[s] = decode_config_type(config.get('device_options', s), state[s])
            elif s in state['device_settings']:
                device_options['device_settings'][s] = decode_config_type(config.get('device_options', s), state['device_settings'][s])
            elif s in state['device_settings']['trigger']:
                device_options['device_settings']['trigger'][s] = decode_config_type(config.get('device_options', s), state['device_settings']['trigger'][s])
        
        # if no vbw was in config file, make vbw equal the rbw
        if not found_vbw:
            plot_options['vbw'] = device_options['rbw']
        if not found_vbw_ratio:
            plot_options['vbw_ratio'] = device_options['rbw'] / plot_options['vbw']
        for p in config.options('options'):
            options[p] = decode_config_type(config.get('options', p), self._options[p])

        for p in config.options('window_options'):
            window_options[p] = decode_config_type(config.get('window_options', p), self._window_options[p])

        # update marker settings
        for p in config.options('marker_options'):
            if p[0] == '-':
                name = -1
                property = p.split('-')[-1]
            else:
                name = int(p.split('-')[0])
                property = p.split('-')[1]  
            if property in self._marker_options[name]:
                self._marker_options[name][property] = decode_config_type(config.get('marker_options', p), self._marker_options[name][property])

        # update trace settings
        for p in config.options('trace_options'):
            if p[0] == '-':
                name = -1
                property = p.split('-')[-1]
            else:
                name = int(p.split('-')[0])
                property = p.split('-')[1]
            if property in self._trace_options[name]:
                self._trace_options[name][property] = decode_config_type(config.get('trace_options', p), self._trace_options[name][property])

        self.apply_options(**options)
        self.apply_window_options(**window_options)
        
        # add config to inform plot options that a config has been laoded
        plot_options['config'] = True
        self.apply_plot_options(**plot_options)
        self._apply_complete_settings(device_options, False)
        self._loading_config = False