import pyqtgraph as pg
import numpy as np
from PySide import QtCore, QtGui
import colors
from pyrf.units import M
from gui_config import MarkerState, TraceState, TabState
from pyrf.numpy_util import calculate_channel_power
from util import smooth, create_traingle_painter
LARGE_NEGATIVE_NUMBER = -900000

# minimum size allowed for auto peak
MIN_AUTO_POS_SIZE = 1000
AREA_AVOID_PERC = 0.02
PEAK_PERC = 0.9
class triggerControl(pg.ROI):
    """
    Class to represent the trigger controls in the plot
    """
    # sigHovering = QtCore.Signal(object)
    # sigHoveringFinished = QtCore.Signal(object)
    sigNewTriggerRange = QtCore.Signal(object)
    def __init__(self):
        super(triggerControl, self).__init__(pos=(0,0))

        self.normal_pen = pg.mkPen(color = colors.WHITE_NUM, width= 2)
        self.setPen(self.normal_pen)
        self.hover_pen = pg.mkPen(color = colors.LIME_NUM, width= 2)
        self.fstart = 0
        self.fstop = 0
        self.amplitude = 0

        self.init_lines()
        self.sigRegionChangeFinished.connect(self.new_trigger)
        self.sigRegionChangeStarted.connect(self.begin_changing)

    def begin_changing(self):
        for l in self.lines:
            l.blockSignals(True)

    def new_trigger(self):
        self.fstart = self.pos().x()
        self.fstop = self.fstart + self.size().x()
        self.amplitude = self.size().y() + self.pos().y()
        self.fstart_line.setValue(self.fstart)

        self.fstop_line.setValue(self.fstop)
        self.amplitude_line.setValue(self.amplitude)
        self.sigNewTriggerRange.emit(self)
        for l in self.lines:
            l.blockSignals(False)

    def init_lines(self):
        self.lines = []
        cursor_pen = pg.mkPen((0,0,0,0), width = 50)
        self.fstart_line = InfiniteLine(pen = cursor_pen, pos = -100, angle = 90, movable = True)
        self.lines.append(self.fstart_line)

        self.fstop_line = InfiniteLine(pen = cursor_pen, pos = -100, angle = 90, movable = True)
        self.lines.append(self.fstop_line)

        self.amplitude_line = InfiniteLine(pen = cursor_pen, pos = -100, angle = 0, movable = True)
        self.lines.append(self.amplitude_line)

        for l in self.lines:
            def hovering():
                self.setPen(self.hover_pen)

            def not_hovering():
                self.setPen(self.normal_pen)


            l.setHoverPen(cursor_pen)
            l.sigHovering.connect(hovering)
            l.sigHoveringFinished.connect(not_hovering)

        def changing_fstart():
            self.setPen(self.hover_pen)
            self.resize_trigger(self.fstart_line.value(),
                                self.fstop,
                                self.amplitude)
        self.fstart_line.sigPositionChanged.connect(changing_fstart)

        def finished_changing_fstart():
            self.setPen(self.normal_pen)
            self.sigNewTriggerRange.emit(self)
        self.fstart_line.sigPositionChangeFinished.connect(finished_changing_fstart)

        def changing_fstop():
            self.setPen(self.hover_pen)
            self.resize_trigger(self.fstart,
                                self.fstop_line.value(),
                                self.amplitude)
        self.fstop_line.sigPositionChanged.connect(changing_fstop)

        def finished_changing_fstop():
            self.setPen(self.normal_pen)
            self.sigNewTriggerRange.emit(self)
        self.fstop_line.sigPositionChangeFinished.connect(finished_changing_fstop)

        def changing_amp():
            self.setPen(self.hover_pen)
            self.resize_trigger(self.fstart,
                                self.fstop,
                                self.amplitude_line.value())
        self.amplitude_line.sigPositionChanged.connect(changing_amp)

        def finished_changing_amplitude():
            self.setPen(self.normal_pen)
            self.sigNewTriggerRange.emit(self)
        self.amplitude_line.sigPositionChangeFinished.connect(finished_changing_amplitude)

    def resize_trigger(self, start, stop, amp):
        self.blockSignals(True)
        self.fstart = start
        self.fstop = stop
        self.amplitude = amp
        span = stop - start
        self.setPos(((start), LARGE_NEGATIVE_NUMBER))
        self.setSize((span, (-1 * LARGE_NEGATIVE_NUMBER) - np.abs(amp)))
        self.fstart_line.setValue(start)

        self.fstop_line.setValue(stop)
        self.amplitude_line.setValue(amp)
        self.blockSignals(False)

    def setMouseHover(self, hover):

        if self.mouseHovering == hover:
            return
        self.mouseHovering = hover
        if hover:
            self.currentPen = self.hover_pen
        else:
            self.currentPen = self.pen
        self.update()
 
class Trace(object):
    """
    Class to represent a trace in the plot
    """
    store = False
    data = None
    raw_packet = None
    freq_range = [0.0, 0.0]
    average_list = []
    average_factor = 100
    calc_channel_power = False
    channel_power = 0
    channel_power_range = [0.0, 0.0]
    curves = []

    smooth_factor = None
    def __init__(self,plot_area, controller, trace_name, trace_color, blank = False, write = False):
        self.name = trace_name
        self.blank = blank

        self.controller = controller
        controller.trace_change.connect(self.trace_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        controller.app_change.connect(self.app_changed)
        self.color = trace_color
        self.plot_area = plot_area
        self.curve = self.plot_area.spectral_plot.plot()
    def clear(self):
        for c in self.curves:
            self.plot_area.spectral_plot.removeItem(c)
        self.curves = []
        
        self.plot_area.spectral_plot.removeItem(self.curve)
    def clear_data(self):
        self.average_list = []
        self.data = None

    def compute_channel_power(self):
        
        if self.calc_channel_power and not self.blank:
            if min(self.channel_power_range) > min(self.freq_range) and max(self.channel_power_range) < max(self.freq_range):
                    if self.data is not None:
                        min_bin = (np.abs(self.freq_range-min(self.channel_power_range))).argmin()
                        max_bin = (np.abs(self.freq_range-max(self.channel_power_range))).argmin()
                        self.channel_power = calculate_channel_power(self.data[min_bin:max_bin])
                        self.controller.apply_trace_options(self.name, ['channel_power'], [self.channel_power])

    def update_curve(self, xdata, ydata, usable_bins, sweep_segments):
        if self.blank or self.store:
            return

        if self._app_state['capture_mode'] == 'Spectrum Analyzer':
            video_factor = self._gui_state.rbw / self._plot_state['vbw']
            if video_factor > 1:
                ydata = smooth(ydata, int(video_factor))

        self.freq_range = xdata
        if self._trace_state[self.name]['mode'] == 'Max Hold':
            if (self.data is None or len(self.data) != len(ydata)):
                self.data = ydata
            self.data = np.maximum(self.data,ydata)

        elif self._trace_state[self.name]['mode'] == 'Min Hold':
            if (self.data is None or len(self.data) != len(ydata)):
                self.data = ydata
            self.data = np.minimum(self.data,ydata)

        elif self._trace_state[self.name]['mode'] == 'Clear/Write':
            self.data = ydata

        elif self._trace_state[self.name]['mode'] == 'Trace Average':
            if len(self.average_list) >= self.average_factor:
                self.average_list.pop(0)

            if self.average_list:
                if len(ydata) != len(self.data):
                    self.data = ydata
                    self.average_list = []
            
            self.average_list.append(ydata)
            self.data = np.average(self.average_list, axis = 0)


        self.compute_channel_power()
        if self.controller.developer_mode:
            self.clear()
            if usable_bins:
                # plot usable and unusable curves
                i = 0
                edge_color = tuple([c / 3 for c in self.color])
                for start_bin, run_length in usable_bins:

                    if start_bin > i:
                        c = self.plot_area.spectral_plot.plot(x=xdata[i:start_bin+1],
                            y=self.data[i:start_bin+1], pen=edge_color)
                        self.curves.append(c)
                        i = start_bin
                    if run_length:
                        c = self.plot_area.spectral_plot.plot(x=xdata[i:i+run_length],
                            y=self.data[i:i+run_length], pen=self.color)
                        self.curves.append(c)
                        i = i + run_length - 1
                if i < len(xdata):
                    c = self.plot_area.spectral_plot.plot(x=xdata[i:], y=self.data[i:],
                        pen=edge_color)
                    self.curves.append(c)
            else:
                odd = True
                i = 0
                alternate_color = (
                    max(0, self.color[0] - 60),
                    max(0, self.color[1] - 60),
                    min(255, self.color[2] + 60),)
                if sweep_segments is None:
                    sweep_segments = [len(self.data)]
                for run in sweep_segments:
                    c = self.plot_area.spectral_plot.plot(x=xdata[i:i + run],
                        y=self.data[i:i + run],
                        pen=self.color if odd else alternate_color)
                    self.curves.append(c)
                    i = i + run
                    odd = not odd
        else:
            self.curve.setData(x=xdata, y= self.data, pen=self.color)

    def state_changed(self, state, changed):
        self._gui_state = state

    def plot_changed(self, state, changed):
        self._plot_state = state

    def app_changed(self, state, changed):
        self._app_state = state

    def trace_changed(self, trace, state, changed):
        self._trace_state = state
        if trace == self.name:
            if 'color' in changed:
                self.color = state[trace]['color']
            if 'clear' in changed:
                self.clear_data()
            if 'pause' in changed:
                self.store = state[trace]['pause']
            if 'mode' in changed:
                if state[trace]['mode'] == 'Off':
                    self.blank = True

                    self.clear_data()
                    self.clear()
                else:
                    self.plot_area.spectral_plot.addItem(self.curve)
                    self.blank = False
            if 'mode' in changed:
                if state[trace]['mode'] == 'Trace Average':
                    self.clear_data()
                    self.average_list = []

        if 'average' in changed:
            self.clear_data()
            self.average_list = []
            self.average_factor = state[-1]['average']
                
class Marker(object):
    """
    Class to represent a marker on the plot
    """
    shape = 'd'
    size = 25
    coursor_dragged = False
    enabled = False
    freq_pos = None
    power_pos = None
    hovering = False
    xdata = []
    ydata = []
    # peaks to avoid because marker was already on them
    prev_peaks = []
    trace_index = 0

    def __init__(self, plot_area, marker_name, color, controller, delta = False):

        self.name = marker_name
        self.delta = delta
        self.marker_plot = pg.ScatterPlotItem()
        self.delta_symbol = pg.ScatterPlotItem()
        self.color = color
        self.draw_color = color
        self._plot = plot_area

        self.controller = controller
        controller.marker_change.connect(self.marker_changed)
        controller.trace_change.connect(self.trace_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        self.cursor_pen = pg.mkPen((0,0,0,0), width = 40)
        self.cursor_line = InfiniteLine(pen = self.cursor_pen, pos = -100, angle = 90, movable = True)
        self.cursor_line.setHoverPen(pg.mkPen((0,0,0, 0), width = 40))

        self.cursor_line.sigDragged.connect(self.dragged)
        self.cursor_line.sigPositionChangeFinished.connect(self.finished_dragged)
        self.text_box = pg.TextItem(anchor = (0.5,0.5))
        # self.text_box.setFont("font-size: 30px;")
        def hovering():
            self.coursor_dragged = True
            self.draw_color = colors.MARKER_HOVER
            self.controller.apply_marker_options(self.name, ['hovering'], [True])
        self.cursor_line.sigHovering.connect(hovering)

        def not_hovering():
            self.coursor_dragged = False
            self.draw_color = color
            self.update_pos(self.xdata, self.ydata)
            self.controller.apply_marker_options(self.name, ['hovering'], [False])
        self.cursor_line.sigHoveringFinished.connect(not_hovering)

    def dragged(self):
        # determine freq of drag
        freq = self.cursor_line.value()
        self.coursor_dragged = True
        self.cursor_line.setPen(self.cursor_pen)
        self.draw_color = colors.MARKER_HOVER
        self.controller.apply_plot_options(marker_dragged = True)
        # determine if point matches threshold
        
        if self._marker_state[-1]['peak_thrshold']:
            data_index = np.where(self.xdata == self.xdata[np.abs(self.xdata - freq).argmin()])[0]
            perc_add = int(len(self.xdata) * 0.008)
            pow = self.ydata[data_index]
            if pow > self._marker_state[-1]['thrshold_val']:
                pow = max(self.ydata[int(data_index - perc_add): int(data_index + perc_add)])
                data_index = np.where(self.ydata == pow)[0]
                self.freq_pos = self.xdata[data_index]
            else:
                return
        else:
            self.freq_pos = freq
        self.update_pos(self.xdata, self.ydata)
        
        # only change position if marker is not fixed
        if not self._marker_state[self.name]['type'] == 'Fixed':
            self.controller.apply_marker_options(self.name, ['hovering', 'freq'], [True, self.freq_pos])
        else:
            self.controller.apply_marker_options(self.name, ['hovering'], [True])

    def finished_dragged(self):
        self.prev_peaks = []
        self.controller.apply_marker_options(-1, ['selected_marker'], [self.name])
        if self._marker_state[self.name]['type'] == 'Fixed':
            self.controller.apply_marker_options(self.name, ['freq', 'power'], [self._plot_state['mouse_pos'][0], self._plot_state['mouse_pos'][1]])
    def remove_marker(self):
        self._plot.removeItem(self.marker_plot)
        self._plot.removeItem(self.delta_symbol)
        self._plot.removeItem(self.cursor_line)
        self._plot.removeItem(self.text_box)

    def add_marker(self):
        self._plot.addItem(self.marker_plot)
        self._plot.addItem(self.delta_symbol)
        self._plot.addItem(self.cursor_line)
        self._plot.addItem(self.text_box)

    def enable(self):

        self.enabled = True
        self.add_marker()
        self.controller.apply_plot_options(marker_dragged = True)

    def disable(self):
        self.enabled = False
        self.remove_marker()

    def marker_changed(self, marker, state, changed):
        if not hasattr(self, '_marker_state'):
            self._marker_state = state
        # if marker is not enabled, leave
        if not state[self.name]['enabled']:
            self.disable()
            return

        if 'selected_marker' in changed:
            if self.name == self._marker_state[-1]['selected_marker']:
                self.draw_color = colors.MARKER_HOVER
                self.update_plot()
            else:
                self.draw_color = self.color
                self.update_plot()

        if marker == self.name:
            if 'enabled' in changed:
                if state[marker]['enabled']:
                    self.enable()
                else:
                    self.disable()

            if 'trace' in changed:
                self.trace_index = state[marker]['trace']


            if 'freq' in changed:
                self.freq_pos = state[marker]['freq']
            if 'power' in changed or 'freq' in changed:

                if state[marker]['type'] == 'Fixed':
                    self.ypos = state[marker]['power']
                    self.update_plot()
                if self.name == self._marker_state[-1]['selected_marker']:
                    self.draw_color = colors.MARKER_HOVER
                    self.update_plot()
                else:
                    self.draw_color = self.color
                    self.update_plot()

            if 'reset_peaks' in changed:
                self.prev_peaks = []

            if 'peak' in changed:
                self.prev_peaks = []
                self.find_peak()

            if 'peak_right' in changed:
                if state[self.name]['peak_right']:
                    if not self._marker_state[self.name]['peak_right']:
                        self.prev_peaks = []
                    self.find_right_peak()

            if 'peak_left' in changed:
                if state[self.name]['peak_left']:
                    if not self._marker_state[self.name]['peak_left']:
                        self.prev_peaks = []
                    self.find_left_peak()

            if 'next_peak' in changed:
                if state[self.name]['next_peak']:
                    if not self._marker_state[self.name]['next_peak']:
                        self.prev_peaks = []
                    self.find_next_peak()

            if 'point_left' in changed:

                self.prev_peaks = []
                self.left_point()

            if 'point_right' in changed:
                self.prev_peaks = []
                self.right_point()

            if 'type' in changed:
                if state[marker]['type'] == 'Fixed':
                    self.update_plot()

        self._marker_state = state

    def trace_changed(self, trace, state, changed):
        self._trace_state = state

    def plot_changed(self, state, changed):
        self._plot_state = state

    def state_changed(self, state, changed):
        self._gui_state = state

    def update_data(self, xdata, ydata):
        if xdata is None or ydata is None:
            return
        self.xdata = xdata
        self.ydata = ydata

    def update_pos(self, xdata, ydata):

        if xdata is None or ydata is None:
            return

        if len(xdata) <= 0 or len(ydata) <= 0:
            return

        # return of current state is fixed
        if self._marker_state[self.name]['type'] == 'Fixed':
            return

        # if current frequency position is none, default to current center frequency
        if self.freq_pos is None:
            self.freq_pos = xdata[len(xdata) / 2]
            self.controller.apply_marker_options(self.name, ['freq'], [self.freq_pos])
        
        peak_region = 0.003
        if self._marker_state[self.name]['cont_peak']:
            if max(ydata) > self._marker_state[-1]['thrshold_val']:
                self.ypos = max(ydata)
                self.freq_pos = xdata[np.where(ydata == self.ypos)[0]][0]
                self.controller.apply_marker_options(self.name, ['freq'], [self.freq_pos])
        else:
            if xdata[0] <= self.freq_pos <= xdata[-1]:
                # find index of nearest frequency
                index = np.argmin(np.abs(xdata - self.freq_pos))

                if self._marker_state[self.name]['mouse_latch']:
                    self.ypos = np.max(ydata[max(0, index - (peak_region * len(ydata))): min(len(self.ydata) - 1, index + (peak_region * len(ydata)))])
                else:
                    self.ypos = ydata[index]
            else:
                self.ypos = 0
            self.xdata = xdata
            self.ydata = ydata
        self.update_plot()
        self.update_state_power()

    def update_plot(self):
        if self.freq_pos is None:
            return
        # calculate scale offset for marker
        height = np.abs( max(self._plot.getViewBox().viewRange()[1]) - min(self._plot.getViewBox().viewRange()[1]))
        width = np.abs( max(self._plot.getViewBox().viewRange()[0]) - min(self._plot.getViewBox().viewRange()[0]))
        scale =  height * 0.01
        if self._marker_state[self.name]['type'] == 'Fixed':
            scale = 0
        if not hasattr(self, 'ypos'):
            self.ypos = self._marker_state[self.name]['power']
        # reset current plot
        self.marker_plot.clear()
        self.delta_symbol.clear()
        self._plot.removeItem(self.marker_plot)
        self._plot.addItem(self.marker_plot)

        # determine if marker is highlighted
        if  self.name == self._marker_state[-1]['selected_marker']:
            brush_color = self.draw_color
            self.cursor_line.setValue(self.freq_pos)
            pen_c = self.draw_color
        else:
            brush_color = (255,255,255,0)
            pen_c = colors.WHITE_NUM
        
        # change shape based on marker type
        if  self._marker_state[self.name]['type'] == 'Normal':
            self.shape = 'd'
        elif self._marker_state[self.name]['type'] == 'Fixed':
            self.shape = '+'
        else:
            self.shape = 't'

        # plot the marker
        self.marker_plot.addPoints(x = [self.freq_pos],
                                   y = [self.ypos + scale],
                                    symbol =  self.shape,
                                    size = self.size, pen = pg.mkPen(pen_c),
                                    brush = brush_color)

        y_pos = self.ypos + (0.06 * height)
        d_freq = self.freq_pos + (0.01 * width)
        d_pos = y_pos

        if self._marker_state[self.name]['type'] in ['Normal', 'Fixed']:
            text = str(self.name + 1)
        else:


            text =  str(self.name + 1) + '      ' +  self._marker_state[self.name]['type'][-1]
            
            self.delta_symbol.addPoints(x = [d_freq],
                           y = [d_pos],
                            symbol =  'j',
                            size = self.size / 1.5, pen = pg.mkPen(colors.WHITE_NUM),
                            brush = colors.WHITE_NUM)
        color_txt = 'rgb%s' % str(self.draw_color)
        t = '<font size="12" font face="verdana" bgcolor="%s">%s</font>' % (color_txt, text)
        self.text_box.setHtml(t)
        viewbox = self.text_box.getViewBox()
        self.text_box.setPos(d_freq, y_pos)

    def update_state_power(self):
        if self.ypos == 0:
            power = None
        else:
            power = self.ypos
        self.controller.apply_marker_options(self.name, ['power'], [power])

    def find_peak(self):
        """
        move the marker to the maximum point of the spectrum
        """
        # do nothing if there is no data
        if len(self.xdata) == 0 or len(self.ydata) == 0:
            return
        # retrieve the min/max x-axis of the current window
        window_freq = self._plot.getViewBox().viewRange()[0]
        data_range = self.xdata
        if window_freq[-1] < data_range[0] or window_freq[0] > data_range[-1]:
            return

        min_index, max_index = np.searchsorted(data_range, (window_freq[0], window_freq[-1]))

        peak_value = np.max(self.ydata[min_index:max_index])

        data_index = np.where(self.ydata==peak_value)[0]
        
        # determine if threshold or check excursion conditions are met
        if not self._check_threshold(peak_value):
            return

        self.freq_pos = self.xdata[data_index][0]
        self.ypos = self.ydata[data_index]

        self.controller.apply_marker_options(self.name, ['freq', 'power'], [self.freq_pos, self.ypos])

    def find_next_peak(self):
        """
        move the selected marker to the next peak
        """
        # do nothing if there is no data
        if len(self.xdata) == 0 or len(self.ydata) == 0:
            return

        ydata = self.remove_prev_peaks()
        # if peak threshold
        if self._marker_state[-1]['peak_thrshold']:
            exc_value = self._marker_state[-1]['thrshold_val']
            if self._marker_state[-1]['peak_exc']:
                exc_value += self._marker_state[-1]['exc_val']
            peak_indices = np.where(ydata > exc_value)[0]
            if len(peak_indices) == 0:
                return
            peak_values = []
            for p in peak_indices:
                peak_values.append(ydata[p])
            next_peak = max(peak_values)
            data_index = np.where(self.ydata == next_peak)[0]

        else:
            if self._marker_state[-1]['peak_exc']:
                data_index = np.abs(ydata - (self.ypos - self._marker_state[-1]['exc_val'])).argmin()
                next_peak = self.ypos - self._marker_state[-1]['exc_val']
            else:
                if len(self.prev_peaks) == 0:
                    next_peak = max(ydata)
                else:
                    next_peak = max(ydata[np.where(ydata < self.ypos)])

            data_index = np.where(self.ydata == next_peak)[0]

        self.freq_pos = self.xdata[data_index][0]
        self.controller.apply_marker_options(self.name, ['freq'], [self.freq_pos])
        self.prev_peaks.append(data_index)

    def left_point(self):
        """
        move the selected marker to the next left pointstop frequency
        """
        # do nothing if there is no data
        if len(self.xdata) == 0 or len(self.ydata) == 0:
            return
        try:
            freq_index = np.where(abs(self.xdata - self.freq_pos) == min(abs(self.xdata - self.freq_pos)))[0] - 1
            freq_pos = self.xdata[freq_index][0]
            if self._marker_state[-1]['peak_thrshold']:
                y_above = np.where(self.ydata >= self._marker_state[-1]['thrshold_val'])[0]

                if len(y_above) < 0:
                    return
                freq_index = np.where(y_above <= freq_index)[0]
                freq_pos = self.xdata[y_above[freq_index[-1]]]

            self.controller.apply_marker_options(self.name, ['freq'], [freq_pos])
        except IndexError:
            return

    def right_point(self):
        """
        move the selected marker to the next right point
        """
        # do nothing if there is no data
        if len(self.xdata) == 0 or len(self.ydata) == 0:
            return

        try:
           
            freq_index = np.where(abs(self.xdata - self.freq_pos) == min(abs(self.xdata - self.freq_pos)))[0] + 1
            freq_pos = self.xdata[freq_index][0]
            # if threshold is on, find the point closest to the threshold
            if self._marker_state[-1]['peak_thrshold']:
                y_above = np.where(self.ydata >= self._marker_state[-1]['thrshold_val'])[0]

                if len(y_above) < 0:
                    return
                freq_index = np.where(y_above >= freq_index)[0]
                y_above[freq_index[0]]
                freq_pos = self.xdata[y_above[freq_index[0]]]

            self.controller.apply_marker_options(self.name, ['freq'], [freq_pos])
        except IndexError:
            return

    def find_right_peak(self):
        """
        move the selected marker to the next peak on the right
        """
        # do nothing if there is no data
        if len(self.xdata) == 0 or len(self.ydata) == 0:
            return

        # retrieve the min/max x-axis of the current window
        window_freq = self._plot.getViewBox().viewRange()[0]

        if self.freq_pos >= max(window_freq):
            return
        perc_add = int(len(self.xdata) * AREA_AVOID_PERC)
        min_index = np.min(np.where(self.xdata >= self.freq_pos)) + perc_add
        max_index = len(self.xdata) - 1

        # determine if edge is reached
        if min_index >= max_index:
            return

        # grab the data right of the spectrum
        y_data = self.ydata[min_index:max_index]
        # if peak threshold
        if self._marker_state[-1]['peak_thrshold']:
            peak_values = []
            if self._marker_state[-1]['peak_thrshold']:

                peak_indices = np.where(y_data > self._marker_state[-1]['thrshold_val'])[0]
                for p in peak_indices:
                    peak_values.append(y_data[p])

            if self._marker_state[-1]['peak_exc']:

                exc_value = self._marker_state[-1]['thrshold_val'] + self._marker_state[-1]['exc_val']
                peak_values = [i for i in peak_values if i >exc_value]

        else:
            # if no peak thtreshold, grab top 90% of the peaks
            peak_values = sorted(y_data)[int(PEAK_PERC * len(y_data)):]
            # if exc is active, make sure to only include points within the excursion
            if self._marker_state[-1]['peak_exc']:
                exc_val = self._marker_state[-1]['exc_val']
                peak_values = [i for i in peak_values if i > (self.ypos + exc_val)]

        freq = None
        peak_value = None
        if len(peak_values) == 0:
            return

        for p in peak_values:

            curr_freq = self.xdata[np.where(self.ydata == p)[0]]
            if freq is None:
                freq = curr_freq

            if curr_freq <= freq:
                freq = curr_freq
                peak_value = p

        if peak_value is None:
            return
        data_index = np.where(y_data ==  peak_value)[0]
        peak_value = max(y_data[max(0, data_index - perc_add): min(data_index + perc_add, len(y_data))])
        data_index = np.where(self.ydata ==  peak_value)
        new_pos = self.xdata[data_index]
        if new_pos > max(self.xdata):
            return
        else:
            self.freq_pos = new_pos

        self.controller.apply_marker_options(self.name, ['freq'], self.freq_pos)

    def find_left_peak(self):
        """
        move the selected marker to the next peak on the left
        """
        # do nothing if there is no data
        if len(self.xdata) == 0 or len(self.ydata) == 0:
            return

        # retrieve the min/max x-axis of the current window
        window_freq = self._plot.getViewBox().viewRange()[0]

        if self.freq_pos >= max(window_freq):
            return
        perc_add = int(len(self.xdata) * AREA_AVOID_PERC)
        min_index = 0
        max_index = np.min(np.where(self.xdata >= self.freq_pos)) - perc_add

        # determine if edge is reached
        if max_index <= 0:
            return
        # grab the data right of the spectrum
        y_data = self.ydata[min_index:max_index]
        # if peak threshold
        if self._marker_state[-1]['peak_thrshold']:
            peak_values = y_data
            if self._marker_state[-1]['peak_thrshold']:
                peak_values = [i for i in peak_values if i >self._marker_state[-1]['thrshold_val']]
            if self._marker_state[-1]['peak_exc']:
                exc_value = self._marker_state[-1]['thrshold_val'] + self._marker_state[-1]['exc_val']
                peak_values = [i for i in peak_values if i >exc_value]
        else:
            # if no peak thtreshold, grab top 90% of the peaks
            peak_values = sorted(y_data)[int(PEAK_PERC * len(y_data)):]
            # if exc is active, make sure to only include points within the excursion

            if self._marker_state[-1]['peak_exc']:

                exc_val = self._marker_state[-1]['exc_val']
                peak_values = [i for i in peak_values if i > (self.ypos + exc_val)]

        freq = None
        peak_value = None
        if len(peak_values) == 0:
            return

        for p in peak_values:
            curr_freq = self.xdata[np.where(self.ydata == p)[0]]
            if freq is None:
                freq = curr_freq
                peak_value = p
            if curr_freq > freq:
                freq = curr_freq
                peak_value = p

        if peak_value is None:
            return
        data_index = np.where(y_data ==  peak_value)[0]
        peak_value = max(y_data[max(0, data_index - perc_add): min(data_index + perc_add, len(y_data))])
        data_index = np.where(self.ydata ==  peak_value)
        new_pos = self.xdata[data_index]
        if new_pos > max(self.xdata):
            return
        else:
            self.freq_pos = new_pos
        self.controller.apply_marker_options(self.name, ['freq'], self.freq_pos)

    def _check_threshold(self, peak_value):
        """
        check if threshold allow a marker peak change
        
        """
        # determine if peak is above the peak threshold
        if self._marker_state[-1]['peak_thrshold']:
            if peak_value < self._marker_state[-1]['thrshold_val']:
                return False
        return True

    def remove_prev_peaks(self):
        """
        remove all previous peaks found
        """
        # avoid points that are local, and previous peaks
        avoid = int(AREA_AVOID_PERC * len(self.ydata))
        areas_to_avoid = []

        for p in self.prev_peaks:

            area = np.arange(max(0, p - avoid), min(len(self.ydata), p + avoid), 1)

            areas_to_avoid = np.concatenate([areas_to_avoid, area])
        areas_to_avoid = np.unique(areas_to_avoid)
        ydata = list(self.ydata)
        ydata = np.delete(ydata, areas_to_avoid)
        return ydata

    def _check_excursion(self, data_index):
        """
        check if excursion conditions allow a marker peak change
        """
        # determine if the peak has enough excursion above the noise floor
        peak_value = self.ydata[data_index]
        if self._marker_state[-1]['peak_exc']:
            # only compare to 5% of the spectrum
            perc_spectr = int(len(self.ydata) * 0.05)
            min_index = max(0, data_index - perc_spectr)

            max_index =  min(len(self.ydata), data_index  + perc_spectr)
            surround_noise = np.mean(self.ydata[min_index:max_index])
            if peak_value < surround_noise + self._marker_state[-1]['exc_val']:
                return False
        return True

class InfiniteLine(pg.InfiniteLine):
    """
    Infinite Line with controls over the hover pen (feature will be available in pyqtgraph 0.9.9)
    """
    sigHovering = QtCore.Signal(object)
    sigHoveringFinished = QtCore.Signal(object)
    def setPen(self, *args, **kwargs):
        """Set the pen for drawing the line. Allowable arguments are any that are valid 
        for :func:`mkPen <pyqtgraph.mkPen>`."""
        self.pen = pg.mkPen(*args, **kwargs)
        if not self.mouseHovering:
            self.currentPen = self.pen
            self.update()

    def setHoverPen(self, *args, **kwargs):
        """Set the pen for drawing the line while the mouse hovers over it.
        Allowable arguments are any that are valid
        for :func:`mkPen <pyqtgraph.mkPen>`.

        If the line is not movable, then hovering is also disabled.

        Added in version 0.9.9."""
        self.hoverPen = pg.mkPen(*args, **kwargs)
        if self.mouseHovering:
            self.currentPen = self.hoverPen
            self.update()

    def boundingRect(self):
        #br = UIGraphicsItem.boundingRect(self)
        br = self.viewRect()
        ## add a 4-pixel radius around the line for mouse interaction.

        px = self.pixelLength(direction=pg.Point(1,0), ortho=True)  ## get pixel length orthogonal to the line
        if px is None:
            px = 0
        w = (max(4, self.pen.width()/2, self.hoverPen.width()/2)+1) * px
        br.setBottom(-w)
        br.setTop(w)
        return br.normalized()

    def hoverEvent(self, ev):
        if (not ev.isExit()) and self.movable and ev.acceptDrags(QtCore.Qt.LeftButton):
            self.setMouseHover(True)
        else:
            self.setMouseHover(False)

    def setMouseHover(self, hover):
        ## Inform the item that the mouse is (not) hovering over it
        if self.mouseHovering == hover:
            return
        self.mouseHovering = hover
        if hover:
            self.currentPen = self.hoverPen
            self.sigHovering.emit(self)
        else:
            self.currentPen = self.pen
            self.sigHoveringFinished.emit(self)
        self.update()
