import colors
from PySide import QtGui
GROUP_BOX_FONT = "QGroupBox { font-weight: bold; font-size: 12px} "
MARKER_LABEL_FONT = "background-color: rgb(%s, %s, %s); color: rgb(%s, %s, %s); font-size: 16px;"
WARNING_LABEL_FONT = "background-color: rgb(%s, %s, %s); color: rgb(%s, %s, %s); font-size: 25px;"
MOUSE_LABEL_FONT = QtGui.QFont()
MOUSE_LABEL_FONT.setBold(True)
AXIS_LABEL_FONT = {'font-size': '14px', 'color': colors.GREY_NUM}
CONTROL_ITEM_SIZE = 16
CONTROL_LABEL_SIZE = 16
MARKER_LABEL_SIZE = 16
HIGHLIGHTED_MARKER_LABEL = "background-color: %s; color: %s" % (colors.MARKER_LABEL_HOVER, colors.WHITE)
