"""
General-purpose widgets
"""
from collections import OrderedDict
from PySide import QtGui, QtCore
import pyqtgraph as pg
import colors
import fonts
import os
from pyrf.units import M, G
from util import (change_widget_background, 
                decode_freq_text, 
                set_button_color, 
                create_item_label, 
                initialize_group_box, 
                create_plot_label)

from difflib import ndiff

FREQ_UNITS = ['GHz', 'MHz', 'kHz', 'Hz' ]
BACKSPACE_KEY = 16777219
ESCAPE_KEY = 16777216
UP_KEY = 16777235
DOWN_KEY = 16777237
RETURN_KEYS = [16777220, 16777221]
NEGATIVE_KEY = 45
UNITS_TO_FACTOR = {'Hz': 1,
                    'kHz': 1e3,
                    'MHz': 1e6,
                    'GHz': 1e9,
                    'dBm': 1,
                    'dB': 1,
                    None: 1}
UNITS_TO_DECIMALS = {'Hz': 0,
                    'kHz': 3,
                    'MHz': 6,
                    'GHz': 9,
                    'dBm': 2,
                    'dB': 2,
                    None: 0}
TEXT_TO_UNITS = {'H': 'Hz',
                'HZ': 'Hz',
                'K': 'kHz',
                'M': 'MHz',
                'G': 'GHz',
                'D': 'dBm',
                'D': 'dB'}

class QButtonTabs(QtGui.QWidget):
    """
    Tab widget that uses buttons instead of tabs
    """
    def __init__(self, controller, rows, columns):
        super(QButtonTabs, self).__init__()
        self.columns = columns
        self.rows = rows
        self.controller = controller
        controller.marker_change.connect(self.marker_changed)
        self._create_controls()
        self._build_layout()

    def _create_controls(self):
        num_labels = self.rows * self.columns
        self.labels = []
        font = QtGui.QFont()
        font.setPixelSize(fonts.CONTROL_ITEM_SIZE)

        for n in range(num_labels):

            label = QtGui.QPushButton(str(n + 1))
            label.setFont(font)
            label.setMinimumHeight(20)
            
            if n == 0:
                change_widget_background(label, 'QPushButton', colors.WHITE, self.controller.label_color)            
            else:
                change_widget_background(label, 'QPushButton', self.controller.widget_color, self.controller.label_color)
            self.labels.append(label)

        def _label_clicked(index):
            self.controller.apply_marker_options(-1, ['selected_marker'], [index])

        self.labels[0].clicked.connect(lambda: _label_clicked(int(self.labels[0].text()) - 1))
        self.labels[1].clicked.connect(lambda: _label_clicked(int(self.labels[1].text()) - 1))
        self.labels[2].clicked.connect(lambda: _label_clicked(int(self.labels[2].text()) - 1))
        self.labels[3].clicked.connect(lambda: _label_clicked(int(self.labels[3].text()) - 1))
        self.labels[4].clicked.connect(lambda: _label_clicked(int(self.labels[4].text()) - 1))
        self.labels[5].clicked.connect(lambda: _label_clicked(int(self.labels[5].text()) - 1))
        self.labels[6].clicked.connect(lambda: _label_clicked(int(self.labels[6].text()) - 1))
        self.labels[7].clicked.connect(lambda: _label_clicked(int(self.labels[7].text()) - 1))
        self.labels[8].clicked.connect(lambda: _label_clicked(int(self.labels[8].text()) - 1))
        self.labels[9].clicked.connect(lambda: _label_clicked(int(self.labels[9].text()) - 1))
        self.labels[10].clicked.connect(lambda: _label_clicked(int(self.labels[10].text()) - 1))
        self.labels[11].clicked.connect(lambda: _label_clicked(int(self.labels[11].text()) - 1))
    def _build_layout(self):
        self.setLayout(QtGui.QGridLayout())
        grid = self.layout()
        grid.setSpacing(0)
        n = 0
        for r in range(self.rows):
            for c in range(self.columns):
                grid.addWidget(self.labels[n], r, c, 1 ,1)
                n += 1

    def marker_changed(self, marker, state, changed):
        self._marker_state = state
        # if a config has changed
        if marker == -1:
            # change tab position if changed
            if 'selected_marker' in changed:
                for l in self.labels:
                    if l.text() == str(state[marker]['selected_marker'] + 1):  
                        change_widget_background(l, 'QPushButton', self.controller.selected_widget, self.controller.label_color)

                    else:
                        change_widget_background(l, 'QPushButton', self.controller.widget_color, self.controller.label_color)

class TraceTab(QtGui.QWidget):
    """
    Tab widget that uses buttons instead of tabs
    """
    def __init__(self, controller, rows, columns):
        super(TraceTab, self).__init__()
        self.columns = columns
        self.rows = rows
        self.controller = controller
        controller.app_change.connect(self.app_changed)
        self._create_controls()
        self._build_layout()
        self.labels[0].click()

    def _create_controls(self):
        num_labels = self.rows * self.columns
        self.labels = []
        font = QtGui.QFont()
        font.setPixelSize(fonts.CONTROL_ITEM_SIZE)
        for n in range(num_labels):

            label = QtGui.QPushButton(str(n + 1))
            label.setFont(font)
            label.setMinimumHeight(20)

            if n == 0:
                change_widget_background(label, 'QPushButton', colors.WHITE, self.controller.label_color)            
            else:
                change_widget_background(label, 'QPushButton', self.controller.widget_color, self.controller.label_color)
            self.labels.append(label)

        def _label_clicked(index):
            self.controller.apply_app_options(selected_trace_tab = index)

        self.labels[0].clicked.connect(lambda: _label_clicked(int(self.labels[0].text()) - 1))
        self.labels[1].clicked.connect(lambda: _label_clicked(int(self.labels[1].text()) - 1))
        self.labels[2].clicked.connect(lambda: _label_clicked(int(self.labels[2].text()) - 1))
        self.labels[3].clicked.connect(lambda: _label_clicked(int(self.labels[3].text()) - 1))
        self.labels[4].clicked.connect(lambda: _label_clicked(int(self.labels[4].text()) - 1))
        self.labels[5].clicked.connect(lambda: _label_clicked(int(self.labels[5].text()) - 1))

    def _build_layout(self):
        self.setLayout(QtGui.QGridLayout())
        grid = self.layout()
        grid.setSpacing(0)
        n = 0
        for r in range(self.rows):
            for c in range(self.columns):
                grid.addWidget(self.labels[n], r, c, 1 ,1)
                n += 1

    def app_changed(self, state, changed):
        self._app_state = state

        # change tab position if changed
        if 'selected_trace_tab' in changed:
            for l in self.labels:
                if l.text() == str(state['selected_trace_tab'] + 1):   
                    change_widget_background(l, 'QPushButton', self.controller.selected_widget, self.controller.label_color)
                else:
                    change_widget_background(l, 'QPushButton', self.controller.widget_color, self.controller.label_color)

class QTabWidgetPlayback(QtGui.QTabWidget):
    """
    QTabWidget with playback features
    """
    def quiet_tab(self, tab):
        """
        quietly click radio button state
        """
        b = self.blockSignals(True)
        self.setCurrentIndex(tab)
        self.blockSignals(b)
        return

class QRadioPlayback(QtGui.QRadioButton):
    """
    QRadioButton with playback features
    """
    def quiet_click(self):
        """
        quietly click radio button state
        """
        b = self.blockSignals(True)
        self.click()
        self.blockSignals(b)
        return

class QLineEditPlayback(QtGui.QLineEdit):
    """
    QLineEditPlayback with playback features
    """
    def quiet_update(self, text):
        """
        quietly click radio button state
        """
        b = self.blockSignals(True)
        self.setText(text)
        self.blockSignals(b)
        return

class QPushLabelPlayback(QtGui.QWidget):
    """
    Custom Qt widget that can be clicked
    """
    clicked = QtCore.Signal()
    def __init__(self, name):
        super(QPushLabelPlayback, self).__init__()
        """
        quietly click radio button state
        """

        self.label = QtGui.QLabel(name)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        grid = QtGui.QHBoxLayout()
        grid.addWidget(self.label)
        self.setMinimumHeight(50)
        self.setLayout(grid)
        


    def setText(self, text):
        self.label.setText(text)

    def mousePressEvent(self, event):
        self.clicked.emit()

    def text(self):
        return self.label.text()

    def setLabelStyleSheet(self, style_sheet):
        self.label.setStyleSheet(style_sheet)

    def click(self):
        self.clicked.emit()

    def setPixmap(self, pixmap):
        self.label.setPixmap(pixmap)

class QComboBoxPlayback(QtGui.QComboBox):
    """
    QComboBox with playback features
    """
    def __init__(self):
        super(QComboBoxPlayback, self).__init__()
        self.setEditable(True)
        # self.setStyleSheet("QComboBoxPlayback{color: rgb(75, 75, 75); Background-color: rgb(234,234,234); border: rrgb(234,234,234)}")
        font = QtGui.QFont()
        font.setPixelSize(fonts.CONTROL_ITEM_SIZE)
        self.setFont(font)
        self.setEditable(False)

    def quiet_update(self, items=None, select_item=None, seperator = 0, seperator_text = ''):
        """
        Update all the items and select a new item in the combo box
        without sending any signals

        :param items: a list of strings to added to the combo box, if None,
                then attempt to update the current index to the select_item
        :param select_item: the string to select, if None then attempt
            to select the same string currently selected in the new list
            of items, if not present select the first item.
        :param seperator: index of seperator, if 0 no seperator will be added
        :param seperator_text: Text of seperator
        """

        # if nothing is passed return
        if items is None and select_item is None:
            return

        # if no new items are passed, select the required item (select_item)
        if items is None:
            b = self.blockSignals(True)
            for i in range(self.count()):

                if self.itemText(i) == select_item:
                
                    self.setCurrentIndex(i)
                    self.blockSignals(b)
                    return
            return

        # if new items are passed
        if select_item is None:
            select_item = self.currentText()
        b = self.blockSignals(True)
        self.clear()
        for i, item in enumerate(items):
            self.addItem(item)
            if item == select_item:
                self.setCurrentIndex(i)
        if seperator > 0:
            self.insertSeparator(seperator)
            self.insertItem(seperator + 1, seperator_text)
            self.insertSeparator(seperator + 2)
        self.blockSignals(b)

    def quiet_update_pixel(self, colors, name, select_item = None):
        """
        Update all the item colors

        :param items: a list of tuple containing the colors
        :param select_item: the string to select, if None then attempt
            to select the same string currently selected in the new list
            of items, if not present select the first item.
        """

        if select_item is None:
            select_item = 0
        block = self.blockSignals(True)
        self.clear()
        for n, c in zip(name, colors):

            button_icon = QtGui.QIcon()
            color = QtGui.QColor()
            r, g, b = c
            color.setRgb(r, g, b)
            pixmap = QtGui.QPixmap(50, 50)
            pixmap.fill(color)
            button_icon.addPixmap(pixmap)
            self.addItem(button_icon, str(n))
            if n == select_item:
                self.setCurrentIndex(select_item)
        self.blockSignals(block)
    def playback_value(self, value):
        """
        Remove all items but value and disable the control
        """
        self.quiet_update([value])
        self.setEnabled(False)

class QCheckBoxWidget(QtGui.QWidget):

    clicked = QtCore.Signal()
    def __init__(self, name, color=None):
        super(QCheckBoxWidget, self).__init__()

        self.name = name
        self.color = color
        self._create_controls()
        self.setLayout(QtGui.QGridLayout())
        self._build_layout()

    def mousePressEvent(self, event):
        self.check_box.click()

    def _create_controls(self):
        self.label = create_item_label(self.name)
        if self.color is not None:
            self.label.setStyleSheet('QLabel {color: %s}' % self.color)
        self.check_box = QCheckBoxPlayback('')
        self.check_box.setLayoutDirection(QtCore.Qt.LayoutDirection.RightToLeft)
        def checkbox_clicked():
            self.clicked.emit()
        self.check_box.clicked.connect(checkbox_clicked)

    def _build_layout(self):
        grid = self.layout()
        grid.setContentsMargins(0,0, 0,0)
        grid.setSpacing(25)
        row = 0
        grid.addWidget(self.label, row, 0, 1, 10)
        grid.addWidget(self.check_box, row, 11, 1, 1)
        grid.setColumnStretch(0, 300)
        self.resize_widget()
    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)
    def isChecked(self):
        return self.check_box.isChecked()

    def setChecked(self, state):
        self.check_box.setChecked(state)

    def quiet_update(self, value):
        """
        Set the checkbox state without sending signals

        :param value: True/False
        """

        self.check_box.quiet_update(value)

    def playback_value(self, value):
        """
        display value with checkbox disabled

        :param value: True/False
        """
        self.checkbox.playback_value(value)

class QCheckBoxPlayback(QtGui.QCheckBox):
    """
    QCheckBox with playback features
    """
    def __init__(self, text):
        super(QCheckBoxPlayback, self).__init__()
        self.setText(text)
        self.setStyleSheet("QCheckBoxPlayback{color: rgb(75, 75, 75); Background-color: rgb(234,234,234); border: rrgb(234,234,234)}")
        font = QtGui.QFont()
        font.setPixelSize(fonts.CONTROL_LABEL_SIZE)
        self.setFont(font)

    def quiet_update(self, value):
        """
        Set the checkbox state without sending signals

        :param value: True/False
        """

        b = self.blockSignals(True)
        self.setChecked(value)
        self.blockSignals(b)

    def playback_value(self, value):
        """
        display value with checkbox disabled

        :param value: True/False
        """
        self.quiet_update(value)
        self.setEnabled(False)


class QDoubleSpinBoxPlayback(QtGui.QDoubleSpinBox):
    """
    QSpinBox with playback features
    """
    def quiet_update(self, minimum=None, maximum=None, value=None):
        """
        Set the spinbox range and value without sending signals

        :param minimum: float
        :param maximum: float
        :param value: float to set or None to leave unchanged
        """
        b = self.blockSignals(True)
        if minimum is not None:
            self.setMinimum(minimum)
        if maximum is not None:
            self.setMaximum(maximum)
        if value is not None:
            self.setValue(value)
        self.blockSignals(False)

    def playback_value(self, value):
        """
        display value and disable widget
        """
        self.quiet_update(value, value, value)
        self.setEnabled(False)

    def stepBy(self, steps):
        """
        Force immediate change when using step buttons
        """
        rval = super(QDoubleSpinBoxPlayback, self).stepBy(steps)
        self.editingFinished.emit()

class QClickLabel(QtGui.QWidget):
    """
    A Widget with a centralized label emits an app state once clicked
    :param controller: the device controller
    """

    def __init__(self, controller, name, reference_name, alignment, width = None, height = None, background_color = colors.BLACK_NUM):
        super(QClickLabel, self).__init__()

        self.controller = controller
        self.name = name
        self.reference_name = reference_name
        self.alignment = alignment
        self.width = width
        self.height = height
        self.color = background_color
        self._initialize_label()

    def _initialize_label(self):
        self.setLayout(QtGui.QGridLayout())
        self.label = QtGui.QLabel()
        grid = self.layout()
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Minimum)
        self.label.setText(self.name)
        self.label.setSizePolicy(sizePolicy)
        self.label.setStyleSheet(fonts.MARKER_LABEL_FONT % (self.color + colors.GREY_NUM))
        self.label.setAlignment(self.alignment)
        grid.setContentsMargins(0,0, 0,0)
        grid.addWidget(self.label, 0, 0,1,1)
        if self.width is not None:
            self.setMaximumWidth(self.width)
        if self.height is not None:
            self.setMaximumHeight(self.height)
    def setText(self, text):
        self.label.setText(text)

    def mousePressEvent(self, event):
        self.controller.apply_app_options(app_click = self.reference_name,
                                          click_location = self.geometry())

    def wheelEvent(self, event):

        if event.delta() > 0:
            self.controller.apply_app_options(wheel_up = self.reference_name)
        else:
            self.controller.apply_app_options(wheel_down = self.reference_name)
        

class ValueEditWidget(QtGui.QWidget):
    """
    A widget that is used to control values in the RTSA
    :param controller: the device controller
    :param name: name of the widget
    :param val_unit: name of unit to be used
    :param current_unit: unit to be displayed
    :param step: step of the value

    :returns: the trigger settings
    """

    value_changed = QtCore.Signal(float)
    min = 0
    max = 0
    freq = 0
    numeric_pad_active = False
    def __init__(self, controller, 
                name, 
                val_unit = 'Hz', 
                current_unit = 'MHz', 
                step = 0.0,
                allow_step_change = True):
        super(ValueEditWidget, self).__init__()

        self.controller = controller
        self.name = name

        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.app_change.connect(self.app_changed)
        self.value_unit = val_unit
        self.unit = current_unit
        self.step = step
        self.allow_step_change = allow_step_change
        self._create_controls()
        self.setLayout(QtGui.QGridLayout())
        self._build_layout()
        self._connect_device_controls()

        self.min = 0
        self.max = 0
        self.freq = 0
        self.numeric_pad_active = False

    def wheelEvent(self, event):
        if event.delta() > 0:
            self._wheel_up()
        else:
            self._wheel_down()
        

    def _wheel_up(self):
        if 'float' in str(type(self.step)):
            self.quiet_update(value = (self.value + self.step))
            self.numeric_widget.updateValue(self.value)
        else:
            
            self.numeric_widget.forceIncrement(self.value, self.unit)
        self.quiet_update(value = self.numeric_widget.value)
        self.value_changed.emit(self.numeric_widget.value)

    def _wheel_down(self):
        if 'float' in str(type(self.step)):
            self.quiet_update(value = self.value - self.step)
        if not 'float' in str(type(self.step)):
             self.numeric_widget.forceDecrement(self.value, self.unit)
        self.value_changed.emit(self.value)

    def mousePressEvent(self, event):
        self.show_numeric_widget(event)
    def _create_controls(self):

        self.value_edit = QtGui.QLabel()
        self.value_edit.setMinimumHeight(30)
        self.value_edit.setStyleSheet("QLabel{font-size: %dpx; color: rgb(75, 75, 75); Background-color: %s; text-align: left}" % (fonts.CONTROL_ITEM_SIZE, self.controller.widget_color))
        self.numeric_widget = NumericEntryWidget(self.controller, 
                                                self.name,
                                                self.value_unit,
                                                self.step)

    def _build_layout(self):
        self.setMaximumHeight(30)
        grid = self.layout()
        grid.setSpacing(0)
        grid.setContentsMargins(0,0, 0,0)
        row = 0
        grid.addWidget(self.value_edit, row, 0, 10, 4)

    def _connect_device_controls(self):

        def new_val(val, text, unit):

            if val >= self.min and val < self.max:
                self.unit = unit
                self.value = val
                self.value_changed.emit(val)

        def numeric_closed():
            self.numeric_pad_active = False
            self.value_edit.setStyleSheet("QLabel{font-size: %dpx;  color: rgb(75, 75, 75); Background-color: %s; text-align: left}" % (fonts.CONTROL_ITEM_SIZE, self.controller.widget_color))

        self.numeric_widget.value_change.connect(new_val)
        self.numeric_widget.widget_closed.connect(numeric_closed)

    def show_numeric_widget(self, click_event = None):
        self.numeric_pad_active = True
        self.controller.apply_app_options(active_num_control = self.name)
        display_freq = self.value_edit.text()

        self.numeric_widget.show_controls(display_freq, self.unit, click_event)
        self.value_edit.setStyleSheet("QLabel{font-size: %dpx;  Background-color: %s; color: white; text-align: left}" % (fonts.CONTROL_ITEM_SIZE, self.controller.selected_widget))

    def close_numeric_pad(self):
        self.numeric_widget.close()

    def quiet_update(self, minimum=None, maximum = None, value = None):
        if minimum is not None:
            self.min = minimum
        if maximum is not None:
            self.max = maximum
        if value is not None:
            if value > self.max:
                value = self.max
            if value < self.min:
                value = self.min
            decimals = UNITS_TO_DECIMALS[self.unit]
            decimal_text = '%0.' + str(decimals) + 'f'
            if self.unit is None:
                text = decimal_text % (value / UNITS_TO_FACTOR[self.unit]) + ' '
            else:
                text = decimal_text % (value / UNITS_TO_FACTOR[self.unit]) + ' ' + self.unit
            self.freq = value
            self.value_edit.setText(text)
            self.value = value

    def setSingleStep(self, step):
        self.step = step
        self.numeric_widget.setStep(step)

    def getUnit(self):
        return self.unit

    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def state_changed(self, state, changed):
        self.gui_state = state
        
    def app_changed(self, state, changed):
        self.app_state = state
        if 'fstep' in changed:
            if self.value_unit == 'Hz' and self.allow_step_change:
                self.numeric_widget.setStep(state['fstep'])
                self.step = state['fstep']

        if 'active_num_control' in changed:
                if self.name != state['active_num_control'] and self.numeric_pad_active:
                    self.close_numeric_pad()
        if 'app_click' in changed:

            if state['app_click'] == self.name:
                self.show_numeric_widget()
        if 'wheel_up' in changed:
            if state['wheel_up'] == self.name:
                self._wheel_up()
  
        if 'wheel_down' in changed:
            if state['wheel_down'] == self.name:
                self._wheel_down()


    def currentValue(self):
        return self.value

class NumericEntryWidget(QtGui.QDialog):
    """
    A widget that is used to enter the changed frequency
    """
    value_change = QtCore.Signal(float, list, list)
    widget_closed = QtCore.Signal()
    value_changed = False
    value_inc = False
    val = 0.0

    def __init__(self, controller, name, val_unit, step):
        super(NumericEntryWidget, self).__init__()
        
        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.app_change.connect(self.app_changed)
        self.name = name
        self.step = step
        self.value_unit = val_unit
        self.setWindowTitle(self.name)
        self._create_controls()
        self.setLayout(QtGui.QGridLayout())
        self._build_layout()
        self._connect_device_controls()
        change_widget_background(self, 'QDialog',  controller.widget_color)
        self.setWindowFlags(self.windowFlags() ^ QtCore.Qt.WindowContextHelpButtonHint)
    def closeEvent(self, event):

        self.widget_closed.emit()

    def keyPressEvent(self, event):
        try:
            num = int(event.text())
            self.number_buttons[num].click()
        except ValueError:
            x = 1
        
        # event for negative sign
        if event.key() == NEGATIVE_KEY:
            self.negative_sign.click()

        if event.key() == BACKSPACE_KEY:
            self.redact_button.click()

        # event for return key
        if event.key() in RETURN_KEYS:
            if self.unit == None:
                # if no units, emit integer
                self.emit_integer_value()

            if self.value_unit == 'dBm':
                self.dbm_button.click()
            elif self.value_unit == 'dB':
                self.db_button.click()

            unit = self.value_edit.text().split()[-1]
            if self.value_edit.text().split()[-1] in FREQ_UNITS:
                for h in self.hz_buttons:
                    if h.text() == unit:
                        h.click()
                        return
            else:
                for h in self.hz_buttons:
                    if h.text() == self.unit:
                        h.click()

        # event for the escape key
        if event.key() == ESCAPE_KEY:
            txt = self.value_edit.text()
            self.value_changed = False
            self.value_inc = False
            if txt == self.disp_text:
                self.close()
            else:
                self.value_changed = False
                self.value_edit.setText(self.disp_text)
        # up key click
        if event.key() == UP_KEY:
            self.up_val.click()

        # down key click
        if event.key() == DOWN_KEY:
            self.down_val.click()

        # event for decimal
        if event.text() == '.':
            self.dot_button.click()
        key = event.text().upper()

        # event for key that represents a unit

        if key in TEXT_TO_UNITS:
            for b in self.hz_buttons:
                if b.text() == TEXT_TO_UNITS[key]:
                    b.click()

            if key == 'D':
                self.dbm_button.click()

    def _create_controls(self):
        self.value_edit = QtGui.QLabel()
        self.value_edit.setMinimumHeight(30)
        self.value_edit.setStyleSheet("QLabel{font-size: %dpx; Background-color: %s; color: white; text-align: left}" % (fonts.CONTROL_ITEM_SIZE, self.controller.selected_widget))
        def update_color(button):
            button.setLabelStyleSheet('QLabel{font-size: 16px}')
            button.setMinimumWidth(60)
            button.setContentsMargins(0,0, 0,0)

        # directory of icons
        dir =  os.getcwd() + '\icons'

        # initialize up arrow
        self.up_val = QPushLabelPlayback('')
        self.up_val.setPixmap(QtGui.QPixmap('up_arrow.png'))

        # initialize downarrow
        self.down_val = QPushLabelPlayback('')
        self.down_val.setPixmap(QtGui.QPixmap('down_arrow.png'))

        # initialize negative button
        self.negative_sign = QPushLabelPlayback('-')
        update_color(self.negative_sign)
        if not self.value_unit in ['dBm', 'dB', None]:
            self.negative_sign.setEnabled(False)

        # initialize the number button
        self.number_buttons = []
        for n in range(10):
            button = QPushLabelPlayback(str(n))
            update_color(button)
            self.number_buttons.append(button)

        # create the . button
        self.dot_button = QPushLabelPlayback('.')
        update_color(self.dot_button)

        # create the redact button
        self.redact_button = QPushLabelPlayback('<<')
        update_color(self.redact_button)

        # create freq unit button
        self.hz_buttons = []
        for u in FREQ_UNITS:
            button = QPushLabelPlayback(u)
            update_color(button)
            self.hz_buttons.append(button)

        # create dBm unit button
        self.dbm_button = QPushLabelPlayback('dBm')
        update_color(self.dbm_button)
        
        # create dB unit button
        self.db_button = QPushLabelPlayback('dB')
        update_color(self.db_button)

        # create return button
        self.return_button = QPushLabelPlayback('Enter')
        update_color(self.return_button)

    def _build_layout(self):
        grid = self.layout()
        grid.setSpacing(0)
        grid.setContentsMargins(0,0, 0,0)
        row = 0
        grid.addWidget(self.value_edit, row, 0, 1, 7)
        row += 1
        grid.addWidget(self.up_val, row, 0, 1, 1)
        grid.addWidget(self.down_val, row, 1, 1, 1)
        grid.addWidget(self.redact_button, row, 2, 1, 1)
        count = 0
        for r in range(3):
            r += 1
            for c in range(3):
                grid.addWidget(self.number_buttons[count + 1], r + 1, c, 1, 1)
                count += 1

        grid.addWidget(self.number_buttons[0], 5, 1, 1, 1)
        grid.addWidget(self.dot_button, 5, 0, 1, 1)
        grid.addWidget(self.negative_sign, 5, 2, 1, 1)
        r = 1
        # add the relavant unit
        if self.value_unit == 'Hz':
            for u in self.hz_buttons:
                grid.addWidget(u, r, 6, 1, 1)
                r += 1
        elif self.value_unit == 'dBm':
            grid.addWidget(self.dbm_button, r, 6, 1, 1)

        elif self.value_unit == 'dB':
            grid.addWidget(self.db_button, r, 6, 1, 1)

        elif self.value_unit is None:
            grid.addWidget(self.return_button, r, 6, 1, 1)

    def _connect_device_controls(self):
 
        # connect number pad controls
        def keypad_type(button):
            self.value_inc = False
            char = button.text()
            if not self.value_changed:
                text = ''
                self.value_changed = True
            else:
                text = self.value_edit.text()
            if char == '.':
                if char in text:
                    return
            if char == '-':
                if len(text) != 0:
                    return
            self.disp_text = text + char
            self.value_edit.setText(self.disp_text)
            self.setFocus()

        self.number_buttons[0].clicked.connect(lambda: keypad_type(self.number_buttons[0]))
        self.number_buttons[1].clicked.connect(lambda: keypad_type(self.number_buttons[1]))
        self.number_buttons[2].clicked.connect(lambda: keypad_type(self.number_buttons[2]))
        self.number_buttons[3].clicked.connect(lambda: keypad_type(self.number_buttons[3]))
        self.number_buttons[4].clicked.connect(lambda: keypad_type(self.number_buttons[4]))
        self.number_buttons[5].clicked.connect(lambda: keypad_type(self.number_buttons[5]))
        self.number_buttons[6].clicked.connect(lambda: keypad_type(self.number_buttons[6]))
        self.number_buttons[7].clicked.connect(lambda: keypad_type(self.number_buttons[7]))
        self.number_buttons[8].clicked.connect(lambda: keypad_type(self.number_buttons[8]))
        self.number_buttons[9].clicked.connect(lambda: keypad_type(self.number_buttons[9]))
        self.dot_button.clicked.connect(lambda: keypad_type(self.dot_button))
        self.negative_sign.clicked.connect(lambda: keypad_type(self.negative_sign))

        def redact_typed():
            if not self.value_changed:
                return
            else:
                text = self.value_edit.text()
            if len(text) > 0:
                text = text[:-1]
                self.value_edit.setText(text)
        self.redact_button.clicked.connect(redact_typed)

        def unit_clicked(unit_button):
            if not self.value_changed and not self.value_inc:
                self.value_change.emit(self.value, self.disp_text, unit_button.text())
                self.close()
                return
            if self.value_inc:
                unit = self.unit
                val = self.value
                factor = UNITS_TO_FACTOR[unit]
            else:
                unit = unit_button.text()
                factor = UNITS_TO_FACTOR[unit]
                val = float(self.value_edit.text().split(' ')[0]) * factor
                            
            
            decimals = UNITS_TO_DECIMALS[unit]
            decimal_text = '%0.' + str(decimals) + 'f'
            text = decimal_text % (val / factor) + ' ' + unit
            self.value_change.emit(val, text, unit_button.text())

            self.close()

        self.hz_buttons[0].clicked.connect(lambda: unit_clicked(self.hz_buttons[0]))
        self.hz_buttons[1].clicked.connect(lambda: unit_clicked(self.hz_buttons[1]))
        self.hz_buttons[2].clicked.connect(lambda: unit_clicked(self.hz_buttons[2]))
        self.hz_buttons[3].clicked.connect(lambda: unit_clicked(self.hz_buttons[3]))
        self.dbm_button.clicked.connect(lambda: unit_clicked(self.dbm_button))
        self.db_button.clicked.connect(lambda: unit_clicked(self.db_button))

        def  increase_val():
            self.setFocus()
            if not self.value_changed:
                if 'float' in str(type(self.step)):
                    self.value += self.step
                    self.value_inc = True
                    self.update_label_val()
                else:
                    for s in self.step:
                        if self.value < s:
                            self.value = s
                            self.value_inc = True
                            self.update_label_val()
                            return
            
        self.up_val.clicked.connect(increase_val)

        def  decrease_val():
            self.setFocus()
            if not self.value_changed:
                if 'float' in str(type(self.step)):
                    self.value -= self.step
                    self.value_inc = True
                    self.update_label_val()
                else:

                    for s in reversed(self.step):
                        if self.value > s:
                            self.value = s
                            self.value_inc = True
                            self.update_label_val()
                            return

        self.down_val.clicked.connect(decrease_val)

        def  ret_clicked():
            self.emit_integer_value()
        self.return_button.clicked.connect(ret_clicked)

    def update_label_val(self):
            unit = self.unit
            factor = UNITS_TO_FACTOR[unit]
            decimals = UNITS_TO_DECIMALS[unit]
            decimal_text = '%0.' + str(decimals) + 'f'
            if self.unit is None:
                text = decimal_text % (self.value / factor) + ' '
            else:
                text = decimal_text % (self.value / factor) + ' ' + unit
            self.value_edit.setText(text)

    def show_controls(self, disp_text, unit, event = None):

        self.value_changed = False
        self.value_inc = False
        self.disp_text = disp_text
        mouse_pos = QtGui.QCursor.pos()

        screen_height = QtGui.QDesktopWidget().screenGeometry().height()
        
        if self.size().height() +  mouse_pos.y() > screen_height:
            y_pos = mouse_pos.y() - (self.size().height() - (screen_height - mouse_pos.y())) + 30
            self.move(mouse_pos.x(), y_pos)
        elif event is not None:
            if self.size().width() > 240:
                width = 240
            else:
                width = self.size().width()
            x_pos = mouse_pos.x() - event.x() - width - 40
            self.move(x_pos, mouse_pos.y())
        else:
            self.move(mouse_pos.x(), mouse_pos.y())
        
        self.activateWindow()
        self.value_changed = False
        self.value_edit.setText(disp_text)
        self.unit = unit
        self.show()
        self.value = float(disp_text.split()[0]) * UNITS_TO_FACTOR[self.unit]
        self.setFocus()

    def setStep(self, step):

        self.step = step

    def emit_integer_value(self):

        if not self.value_changed and not self.value_inc:
            self.close()
            return
        unit = self.unit
        if self.value_inc:
            val = self.value
        else:
            val = int(self.value_edit.text())
        text = str(val)
        self.value_change.emit(val, text, self.unit)
        self.close()

    def updateValue(self, val):
        self.value = val

    def forceIncrement(self, val, unit):
        self.unit = unit
        self.value = val
        self.value_inc = True
        if self.unit is None:
            self.value += self.step
            self.emit_integer_value()
            return

        if 'float' in str(type(self.step)):
            self.value += self.step
        else:
            for s in self.step:

                if val < s:
                    self.value = s
                    break
        if self.value_unit == 'Hz':
            for b in self.hz_buttons:
                if b.text() == self.unit:
                    b.click()
        if self.value_unit == 'dBm':
            self.dbm_button.click()

        if self.value_unit == 'dB':
            self.db_button.click()

    def forceDecrement(self, val, unit):
        self.unit = unit
        self.value = val
        self.value_inc = True
    
        if self.unit is None:
            self.value -= self.step
            self.emit_integer_value()
            return

        if 'float' in str(type(self.step)):
            self.value -= self.step
        else:

            for s in reversed(sorted(self.step)):
                
                if val > s:
                    self.value = s
                    break
        if self.value_unit == 'Hz':
            for b in self.hz_buttons:
                if b.text() == self.unit:
                    
                    b.click()

        if self.value_unit == 'dBm':
            self.dbm_button.click()

        if self.value_unit == 'dB':
            self.db_button.click()

    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def state_changed(self, state, changed):
        self.gui_state = state
        
    def app_changed(self, state, changed):
        self.app_state = state


class PlotWindowWidget(QtGui.QWidget):
    """
    A widget based from the Qt widget with a layout that represents the Fstart/Fstop and Fcenter
    of the given plot window
    """
    button_clicked = 1
    def __init__(self, controller, plot, grad = False):
        super(PlotWindowWidget, self).__init__()
        
        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        controller.warning_change.connect(self.warning_changed)
        controller.app_change.connect(self.app_changed)
        self._plot = plot
        self.view_box = self._plot.plotItem.getViewBox()
        self._grad = grad
        self._create_controls()
        self.setLayout(QtGui.QGridLayout())
        self._build_layout()
        
    def mousePressEvent(self, event):
        self.button_clicked =  event.button()

    def _create_controls(self):
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.Fixed)

        self._warning_label = QtGui.QLabel('')
        self._warning_label.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setBold(True)
        self._warning_label.setStyleSheet(fonts.WARNING_LABEL_FONT % (colors.BLACK_NUM + colors.RED_NUM))
        self._warning_label.setAlignment(QtCore.Qt.AlignRight)
        self._warning_label.setFont(font)
        label_width = 200
        freq_width = 200
        label_height = 20
        self._fcenter_label = QClickLabel(self.controller, 
                                        'Center', 
                                        'Center Frequency', 
                                        QtCore.Qt.AlignCenter, 
                                        height = label_height, 
                                        width = freq_width)
            
        self._fstop_label = QClickLabel(self.controller, 
                                        'Stop', 
                                        'Stop Frequency',
                                        QtCore.Qt.AlignRight, 
                                        width = freq_width,
                                        height = label_height)

        self._fstart_label = QClickLabel(self.controller, 
                                    'Start', 
                                    'Start Frequency',
                                    QtCore.Qt.AlignLeft,
                                    width = freq_width,
                                    height = label_height)
        
        self._rbw_label = QClickLabel(self.controller, 
                                    'RBW', 
                                    'RBW', 
                                    QtCore.Qt.AlignLeft,
                                    width = label_width,
                                    height = label_height)

        self._vbw_label = QClickLabel(self.controller, 
                                    'VBW', 
                                    'Video Bandwidth', 
                                    QtCore.Qt.AlignLeft, 
                                    width = label_width,
                                    height = label_height)

        self._span_label = QClickLabel(self.controller, 
                                    'Span', 
                                    'Span', 
                                    QtCore.Qt.AlignCenter, 
                                    width = freq_width,
                                    height = label_height)

    def _build_layout(self):

        grid = self.layout()

        if self._grad:
            grid.addWidget(self._plot.gradient_editor)
        else:
            grid.setColumnMinimumWidth(0, 20)

        grid.setSpacing(1)

        row = 0
        width = 100
        grid.addWidget(self._plot, row, 1, 12, width)
        grid.addWidget(self._warning_label, row, 1, 1, width - 10)
        grid.addWidget(self._rbw_label, 14, 1, 1, 1)
        grid.addWidget(self._vbw_label, 14, 2, 1, 1)
        grid.addWidget(self._fcenter_label, 13, 45, 1, 1)
        grid.addWidget(self._span_label, 14, 45, 1, 2)
        grid.addWidget(self._fstart_label, 13, 1, 1, 1)
        grid.addWidget(self._fstop_label, 13, width, 1, 1)
        
        self.resize_widget()

    def device_changed(self, dut):
        self.dut_prop = dut.properties

    def state_changed(self, state, changed):
        self.gui_state = state

        if 'span' in changed or 'center' in changed:
            if state.rfe_mode() in self.dut_prop.TUNABLE_MODES:
                center = state.center
            else:
                center = self.dut_prop.MAX_TUNABLE[state.rfe_mode()]
            if int(center) > G:
                unit = 'GHz'
                div = G
            else:
                unit = 'MHz'
                div = M
            self._fcenter_label.setText('Center: %0.4f %s' % (center / div, unit))
            fstart = center - (state.span / 2)
            fstop = center + (state.span / 2)
            self._fstart_label.setText('Start: %0.4f %s' % (fstart/ div, unit))
            self._fstop_label.setText('Stop: %0.4f %s' % (fstop / div, unit))
            self.update_span_label()

        if 'rbw' in changed:
            self.update_rbw_label()

    def plot_changed(self, state, changed):
        self.plot_state = state
        if 'vbw' in changed or 'vbw_auto' in changed:
            self.update_vbw_label()
            if state['vbw_auto']:
                self._vbw_label.setEnabled(False)
            else:
                self._vbw_label.setEnabled(True)

        if 'rbw_auto' in changed:
            self.update_rbw_label()
            if state['rbw_auto']:
                self._rbw_label.setEnabled(False)
            else:
                self._rbw_label.setEnabled(True)

    def app_changed(self, state, changed):
        self._app_state = state
        if state['capture_mode'] == 'RTSA':
            self._vbw_label.hide()
        else:
            self._vbw_label.show()

    def warning_changed(self, state, changed):

        if state['saturation']:
            self._warning_label.show()
            self._warning_label.setText('Gain Overload Warning!!!')
        else:
            self._warning_label.hide()
            self._warning_label.setText('')

    def update_rbw_label(self):
        if hasattr(self, 'gui_state'):
            rfe_mode = self.gui_state.rfe_mode()
            if self.plot_state['rbw_auto']:
                auto_mark = ''
            else:
                auto_mark = '#'
            if rfe_mode == 'HDR':
                self._rbw_label.setText("%sRBW: %0.2f Hz" % (auto_mark, self.gui_state.rbw))
            else:
                self._rbw_label.setText("%sRBW: %0.2f kHz" % (auto_mark, self.gui_state.rbw / 1e3))

    def update_vbw_label(self):
        if hasattr(self, 'gui_state'):
            rfe_mode = self.gui_state.rfe_mode()
            if self.plot_state['vbw_auto']:
                auto_mark = ''
            else:
                auto_mark = '#'
            self._vbw_label.setText(" %sVBW: %0.2f kHz" % (auto_mark, self.plot_state['vbw'] / 1e3))

    def update_span_label(self):
        rfe_mode = self.gui_state.rfe_mode()
        if rfe_mode == 'HDR':
            self._span_label.setText("Span: %0.2f kHz" % (self.gui_state.span / 1e3))
        else:
            self._span_label.setText("Span: %0.2f MHz" % (self.gui_state.span/ M))

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)

GRADIENTS = OrderedDict([
    ('thermal', {'ticks': [(0.3333, (185, 0, 0, 255)), (0.6666, (255, 220, 0, 255)), (1, (255, 255, 255, 255)), (0, (0, 0, 0, 255))], 'mode': 'rgb'}),
    ('flame', {'ticks': [(0.2, (7, 0, 220, 255)), (0.5, (236, 0, 134, 255)), (0.8, (246, 246, 0, 255)), (1.0, (255, 255, 255, 255)), (0.0, (0, 0, 0, 255))], 'mode': 'rgb'}),
    ('yellowy', {'ticks': [(0.0, (0, 0, 0, 255)), (0.2328863796753704, (32, 0, 129, 255)), (0.8362738179275941, (255, 255, 0, 255)), (0.5257586450247, (115, 15, 255, 255)), (1.0, (255, 255, 255, 255))], 'mode': 'rgb'} ),
    ('bipolar', {'ticks': [(0.0, (0, 255, 255, 255)), (1.0, (255, 255, 0, 255)), (0.5, (0, 0, 0, 255)), (0.25, (0, 0, 255, 255)), (0.75, (255, 0, 0, 255))], 'mode': 'rgb'}),
    ('spectrum', {'ticks': [(1.0, (255, 0, 255, 255)), (0.0, (255, 0, 0, 255))], 'mode': 'hsv'}),
    ('cyclic', {'ticks': [(0.0, (255, 0, 4, 255)), (1.0, (255, 0, 0, 255))], 'mode': 'hsv'}),
    ('greyclip', {'ticks': [(0.0, (0, 0, 0, 255)), (0.99, (255, 255, 255, 255)), (1.0, (255, 0, 0, 255))], 'mode': 'rgb'}),
    ('grey', {'ticks': [(0.0, (0, 0, 0, 255)), (1.0, (255, 255, 255, 255))], 'mode': 'rgb'}),
])

class PlotGradientWidget(pg.GradientWidget):
    """
    A pg gradient widget with the ability to load/add preset gradients
    """

    def __init__(self, parent,orientation):
        super(PlotGradientWidget, self).__init__()
        self.gradients = GRADIENTS
        self.orientation = orientation
        self.setOrientation(orientation)

    def loadPreset(self, name):
        """
        Load a predefined gradient.

        """
        # TODO: provide image with names of defined gradients
        self.restoreState(self.gradients[name])

    def addPreset(self, name, gradient):
        """
        Add a gradient to the list of predefined gradients.

        ===============  =================================================================================
        **Arguments:**
        name            Name of the new preset gradient
        gradient        Dict containing new gradient
                        Keys must include:
                            - 'mode': hsv or rgb
                            - 'ticks': a list of tuples (pos, (r,g,b,a))

        ===============  =================================================================================
        """
        self.gradients[name] = gradient