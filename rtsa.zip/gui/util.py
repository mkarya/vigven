import numpy as np
from PySide import QtGui, QtCore
import colors
import string
import fonts
import numpy 
ACCEPTABLE_UNITS = {'H': 1,
                    'HZ': 1,
                    'K': 1e3,
                    'KHZ': 1e3,
                    'M': 1e6,
                    'MHZ': 1e6,
                    'G': 1e9,
                    'GHZ': 1e9}
TEXT_TO_UNITS = {'H': 'Hz',
                    'HZ': 'Hz',
                    'K': 'kHz',
                    'KHZ': 'kHz',
                    'M': 'MHz',
                    'MHZ': 'MHz',
                    'G':'GHz',
                    'GHZ': 'GHz'}

def frequency_text(hz):
    """
    return hz as readable text in Hz, kHz, MHz or GHz
    """
    if hz < 1e3:
        return "%.3f Hz" % hz
    elif hz < 1e6:
        return "%.3f kHz" % (hz / 1e3)
    elif hz < 1e9:
        return "%.3f MHz" % (hz / 1e6)
    return "%.3f GHz" % (hz / 1e9)

def decode_freq_text(text):
    """
    return a float value deciphered from text
    """
    text = text.upper()
    factor = 0
    for unit in ACCEPTABLE_UNITS:   
        if unit in text:
            factor = ACCEPTABLE_UNITS[unit]
            break
    if factor == 0:
        factor = 1e6
        unit = 'MHZ'

    text.remove(UNIT)
    freq = float(text) * factor
    print freq
def find_nearest_index(value, array):
    """
    returns the index in the array of the nearest value      
    """
    idx = (np.abs(array-value)).argmin()
    return idx
    

def change_widget_background(widget, widget_type, background_color, border_color = None, border_width = 1):
    """
    changes the background color of the widget to the specified color
    """
    
    if border_color is None:
        widget.setStyleSheet("%s{Background-color: %s;}" % (widget_type, background_color)) 
    else:
        widget.setStyleSheet("%s{Background-color: %s; border: %dpx solid %s}" % (widget_type, background_color, border_width, border_color)) 

def initialize_groupbox_stylesheet(group_box, controller, hide=True):
        if hide:
            group_box.setVisible(False)
        params = (controller.widget_color, 
                controller.widget_border_length, 
                controller.border_color, 
                controller.widget_border_length, 
                controller.border_color, 
                controller.widget_border_length, 
                controller.border_color)
        group_box.setStyleSheet("QGroupBox{Background-color: %s; border-top: %dpx solid %s; border-left: %dpx solid %s;  border-right: %dpx solid %s}" % params) 

        group_box.setMinimumWidth(200)
        

def clear_layout(layout):
    """
    Clear all the widgets from a layout
    """
    if layout is None:
        return
    while layout.count():
        layout.removeItem(layout.takeAt(0))

def hide_layout(layout):
    """
    Hide all widgets in a layout
    """
    while layout.count():
        w = layout.takeAt(0).widget()
        if w:
            w.hide()

def initialize_group_box(controller, orientation = 'v'):
    """
    Inititalize and return a group box and a grid
    """
    widget = QtGui.QGroupBox()
    
    change_widget_background(widget, 
                    'QGroupBox',
                    controller.widget_color, 
                    border_color = controller.widget_color)

    if orientation == 'v':
        grid = QtGui.QVBoxLayout()
    else:
        grid = QtGui.QHBoxLayout()
    grid.setContentsMargins(2,2, 2,2)

    return widget, grid

def set_button_color(widget, color):
    c = QtGui.QColor()
    palette = QtGui.QPalette()
    c.setRgb(color[0], 
             color[1], 
             color[2])
    palette.setColor(QtGui.QPalette.Background, c)
    widget.setAutoFillBackground(True)
    widget.setPalette(palette)

def create_title_label(name, controller):
    font = QtGui.QFont()
    font.setBold(True)
    font.setPointSize(12)

    label = QtGui.QLabel(name)
    label.setStyleSheet('QLabel {Background: %s}' % controller.header_color)
    label.setFont(font)
    label.setAlignment(QtCore.Qt.AlignCenter)
    return label

def create_item_label(name = None):
    if name is None:
        return QtGui.QLabel()
    font = QtGui.QFont()
    font.setPixelSize(fonts.CONTROL_LABEL_SIZE)
    
    label = QtGui.QLabel(name)
    label.setFont(font)
    label.setAlignment(QtCore.Qt.AlignLeft)
    return label

def update_button(button, controller):
    button.setLabelStyleSheet('QLabel{background: %s; border-radius: 10px; color: %s}' % (controller.widget_button_color,
                                                                            controller.button_text_color))

def smooth(list,degree=1):
    new_list = []
    list_average = np.mean(sorted(list)[int(0.995 * len(list)):-1]) + 5
    for n, i in enumerate(list):
        
        start = max(0, n - degree)
        stop = min(len(list), n + degree)
        points = list[start:stop]
        if list[n] > list_average:
            new_list.append(list[n])
        else:
            new_list.append(np.mean(points))
 
    return new_list

def create_plot_label(text, alignment, width = None, background_color = colors.BLACK_NUM):
    sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.Fixed)
    label = QtGui.QLabel(text)
    label.setSizePolicy(sizePolicy)
    label.setStyleSheet(fonts.MARKER_LABEL_FONT % (background_color + colors.GREY_NUM))
    label.setAlignment(alignment)
    
    if width is not None:
        label.setMaximumWidth(width)
    return label

def format_frequency_text(freq_text):
    found_decimal = False
    count = 0
    new_string = ''
    for s in freq_text:

        if s == '.':
            found_decimal = True
            new_string = new_string + s
            continue

        if found_decimal:
            try:
                num = int(s)
                if count == 3:
                    count = 1
                    new_string = new_string + ' '
                else:
                    count += 1
            except ValueError:
                x = 1
        new_string = new_string + s
    
    return new_string
            
def calculate_rbw_values(state, prop):
    rfe_mode = state.rfe_mode()
    speca_mode = state.mode

    rbw_values = prop.RBW_VALUES[rfe_mode]
    if rfe_mode == 'HDR':
        unit = 'Hz'
        div = 1
    else:
        unit = 'kHz'
        div = 1000
        rbw_values.append(1e6)
    if 'Sweep' in speca_mode:
        min_rbw = prop.FULL_BW[rfe_mode] / 16384
        rbw_values = [i for i in rbw_values if i > min_rbw]
    return rbw_values
    
def auto_config_rbw(state, prop):
    rbw_values = calculate_rbw_values(state, prop)
    ratio = state.span / prop.DEFAULT_SPECA_SPAN
    new_rbw = (ratio * (max(rbw_values) - min(rbw_values))) + min(rbw_values)
    return new_rbw
    
    
def create_traingle_painter():

    mysymbol = QtGui.QPainterPath()
    mysymbol.addText(0, 0, QtGui.QFont("San Serif", 10), 'Y')
    br = mysymbol.boundingRect()
    scale = min(1. / br.width(), 1. / br.height())
    tr = QtGui.QTransform()
    tr.scale(scale, scale)
    tr.translate(-br.x() - br.width()/2., -br.y() - br.height()/2.)
    mysymbol = tr.map(mysymbol)

    return mysymbol