
from PySide import QtGui, QtCore
from labels import MARKERS, TRACES
from fonts import GROUP_BOX_FONT, HIGHLIGHTED_MARKER_LABEL
from gui_config import MarkerState, TraceState, AppState
from util import hide_layout, change_widget_background, format_frequency_text
M = 1e6
UNITS = ['GHz', 'MHz', 'kHz', 'Hz']
UNIT_MAGNITUDE = {'GHz': 1e9,
                  'MHz': 1e6,
                  'kHz': 1e3,
                  'Hz': 1}
UNIT_DECIMAL = {'GHz': 11,
                  'MHz': 8,
                  'kHz': 5,
                  'Hz': 2}
TABLE_HEADERS = ['Marker', 'Mode', 'Trace', 'X', 'Y']
TRACE_TABLE_HEADERS = ['Channel Power (dBm)']
TRACES =[0]

class DisplayTable(QtGui.QWidget):
    def __init__(self, controller):
        super(DisplayTable, self).__init__()
        self.app_state = AppState().state
        controller.app_change.connect(self.app_changed)
        controller.marker_change.connect(self.marker_changed)
        self.controller = controller
        self._create_controls()
        self.setLayout(QtGui.QGridLayout())
        self.resize_widget()

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Minimum)

    def _create_controls(self):
        self.setLayout(QtGui.QGridLayout())
        grid = self.layout()
        self.marker_table = MarkerTable(self.controller)
        self.channel_table = ChannelTable(self.controller)
        self.channel_table.setStyleSheet("QLabel {color : white;}")
        spacer_label = QtGui.QLabel()
        spacer2_label = QtGui.QLabel()
        grid.addWidget(spacer_label, 0,0,1,5)
        grid.addWidget(self.marker_table, 0,5,1,1)
        grid.addWidget(self.channel_table, 0,5,1,1)
        grid.addWidget(spacer2_label, 0,2,1,2)

    def app_changed(self, state, changed):
        self.app_state = state

        if 'measurement_mode' in changed:
            if state['measurement_mode'] == 'Analyzer':
                self.channel_table.hide()
                if not self._marker_state[-1]['show_table']:
                    self.hide()
            else:
                self.marker_table.hide()
                self.channel_table.show()
                self.show()
                

    def marker_changed(self, marker, state, changed):
        self._marker_state = state
        if marker < 0:
            if 'show_table' in changed:

                if self.app_state['measurement_mode'] == 'Analyzer':
                    if state[-1]['show_table']:
                        self.show()
                        self.marker_table.show()

                    else:
                        self.hide()
                        self.marker_table.hide()
                else:
                        self.marker_table.hide()

class MarkerTable(QtGui.QWidget):

    def __init__(self, controller):
        super(MarkerTable, self).__init__()
        self.controller = controller
        self._create_controls()

        controller.marker_change.connect(self.marker_changed)
        controller.trace_change.connect(self.trace_changed)
        controller.state_change.connect(self.state_changed)
        controller.app_change.connect(self.app_changed)
        self._marker_state = MarkerState().state
        self._trace_state = TraceState().state
        
        self.setLayout(QtGui.QGridLayout())
        self.resize_widget()

    def _create_controls(self):
        self._marker_rows = {}
        self.table = QtGui.QTableWidget()
        self.table.setRowCount(len(MARKERS) + 1)
        self.table.setColumnCount(len(TABLE_HEADERS))
        self.table.setMaximumWidth(500)
        # if table is clicked, changed clicked row to selected marker
        def table_clicked(row, colum):
           if row > 0:
                self.controller.apply_marker_options(-1, ['selected_marker'], [row - 1])
        self.table.cellClicked.connect(table_clicked)
        color = self.controller.label_color_num
        font = QtGui.QFont()
        font.setPixelSize(16)
        for h in range(len(TABLE_HEADERS)):
            # change text color of tables to represent color of item
            self.table.setItem(0,h, QtGui.QTableWidgetItem())
            self.table.item(0, h).setBackground(QtGui.QColor(color[0], color[1], color[2]))
            self.table.item(0, h).setForeground(QtGui.QColor(255, 255, 255))
            self.table.item(0, h).setText(TABLE_HEADERS[h])
            self.table.item(0, h).setFont(font)
        for m in MARKERS:
            for h in range(len(TABLE_HEADERS)):
                self.table.setItem(m + 1,h, QtGui.QTableWidgetItem())
                self.table.item(m + 1, h).setBackground(QtGui.QColor(0,0,0))

        self.table.setSelectionMode(QtGui.QTableWidget.NoSelection)
        # declare labels if marker table is turned off
        self.marker_label = QtGui.QLabel()

        self.table.setSortingEnabled(False)
        header = QtGui.QHeaderView(QtCore.Qt.Orientation.Horizontal)
        header.setResizeMode(QtGui.QHeaderView.ResizeMode.Fixed)
        header.setStretchLastSection(True)
        self.table.setHorizontalHeader(header)
        self.table.horizontalHeader().hide()
        self.table.verticalHeader().hide()
        self.table.setColumnWidth(0, 25)
        self.table.setColumnWidth(2, 60)
        self.table.setColumnWidth(3, 190)

    def _build_layout(self):
        grid = self.layout()
        hide_layout(grid)
        header_shown = False
        def show(widget, y, x, h, w):
            grid.addWidget(widget, y, x, h, w)
            widget.show()

        self.show()
        show(self.table, 0, 0, 1, 1)

        self.resize_widget()

    def marker_changed(self, marker, state, changed):
        self._marker_state = state
        selected_marker = self._marker_state[-1]['selected_marker']
        if self.app_state['measurement_mode'] != 'Analyzer':
            return
        if  'enabled' in changed:
            if marker >= 0:
                row = marker + 1
                if not state[marker]['enabled']:
                    for h in range(len(TABLE_HEADERS)):
                        self.table.item(row, h).setText('')
                self._build_layout()
        if marker >= 0:
            row = marker + 1
            if state[marker]['enabled']:
                unit = state[marker]['unit']
                factor = UNIT_MAGNITUDE[unit]

                decimals = "%" + "0.%df" % UNIT_DECIMAL[state[marker]['unit']]
                if  'freq' in changed or 'power' in changed or 'type' in changed:
                    # grab marker color
                    color = self._trace_state[state[marker]['trace']]['color']
                    
                    # grab marker type
                    marker_type = state[marker]['type']

                    # grab power and frequency
                    marker_freq = state[marker]['freq'] / factor
                    marker_power = state[marker]['power']
                    
                    # if delta, display delta values
                    if 'Delta' in marker_type:
                        pow_unit = 'dB'
                        freq = decimals % ((state[marker]['freq'] - state[int(marker_type[-1]) - 1]['freq']) / factor)
                        if marker_power is None or state[int(marker_type[-1]) - 1]['power'] is None:
                            power = None
                        else:

                            power =  marker_power - state[int(marker_type[-1]) - 1]['power']
                    else:
                        pow_unit = 'dBm'
                        freq = decimals % marker_freq
                        power = marker_power

                    for h in range(len(TABLE_HEADERS)):
                        # change text color of tables to represent color of item
                        self.table.item(row, h).setForeground(QtGui.QColor(color[0], color[1], color[2]))

                    self.table.item(row, 0).setText(str(marker + 1))
                    

                    self.table.item(row, 1).setText(marker_type)
                    if 'Delta' in marker_type:
                        self.table.item(row, 2).setText(str(state[marker]['trace'] + 1))
                    else:
                        self.table.item(row, 2).setText(str(state[marker]['trace'] + 1))
                    freq_text = format_frequency_text('%s %s' % (freq, unit))
                    self.table.item(row, 3).setText(freq_text)

                    if state[marker]['power'] is None or power is None:
                        self.table.item(row, 4).setText('---')
                    else:
                        self.table.item(row, 4).setText('%0.2f %s' % (power, pow_unit))

        else:
            if 'selected_marker' in changed:
                self._update_table_font()

    def _update_table_font(self):
        selected_marker = self._marker_state[-1]['selected_marker']
        for marker in self._marker_state:
            if marker >= 0:
                if marker == selected_marker:
                    font = QtGui.QFont()
                    font.setBold(True)
                    font.setPixelSize(16)
                    for h in range(len(TABLE_HEADERS)):
                        self.table.item(marker + 1, h).setFont(font)

                else:
                    font = QtGui.QFont()
                    font.setPixelSize(16)

                    for h in range(len(TABLE_HEADERS)):
                        self.table.item(marker + 1, h).setFont(font)
    def _update_label_colors(self, color):
        self.marker_label.setStyleSheet("QLabel {color : rgb(%d, %d, %d);}" % (color[0],
                                                                          color[1],
                                                                          color[2]))
    def app_changed(self, state, changed):
        self.app_state = state

    def state_changed(self, state, changed):
        if 'device_settings.iq_output_path' in changed:
            if state.device_settings['iq_output_path'] == 'CONNECTOR':
                self.setVisible(False)
            elif state.device_settings['iq_output_path'] == 'DIGITIZER':
                self.setVisible(True)

    def trace_changed(self, trace, state, changed):
        self._trace_state = state

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Preferred)

class ChannelTable(QtGui.QWidget):

    def __init__(self, controller):
        super(ChannelTable, self).__init__()
        self.controller = controller
        self._create_controls()
        self._build_layout()
        
        controller.trace_change.connect(self.trace_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        self._trace_state = TraceState().state
        self.resize_widget()

    def _create_controls(self):
        self._marker_rows = {}
        self.table = QtGui.QTableWidget()
        self.table.setRowCount(len(TRACES))
        self.table.setColumnCount(len(TRACE_TABLE_HEADERS) + 1)
        self.table.setHorizontalHeaderLabels(TRACE_TABLE_HEADERS)
        self.table.setMaximumHeight(60)
        self.table.setMaximumWidth(500)
        
        # first row is a la bel for the channel power
        self.table.setItem(0,0, QtGui.QTableWidgetItem())
        color = self.controller.label_color_num
        self.table.item(0, 0).setText('Total Channel Power')
        self.table.item(0, 0).setBackground(QtGui.QColor(color[0],color[0],color[0]))
        self.table.item(0, 0).setForeground(QtGui.QColor(255, 255, 255))
        self.table.setItem(0,1, QtGui.QTableWidgetItem())
        self.table.item(0, 1).setBackground(QtGui.QColor(0,0,0))

        self.table.setSortingEnabled(False)
        header = QtGui.QHeaderView(QtCore.Qt.Orientation.Horizontal)
        header.setResizeMode(QtGui.QHeaderView.ResizeMode.ResizeToContents)
        header.setStretchLastSection(True)
        self.table.setHorizontalHeader(header);
        header = QtGui.QHeaderView(QtCore.Qt.Orientation.Vertical)
        header.setResizeMode(QtGui.QHeaderView.ResizeMode.ResizeToContents)
        header.setStretchLastSection(True)
        self.table.setVerticalHeader(header)
        self.table.horizontalHeader().hide()
        self.table.verticalHeader().hide()


    def _build_layout(self):
        self.setLayout(QtGui.QGridLayout())
        grid = self.layout()
        grid.addWidget(self.table, 0, 0, 1, 1)
        self.setLayout(grid)

    def state_changed(self, state, changed):
        if 'device_settings.iq_output_path' in changed:
            if state.device_settings['iq_output_path'] == 'CONNECTOR':
                self.setVisible(False)
            elif state.device_settings['iq_output_path'] == 'DIGITIZER':
                self.setVisible(True)

    def plot_changed(self, state, changed):
        self.plot_state = state

    def trace_changed(self, trace, state, changed):
        self._trace_state = state
        if trace == 0:
            if 'color' in changed:
                color = state[trace]['color']
  
                self.table.item(0, 1).setForeground(QtGui.QColor(color[0], color[1], color[2]))
            if 'channel_power' in changed:
                if state[trace]['mode'] == 'Off':
                    self.table.item(trace, 0).setText('1')
                else:
                    power_text = '%0.2f dBm' % state[trace]['channel_power']
                    span = max(self.plot_state['channel_power_region']) - min(self.plot_state['channel_power_region'])
                    freq_text = '%0.2f MHz' % (span / M)
                    self.table.item(0, 1).setText(('%s / %s' % (power_text, freq_text)))


    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Minimum)
