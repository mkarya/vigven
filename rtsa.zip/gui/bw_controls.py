from PySide import QtGui, QtCore

from pyrf.units import M
import colors
from widgets import (ValueEditWidget,
                    QComboBoxPlayback, 
                    QDoubleSpinBoxPlayback, 
                    QCheckBoxWidget)
from fonts import GROUP_BOX_FONT

from pyrf.sweep_device import MAXIMUM_SPP as MAXIMUM_SWEEP_SPP

from util import (create_item_label,
                create_title_label, 
                change_widget_background, 
                initialize_groupbox_stylesheet, 
                initialize_group_box, 
                clear_layout, 
                set_button_color, 
                hide_layout,
                calculate_rbw_values)

INPUT_DECIMALS = 8
WIDGET_WIDTH = 12
BW_STEPS = [1, 3, 1e2, 3e2, 1e3, 3e3, 1e4, 3e4, 1e5, 3e5, 1e6]
class BWControls(QtGui.QGroupBox):

    def __init__(self, controller):
        super(BWControls, self).__init__()

        self.controller = controller
        controller.device_change.connect(self.device_changed)
        controller.state_change.connect(self.state_changed)
        controller.plot_change.connect(self.plot_changed)
        controller.app_change.connect(self.app_changed)
        grid = QtGui.QGridLayout()
        grid.setContentsMargins(0,0, 0,0)
        initialize_groupbox_stylesheet(self, controller)

        self.setAlignment(QtCore.Qt.AlignTop)
        title_label = create_title_label('BW', self.controller)
        row = 0
        grid.addWidget(title_label, row, 0, 1, WIDGET_WIDTH)
        row += 1
        grid.addWidget(self._rbw_controls(), row, 1, 1, WIDGET_WIDTH - 2)
        row += 1
        grid.addWidget(self._vbw_controls(), row, 1, 1, WIDGET_WIDTH - 2)
        self.setLayout(grid)
        self.resize_widget()

    def resize_widget(self):
        self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)

    def _rbw_controls(self):
        bw_widget, grid = initialize_group_box(self.controller)
        rbw_label = create_item_label('Resolution Bandwidth')
        rbw_box =  ValueEditWidget(self.controller, 
                                        'RBW', 
                                        val_unit = 'Hz', 
                                        current_unit = 'kHz',
                                        step =  BW_STEPS,
                                        allow_step_change = False)
  
        rbw_box.setToolTip("Change the RBW of the FFT plot")

        def new_rbw():
            self.controller.apply_settings(rbw=self._rbw_box.value)
            self.controller.apply_plot_options(rbw_auto = False)       

        rbw_box.value_changed.connect(new_rbw)
        self._rbw_box = rbw_box
        
        # rbw mode widget
        self.rbw_mode = QCheckBoxWidget("Auto", color = 'rgb(75, 75, 75)')
        def change_rbw_mode():
            self.controller.apply_plot_options(rbw_auto = self.rbw_mode.isChecked())       
        self.rbw_mode.clicked.connect(change_rbw_mode)

        grid.addWidget(rbw_label)
        grid.addWidget(self.rbw_mode)
        grid.addWidget(rbw_box)
        bw_widget.setLayout(grid)
        return bw_widget

    def _vbw_controls(self):
        bw_widget, grid = initialize_group_box(self.controller)
        vbw_label = create_item_label('Video Bandwidth')
        # VBW entry widget
        self.vbw_box = ValueEditWidget(self.controller, 
                                        'Video Bandwidth', 
                                        val_unit = 'Hz', 
                                        current_unit = 'kHz',
                                        step = BW_STEPS,
                                        allow_step_change = False)
        def new_vbw():
            self.controller.apply_plot_options(vbw = self.vbw_box.currentValue(),
                                                vbw_auto = False)
        self.vbw_box.value_changed.connect(new_vbw)
        self.vbw_box.quiet_update(0, 12e12)
        self.vbw_box.setToolTip("Change the VBW of the FFT plot")

        # vbw mode widget
        self.vbw_mode = QCheckBoxWidget("Auto", color = 'rgb(75, 75, 75)')
        def change_vbw_mode():
            new_vbw = self._gui_state.rbw / self.vbw_rbw_ratio.value
            self.controller.apply_plot_options(vbw_auto = self.vbw_mode.isChecked())       
            
            self.controller.apply_plot_options()
        self.vbw_mode.clicked.connect(change_vbw_mode)

        # vbw to rbw ratio
        ratio_label = create_item_label('RBW:VBW')
        self.vbw_rbw_ratio = ValueEditWidget(self.controller, 
                                        'RBW:VBW',
                                        val_unit = None, 
                                        current_unit = None,
                                        step = 1.0,
                                        allow_step_change = False)

        self.vbw_rbw_ratio.quiet_update(1, 12e12, 1)
        def new_vbw_ratio():
            self.controller.apply_plot_options(vbw_ratio = self.vbw_rbw_ratio.currentValue())
        self.vbw_rbw_ratio.value_changed.connect(new_vbw_ratio)
        space_label = create_item_label('')
        space_label.setMaximumHeight(10)
        grid.addWidget(vbw_label)
        grid.addWidget(self.vbw_box)
        grid.addWidget(self.vbw_mode)
        grid.addWidget(space_label)
        grid.addWidget(ratio_label)
        grid.addWidget(self.vbw_rbw_ratio)
        bw_widget.setLayout(grid)
        self.vbw_widget = bw_widget
        return bw_widget

    def device_changed(self, dut):
        # to later calculate valid frequency values
        self.dut_prop = dut.properties

    def state_changed(self, state, changed):
        self._gui_state = state

        if 'mode' in changed:
            self._update_rbw_options()

        if 'rbw' in changed:
            self._rbw_box.quiet_update(value = state.rbw)

        if 'playback' in changed:
            if state.playback:
                self._rbw_box.playback_value(str(state.rbw))
            else:
                self._rbw_box.setEnabled(True)

        if 'device_settings.iq_output_path' in changed:
            if state.device_settings['iq_output_path'] == 'CONNECTOR':
                self._rbw_box.setEnabled(False)
            elif state.device_settings['iq_output_path'] == 'DIGITIZER':
                self._rbw_box.setEnabled(True)

    def plot_changed(self, state, changed):
        self._plot_state = state
        if 'vbw_auto' in changed:
            self.vbw_mode.quiet_update(state['vbw_auto'])

        if 'vbw' in changed:
            if hasattr(self, '_gui_state'):
                self.vbw_box.quiet_update(value = state['vbw'])
        if 'vbw_ratio' in changed:

            self.vbw_rbw_ratio.quiet_update(value = state['vbw_ratio'])

        if 'rbw_auto' in changed:
            self.rbw_mode.quiet_update(state['rbw_auto'])

    def app_changed(self, state, changed):
        self._app_state = state
        if state['capture_mode'] == 'RTSA':
            self.vbw_widget.hide()
        else:
            self.vbw_widget.show()

    def _update_rbw_options(self):
        """
        populate RBW drop-down with reasonable values for the current mode
        """
        if hasattr(self, '_gui_state'):
            self._rbw_values = calculate_rbw_values(self._gui_state, self.dut_prop)
            self._rbw_box.quiet_update(min(self._rbw_values), 
                                        max(self._rbw_values),
                                        self._gui_state.rbw)
