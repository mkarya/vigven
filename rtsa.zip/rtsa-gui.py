#!/usr/bin/env python

from gui.spectrum_analyzer import main

main()
